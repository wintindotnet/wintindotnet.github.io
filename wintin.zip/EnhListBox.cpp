// EnhListBox.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "EnhListBox.h"
#include "ContentPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEnhListBox

CEnhListBox::CEnhListBox()
{
}

CEnhListBox::~CEnhListBox()
{
}


BEGIN_MESSAGE_MAP(CEnhListBox, CListBox)
	//{{AFX_MSG_MAP(CEnhListBox)
	ON_WM_RBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnhListBox message handlers

void CEnhListBox::OnRButtonUp(UINT nFlags, CPoint point) 
{
  CRect Rect;          

  // Simulate item selection

  SendMessage(WM_LBUTTONDOWN, 0, MAKELONG(point.x, point.y));
  SendMessage(WM_LBUTTONUP, 0, MAKELONG(point.x, point.y));

  // Adjust point to cursor position

  GetWindowRect(&Rect);
  point += Rect.TopLeft();
  ((CContentPage *) GetParent())->OnRButtonDown(nFlags, point);
}

