// TinEditView.cpp : implementation file
//

#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "TinEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTinEditView dialog


CTinEditView::CTinEditView(CWnd* pParent /*=NULL*/)
	: CDialog(CTinEditView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTinEditView)
	m_szName = _T("");
	m_szValue = _T("");
	//}}AFX_DATA_INIT
}


void CTinEditView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTinEditView)
	DDX_Control(pDX, IDDELETE, m_cbDelete);
	DDX_Control(pDX, IDC_SESSION, m_cbSession);
	DDX_Control(pDX, IDNEW, m_cbnew);
	DDX_Control(pDX, IDC_TREE, m_ctValueTree);
	DDX_Text(pDX, IDC_EDIT_NAME, m_szName);
	DDX_Text(pDX, IDC_EDIT_VALUE, m_szValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTinEditView, CDialog)
	//{{AFX_MSG_MAP(CTinEditView)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE, OnSelchangedTree)
	ON_BN_CLICKED(IDNEW, OnNew)
	ON_CBN_SELCHANGE(IDC_SESSION, OnSelchangeSession)
	ON_EN_CHANGE(IDC_EDIT_NAME, OnChangeEditName)
	ON_EN_CHANGE(IDC_EDIT_VALUE, OnChangeEditValue)
	ON_BN_CLICKED(IDDELETE, OnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CTinEditView::AddListToTree(char *szName, struct listnode *node)
{
	HTREEITEM hItem;
	TV_INSERTSTRUCT tvis;
	
	tvis.hInsertAfter = TVI_LAST;
	tvis.item.mask = TVIF_TEXT|TVIF_PARAM;
	tvis.item.hItem = NULL;

	tvis.hParent = TVI_ROOT;
	tvis.item.pszText = szName;
	tvis.item.lParam = (long) node;
	hItem = m_ctValueTree.InsertItem(&tvis);
	tvis.hParent = hItem;

	while ((node = node->next))
	{
		tvis.item.pszText = node->left;
		tvis.item.lParam = (long) node;
		m_ctValueTree.InsertItem(&tvis);
	}

}

void CTinEditView::InitTree(void)
{
	struct listnode *node;

	m_ctValueTree.DeleteAllItems( );

	node =(CurrentSession) ? CurrentSession->actions : common_actions;
	AddListToTree("Actions", node);

	node =(CurrentSession) ? CurrentSession->aliases : common_aliases;
	AddListToTree("Aliases", node);

	node =(CurrentSession) ? CurrentSession->highs : common_highs;
	AddListToTree("Highlights", node);

	node =(CurrentSession) ? CurrentSession->subs : common_subs;
	AddListToTree("Substitutes", node);

	node =(CurrentSession) ? CurrentSession->antisubs : common_antisubs;
	AddListToTree("Antisubstitutes", node);

	node =(CurrentSession) ? CurrentSession->myvars : common_myvars;
	AddListToTree("Variables", node);
}

/////////////////////////////////////////////////////////////////////////////
// CTinEditView message handlers


BOOL CTinEditView::OnInitDialog() 
{
	int iPos;
	struct session *ses;
	
	CDialog::OnInitDialog();


	// Fill the dropdown

	ses = sessionlist;

	while(ses)
	{
		iPos = m_cbSession.InsertString(-1, ses->name);
		m_cbSession.SetItemDataPtr(iPos, ses);
		ses = ses->next;
	}

	iPos = m_cbSession.InsertString(-1, "Common Lists");
	m_cbSession.SetItemDataPtr(iPos, NULL);

	m_cbSession.SetCurSel(0);

	// Initialise tree

	CurrentSession = (struct session *) m_cbSession.GetItemDataPtr(0);
	InitTree();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTinEditView::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	struct listnode *node;
	
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	
	if(m_ctValueTree.GetParentItem(pNMTreeView->itemNew.hItem) == NULL)
	{
		m_szName = "";
		m_szValue = "";
	}
	else
	{
		node = (struct listnode *) (pNMTreeView->itemNew.lParam);
		m_szName = node->left;
		m_szValue = node->right;
	}

	UpdateData(FALSE);

	namechanged = 0;
	valuechanged = 0;
	UpdateButtons();

	*pResult = 0;
}

void CTinEditView::OnNew() 
{
	struct listnode *head, *node, *prev;
	
	if(m_szName == "" || m_szValue == "")
		return;
		
	HTREEITEM hItem = m_ctValueTree.GetSelectedItem();
	
	if(hItem == NULL)
		return;

	HTREEITEM hItemParent = m_ctValueTree.GetParentItem(hItem);	
	node = (struct listnode *)m_ctValueTree.GetItemData(hItem);

	if(hItemParent == NULL || m_szName != node->left)	
	{
		// this is a new node of parent's type

		if(hItemParent == NULL)
			head = (struct listnode *)m_ctValueTree.GetItemData(hItem);
		else
			head = (struct listnode *)m_ctValueTree.GetItemData(hItemParent);

		// Check argument is ok, if it's a highlight

		if(head == (CurrentSession ? CurrentSession->highs : common_highs))
		{
			if(!is_high_arg(m_szValue.GetBuffer(1)))
			{
				AfxMessageBox("Invalid highlight: must be a colour or highlight number");
				return;
			}
		}		

		if(head == (CurrentSession ? CurrentSession->actions : common_actions))
		{
			insertnode_list(head, m_szName.GetBuffer(1), m_szValue.GetBuffer(1), "5", PRIORITY);
		}
		else
		{
			insertnode_list(head, m_szName.GetBuffer(1), m_szValue.GetBuffer(1), "", ALPHA);
		}

		// find where the node was put

		node = searchnode_list(head, m_szName.GetBuffer(1));

		// walk the list to find item behind it

		prev = head;
		
		while(prev->next && prev->next != node)
			prev = prev->next;

		if(prev->next != node)
			return;		// curious, couldnt find it...

		// walk the tree to find the item

		if(hItemParent == NULL)
			hItemParent = hItem;

		hItem = m_ctValueTree.GetChildItem(hItemParent);

		while(hItem && m_ctValueTree.GetItemData(hItem) != (DWORD)prev)
			hItem = m_ctValueTree.GetNextSiblingItem(hItem);

		if(!hItem)
			hItem = hItemParent;

		// phew

		TV_INSERTSTRUCT tvis;
		
		tvis.hInsertAfter = hItem;
		tvis.item.mask = TVIF_TEXT|TVIF_PARAM;
		tvis.item.hItem = NULL;

		tvis.hParent = hItemParent;
		tvis.item.pszText = m_szName.GetBuffer(1);
		tvis.item.lParam = (DWORD) node;
		hItem = m_ctValueTree.InsertItem(&tvis);

		m_ctValueTree.SelectItem(hItem);
	}
	else
	{
		// this is a replacement for the current node

		head = (struct listnode *)m_ctValueTree.GetItemData(hItemParent);

		// Check argument is ok, if it's a highlight

		if(head == (CurrentSession ? CurrentSession->highs : common_highs))
		{
			if(!is_high_arg(m_szValue.GetBuffer(1)))
			{
				AfxMessageBox("Invalid highlight: must be a colour or highlight number");
				return;
			}
		}		

		myfree(node->right);
		node->right = mystrdup(m_szValue.GetBuffer(1));
		valuechanged = 0;
		UpdateButtons();
	}

}

void CTinEditView::OnSelchangeSession() 
{
	CurrentSession = (struct session *) (m_cbSession.GetItemDataPtr(m_cbSession.GetCurSel()));
	InitTree();
}

void CTinEditView::OnChangeEditName() 
{
	namechanged = 1;
	UpdateButtons();
}

void CTinEditView::OnChangeEditValue() 
{
	valuechanged = 1;
	UpdateButtons();
}

void CTinEditView::UpdateButtons() 
{
	CString cs;

	UpdateData(TRUE);

	if(valuechanged || namechanged)
		m_cbDelete.EnableWindow(FALSE);
	else
		m_cbDelete.EnableWindow(TRUE);
	
	if(namechanged)
	{
		m_cbnew.SetWindowText("Add");

		if(m_szValue != "" && m_szName != "")
		{
			m_cbnew.EnableWindow(TRUE);
		}
		else
		{
			m_cbnew.EnableWindow(FALSE);
		}
	}
	else
	{
		m_cbnew.SetWindowText("Replace");

		if(valuechanged && m_szValue != "")
		{
			m_cbnew.EnableWindow(TRUE);
		}
		else
		{
			m_cbnew.EnableWindow(FALSE);
		}
	}
}

void CTinEditView::OnDelete() 
{
	struct listnode *node, *head;

	if(m_szName == "")
		return;
	
	HTREEITEM hItem = m_ctValueTree.GetSelectedItem();
	
	if(hItem == NULL)
		return;

	HTREEITEM hItemParent = m_ctValueTree.GetParentItem(hItem);	

	if(hItemParent == NULL)	
		return;


	node = (struct listnode *)m_ctValueTree.GetItemData(hItem);
	head = (struct listnode *)m_ctValueTree.GetItemData(hItemParent);

	deletenode_list(head, node);
	m_ctValueTree.DeleteItem(hItem);

	UpdateData(FALSE);
}
