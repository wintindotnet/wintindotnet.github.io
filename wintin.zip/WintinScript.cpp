// WintinScript.cpp : implementation file
//

#include "stdafx.h"
//#include "telnet.h"
#include "WintinScript.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WintinScript

IMPLEMENT_DYNCREATE(WintinScript, CCmdTarget)

WintinScript::WintinScript()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	
	AfxOleLockApp();
}

WintinScript::~WintinScript()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	
	AfxOleUnlockApp();
}


void WintinScript::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(WintinScript, CCmdTarget)
	//{{AFX_MSG_MAP(WintinScript)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(WintinScript, CCmdTarget)
	//{{AFX_DISPATCH_MAP(WintinScript)
	DISP_FUNCTION(WintinScript, "Command", Command, VT_I2, VTS_BSTR)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IWintinScript to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {AED07E4E-5821-443F-85E0-7F9B4EFAD13E}
static const IID IID_IWintinScript =
{ 0xaed07e4e, 0x5821, 0x443f, { 0x85, 0xe0, 0x7f, 0x9b, 0x4e, 0xfa, 0xd1, 0x3e } };

BEGIN_INTERFACE_MAP(WintinScript, CCmdTarget)
	INTERFACE_PART(WintinScript, IID_IWintinScript, Dispatch)
END_INTERFACE_MAP()

// {5E0C8826-7C28-4B60-8070-4EB08E650E70}
IMPLEMENT_OLECREATE(WintinScript, "TELNET.WintinScript", 0x5e0c8826, 0x7c28, 0x4b60, 0x80, 0x70, 0x4e, 0xb0, 0x8e, 0x65, 0xe, 0x70)

/////////////////////////////////////////////////////////////////////////////
// WintinScript message handlers

short WintinScript::Command(LPCTSTR cmd) 
{
	// TODO: Add your dispatch handler code here

	return 0;
}
