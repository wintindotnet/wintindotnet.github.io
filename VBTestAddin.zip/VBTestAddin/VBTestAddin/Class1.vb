Imports System
Imports ScriptEngine
Imports ICSharpCode.Core.Services

Public Class Class1
    Inherits AbstractService
    Implements ICommand

    Private interpreter As Interpreter

    Sub New()

    End Sub

    Sub Class1_Initialize(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Initialize
        interpreter = DirectCast(ServiceManager.Services.GetService(GetType(Interpreter)), Interpreter)
    End Sub

    Sub HandleMenuItem()
        interpreter.Display(Environment.NewLine & "AddinTest Menu Item Selected" & Environment.NewLine)
    End Sub



    Public Sub ProcessCommand(ByVal verb As String, ByVal args As String) Implements ScriptEngine.ICommand.ProcessCommand
        interpreter.Display(Environment.NewLine & "Command " & verb & " called with arguments " & args & Environment.NewLine)
    End Sub
End Class

Public Class MenuTest
    Inherits AbstractMenuCommand

    Public Overrides Sub Run(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim class1 As Class1
        class1 = DirectCast(ServiceManager.Services.GetService(GetType(Class1)), Class1)
        class1.HandleMenuItem()
    End Sub
End Class
