// WrapLength.cpp : implementation file
//

#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "WrapLength.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWrapLength dialog


CWrapLength::CWrapLength(CWnd* pParent /*=NULL*/)
	: CDialog(CWrapLength::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWrapLength)
	m_WrapLength = 0;
	//}}AFX_DATA_INIT
}


void CWrapLength::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWrapLength)
	DDX_Text(pDX, IDC_EDIT1, m_WrapLength);
	DDV_MinMaxInt(pDX, m_WrapLength, 10, 1000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWrapLength, CDialog)
	//{{AFX_MSG_MAP(CWrapLength)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWrapLength message handlers


extern "C" int wraplength;

BOOL CWrapLength::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_WrapLength = wraplength;
	UpdateData(FALSE);
	
	return TRUE;  
}

