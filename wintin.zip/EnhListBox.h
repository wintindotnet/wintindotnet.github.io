// EnhListBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEnhListBox window

class CEnhListBox : public CListBox
{
// Construction
public:
	CEnhListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnhListBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEnhListBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEnhListBox)
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
