
/* Function and structure declarations introduced as part of the tintin/
   Wintin code revamp

   WDL 7/4/96
*/

/* Globals defined in main.c */



extern int term_echoing;
extern int echo;
extern int speedwalk;
extern int togglesubs;
extern int presub;
extern int update_common;
extern int redraw;
extern int sessionsstarted;
extern int puts_echoing;
extern int verbose;
extern int alnum;
extern int acnum ;
extern int subnum;
extern int varnum;
extern int hinum;
extern int pdnum;
extern int antisubnum;
extern int verbatim;
extern char homepath[];
extern char E;
extern struct session *sessionlist, *activesession;
extern struct listnode *common_aliases, *common_actions, *common_subs, *common_myvars;
extern struct listnode *common_highs, *common_antisubs, *common_pathdirs;
extern char vars[10][BUFFER_SIZE];	/* the %0, %1, %2,....%9 variables */
extern char remvars[BUFFER_SIZE];   /* the %r remainder */
extern char tintin_char;
extern char verbatim_char;
extern char system_com[];
extern int mesvar[];
extern int display_row, display_col, input_row, input_col;
extern int term_columns;
extern char k_input[];
extern char done_input[], prev_command[];
extern int hist_num;
extern int conn_has_closed;
extern int bppmode;
extern int in_bpp_packet;
extern int bpp_packet_line;
extern char *bpp_packet[];
extern HWND hwMusicMCIWnd, hwSoundMCIWnd;



/* globals in ticks.c */

extern int sec_to_tick, time0, tick_size;

/* globals in files.c */

extern struct completenode *complete_head;

/* globals in variable.c */

extern time_t time_started;

/* action.c */

extern void action_command(char *arg, struct session *ses);
extern void unaction_command(char *arg, struct session *ses);
extern void prepare_actionalias(char *string, char *result, struct session *ses);
extern void substitute_vars(char *arg, char *result);
extern void check_all_actions(char *line, struct session *ses);
extern int match_a_string(char *line, char *mask);
extern int check_one_action(char *line, char *action, struct session *ses);
extern int check_a_action(char *line, char *action, struct session *ses);

/* alias.c */

extern void alias_command(char *arg, struct session *ses);
extern void unalias_command(char *arg, struct session *ses);


/* antisub.c */

extern void parse_antisub(char *arg, struct session *ses);
extern void unantisubstitute_command(char *arg, struct session *ses);
extern int do_one_antisub(char *line, struct session *ses);

/* files.c */

extern int read_complete(char *filename);
extern void log_command(char *arg, struct session *ses);
extern void append_command(char *arg, struct session *ses);
extern struct session *read_command(char *filename, struct session *ses);
struct session *readsrc_command(char *filename, struct session *ses);
extern struct session *write_command(char *filename, struct session *ses);
extern struct session *writesession_command(char *filename, struct session *ses);
extern void prepare_for_write(char *command, char *left, char *right, char *pr, char *result);
extern void prepare_quotes(char *string);

/* glob.c */

extern int match(char *regex, char *string);

/* help.c */

void help_command(char *arg);

/* highligh.c */

extern void parse_high(char *arg, struct session *ses);
extern int is_high_arg(char *s);
extern void unhighlight_command(char *arg, struct session *ses);
extern void do_one_high(char *line, struct session *ses);
extern void add_codes(char *line, char *result, char *htype, int flag);

/* history.c */

extern void history_command(struct session *ses);
extern void do_history(char *buffer, struct session *ses);
extern void insert_history(char *buffer, struct session *ses);
extern struct session *parse_history_command(char *command, char *arg, struct session *ses);

/* ivars.c */

extern void math_command(char *line, struct session *ses);
extern void if_command(char *line, struct session *ses);
extern int eval_expression(char *arg);
extern int conv_to_ints(char *arg);
extern int do_one_inside(int begin, int end);

/* llist.c */

extern struct listnode *init_list(void);
extern void kill_list(struct listnode *nptr);
extern void kill_all(struct session *ses, int mode);
extern struct listnode *copy_list(struct listnode *sourcelist, int mode);
extern void insertnode_list(struct listnode *listhead, char *ltext, char *rtext, char *prtext, int mode);
extern void deletenode_list(struct listnode *listhead, struct listnode *nptr);
extern struct listnode *searchnode_list(struct listnode *listhead, char *cptr);
extern struct listnode *searchnode_list_begin(struct listnode *listhead, char *cptr, int mode);
extern void shownode_list(struct listnode *nptr);
extern void shownode_list_action(struct listnode *nptr);
extern void show_list(struct listnode *listhead);
extern void show_list_action(struct listnode *listhead);
extern struct listnode *search_node_with_wild(struct listnode *listhead, char *cptr);
extern int check_one_node(char *text, char *action);
extern void addnode_list(struct listnode *listhead, char *ltext, char *rtext, char *prtext);
extern int count_list(struct listnode *listhead);

/* main.c */

extern BOOL myhandler(DWORD cttype);
extern void tininit(char *);
extern void tinchar(unsigned c);
extern int tinspecchar(char *s);
void tinquit(void);
extern void tinread(SOCKET rsock);
extern void tinasyncread(struct session * sesptr);
extern void tinclose(SOCKET sock);
extern int interpret_buffer(unsigned c, struct session *ses);
extern void read_mud(struct session *ses);
extern void do_one_line(char *line, struct session *ses);
extern void snoop(char *buffer, struct session *ses);
extern void showinwin(char *cptr, int window);
extern void openwin(char *arg);
extern void wswitch(char *cptr);
extern void conio(char *cptr);
extern void tintin_puts(char *cptr, struct session *ses);
extern void tintin_puts2(char *cptr, struct session *ses);
extern void tintin_puts3(char *cptr, struct session *ses);
extern void tintin_debug(char *cptr, struct session *ses);
extern void tintin_panel(int ind, char *txt, struct session *ses);
extern void tintick(void);
extern void split_command(void);
extern void unsplit_command(void);

/* misc.c */

extern void cr_command(struct session *ses);
extern void version_command(void);
extern void verbatim_command(void);
extern struct session *all_command(char *arg, struct session *ses);
extern void redraw_command(void);
extern void bell_command(struct session *ses);
extern void boss_command(struct session *ses);
extern void bpp_command(struct session *ses);
extern void char_command(char *arg, struct session *ses);
extern void echo_command(char *arg, struct session *ses);
extern void end_command(char *command, struct session *ses);
extern void ignore_command(struct session *ses);
extern void presub_command(struct session *ses);
extern void update_command(struct session *ses);
extern void togglesubs_command(struct session *ses);
extern void showme_command(char *arg, struct session *ses);
extern void debug_command(char *arg, struct session *ses);
extern void panel_command(char *arg, struct session *ses);
extern void loop_command(char *arg, struct session *ses);
extern void message_command(char *arg, struct session *ses);
extern void snoop_command(char *arg, struct session *ses);
extern void speedwalk_command(char *arg, struct session *ses);
extern void system_command(char *arg, struct session *ses);
extern struct session *zap_command(struct session *ses);
extern void wizlist_command(struct session *ses);
extern void tablist(struct completenode *tcomplete);
extern void tabread(char *arg, struct session *ses);
extern void tabwrite(char *arg, struct session *ses);
extern void tab_add(char *arg);
extern void tab_delete(char *arg);
extern void display_info(struct session *ses);
extern void *mymalloc(size_t size);
extern void myfree(void *memblock);
extern void rndnum_command(char *arg, struct session *ses);
extern void winmap_command(char *arg, struct session *ses);
extern char mapbuf[10000];
extern int mapping;

/* net.c */

extern int connect_mud(char *host, char *port, struct session *ses);
extern HANDLE connect_async_mud(int port, int baud, int bits, int parity, int stop,
			  struct session * ses);
extern void write_line_mud(char *line, struct session *ses);
extern void async_write_line_mud(char *line, struct session *ses);
extern void telnet_write_line_mud(char *line, struct session *ses);
extern int read_buffer_mud(char *buffer, struct session *ses);
extern int async_read_buffer_mud(char *buffer, struct session *ses);
extern int telnet_read_buffer_mud(char *buffer, struct session *ses);
extern void do_telnet_protocol(unsigned char dat0, unsigned char dat1, unsigned char dat2, struct session *ses);
extern DWORD FAR PASCAL CommWatchProc(struct session * ses);

/* packet.c */

extern void parse_bpp_packet(void *Mud, char *bpp_packet[]);
extern void *alloc_mud_object();
extern void delete_mud_object(void *Mud);
extern void display_mud_object(void *Mud);


/* parse.c */

extern struct session *parse_input(char *input, struct session *ses);
extern int is_speedwalk_dirs(char *cp);
extern void do_speedwalk(char *cp, struct session *ses);
extern struct session *parse_tintin_command(char *command, char *arg, struct session *ses);
extern char *get_arg_all(char *s, char *arg);
extern char *get_arg_with_spaces(char *s, char *arg);
extern char *get_arg_in_braces(char *s, char *arg, int flag);
extern char *get_arg_stop_spaces(char *s, char *arg);
extern char *space_out(char *s);
extern void write_com_arg_mud(char *command, char *argument, struct session *ses);
extern void prompt(struct session *ses);

/* path.c */

extern void mark_command(struct session *ses);
extern void map_command(char *arg, struct session *ses);
extern void savepath_command(char *arg, struct session *ses);
extern void path_command(struct session *ses);
extern void return_command(struct session *ses);
extern void unpath_command(struct session *ses);
extern void check_insert_path(char *command, struct session *ses);
extern void pathdir_command(char *arg, struct session *ses);

/* session.c */

extern struct session *session_command(char *arg, struct session *ses);
extern void show_session(struct session *ses);
extern struct session *newactive_session(void);
extern struct session *new_session(char *name, char *address, struct session *ses);
extern struct session *new_async_session(char *name, char *address, struct session *ses);
extern void close_async(struct session *ses);
extern void cleanup_session(struct session *ses);

/* sound.c */

extern void sound_command(char *arg, struct session *ses);
extern void music_command(char *arg, struct session *ses);

/* substitu.c */

extern void parse_sub(char *arg, struct session *ses);
extern void unsubstitute_command(char *arg, struct session *ses);
extern int do_one_sub(char *line, struct session *ses);

/* text.c */

extern void read_file(char *arg, struct session *ses);

/* ticks.c */

extern void tick_command(struct session *ses);
extern void tickoff_command(struct session *ses);
extern void tickon_command(struct session *ses);
extern void tickset_command(char *arg, struct session *ses);
extern void ticksize_command(char *arg, struct session *ses);

/* utils.c */

extern int is_abrev(char *s1, char *s2);
extern char *mystrdup(char *s);
extern void syserr(char *msg);


/* variable.c */

extern void var_command(char *arg, struct session * ses);
extern void push_command(char *arg, struct session * ses);
extern void remove_command(char *arg, struct session * ses);
extern void select_command(char *arg, struct session * ses);
extern void unvar_command(char *arg, struct session *ses);
extern void substitute_myvars(char *arg, char *result, struct session *ses);
extern void tolower_command(char *arg, struct session *ses);
extern void toupper_command(char *arg, struct session *ses);
extern void match_command(char *line, struct session *ses);
extern void capture_command(char *line, struct session *ses);


/* 	C declarations in telnedoc.cpp */

extern int showstr(char *str, int handle);
extern int repline(char *str, int handle);
extern int setinsertpos(int type, int pos, int handle);
extern int newwindow(char *title);
extern HWND getmainwnd(void);
extern void closemainwindow(void);
extern HWND mainwnd(void);
extern void setcarethandle(int iHandle);
extern void winsockerrmsg(int nError, LPSTR pszError);
extern void messagebox(LPSTR pszMessage);
extern void paneltext(int, char*);
extern int winmapper(char *str);
extern int wininput(char *str);
extern void safe_tinchar(unsigned u);

