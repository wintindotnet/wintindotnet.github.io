/*********************************************************************/
/* file: net.c - do all the net stuff                                */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

#define ASCII_XON       0x11
#define ASCII_XOFF      0x13

/* This file massively modified for NT...
 */

/**************************************************/
/* try connect to the mud specified by the args   */
/* return fd on success / 0 on failure            */
/**************************************************/
int connect_mud(char *host, char *port, struct session *ses)
{
  int sock, connectresult, opt;
  struct sockaddr_in sockaddr;
  char errbuf[512];

  if (isdigit(*host))		/* interprete host part */
    sockaddr.sin_addr.s_addr = inet_addr(host);
  else
  {
    struct hostent *hp;

    if ((hp = gethostbyname(host)) == NULL)
    {
      tintin_puts("#ERROR - UNKNOWN HOST.", ses);
      prompt(NULL);
      return 0;
    }
    memcpy((char *) &sockaddr.sin_addr, hp->h_addr, sizeof(sockaddr.sin_addr));
  }

  if (isdigit(*port))
    sockaddr.sin_port = htons((u_short) atoi(port));	/* inteprete port part */
  else
  {
    tintin_puts("#THE PORT SHOULD BE A NUMBER.", ses);
    prompt(NULL);
    return 0;
  }

  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    winsockerrmsg(WSAGetLastError(), errbuf);
    messagebox(errbuf);
    syserr("socket");
  }

  sockaddr.sin_family = AF_INET;

  tintin_puts("#Trying to connect..", ses);

  connectresult = connect(sock, (struct sockaddr *) &sockaddr, sizeof(sockaddr));

  if (connectresult)
  {
    winsockerrmsg(WSAGetLastError(), errbuf);
    tintin_puts2(errbuf, NULL);
    prompt(NULL);
    return 0;
  }

  opt = 1;
  setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&opt, 1);

  //Get async notification of incoming data
  // FD_CLOSE added per Feng Chen

  if (WSAAsyncSelect(sock, getmainwnd(), WM_USER + 1, FD_READ|FD_CLOSE) == SOCKET_ERROR)
  {
    winsockerrmsg(WSAGetLastError(), errbuf);
    messagebox(errbuf);
    syserr("async select");
  }

  return sock;
}

HANDLE connect_async_mud(int port, int baud, int bits, int parity, int stop,
			 struct session * ses)
{
  HANDLE comhandle;
  char szPort[10];
  DCB dcb;
  int p, s;
  COMMTIMEOUTS CommTimeOuts;
  byte buf[128];
  DWORD error;

  sprintf(szPort, "COM%d", port);

  sprintf(buf, "#Connecting via %s at %d baud, %d-%c-%d...",
	  szPort, baud, bits, parity, stop);

  tintin_puts(buf, ses);

  if ((comhandle = CreateFile(szPort, GENERIC_READ | GENERIC_WRITE,
			      0,	//exclusive access
			       NULL,	//no security attrs
			       OPEN_EXISTING,
			      FILE_FLAG_OVERLAPPED,	//overlapped I / O
			       NULL)) == INVALID_HANDLE_VALUE)
  {
    DWORD dwError = GetLastError();

    switch (dwError)
    {
    case 2:
      sprintf(buf, "%s: Device not found.", szPort);
      break;

    case 5:
      sprintf(buf, "%s: Access is denied.", szPort);
      break;

    default:
      sprintf(buf, "Can't open %s: error %d.", szPort);
      break;
    }

    tintin_puts(buf, ses);

    return (0);
  }

  //get any early notifications

  if (!SetCommMask(comhandle, EV_RXCHAR))
  {
    messagebox("SetCommMask failed\n");
    CloseHandle(comhandle);
    return 0;
  }

  //set buffer sizes

  if (!SetupComm(comhandle, 4096, 4096))
  {
    messagebox("SetupComm failed\n");
    CloseHandle(comhandle);
    return 0;
  }

  dcb.DCBlength = sizeof(DCB);

  GetCommState(comhandle, &dcb);

  switch (parity)
  {
  case 'n':
  case 'N':
    p = NOPARITY;
    break;

  case 'e':
  case 'E':
    p = EVENPARITY;
    break;

  case 'o':
  case 'O':
    p = ODDPARITY;
    break;

  case 'm':
  case 'M':
    p = MARKPARITY;
    break;

  default:
    p = NOPARITY;
    break;
  }

  switch (stop)
  {
  case 1:
    s = ONESTOPBIT;
    break;

  case 15:
    s = ONE5STOPBITS;
    break;

  case 2:
    s = TWOSTOPBITS;
    break;

  default:
    s = ONESTOPBIT;
    break;
  }

  dcb.BaudRate = baud;
  dcb.ByteSize = bits;
  dcb.Parity = p;
  dcb.StopBits = s;

  //setup hardware flow control

  dcb.fOutxDsrFlow = 0;
  dcb.fDtrControl = DTR_CONTROL_ENABLE;

  dcb.fOutxCtsFlow = 1;
  dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;

  //setup software flow control

  dcb.fInX = dcb.fOutX = 0;
  dcb.XonChar = ASCII_XON;
  dcb.XoffChar = ASCII_XOFF;
  dcb.XonLim = 100;
  dcb.XoffLim = 10;

  //other various settings

  dcb.fBinary = TRUE;
  dcb.fParity = TRUE;

  if (!SetCommState(comhandle, &dcb))
  {
    messagebox("SetCommState failed\n");
    error = GetLastError();
    CloseHandle(comhandle);
    return 0;
  }

  //set up for overlapped non - blocking I / O

  CommTimeOuts.ReadIntervalTimeout = MAXDWORD;
  CommTimeOuts.ReadTotalTimeoutMultiplier = 0;
  CommTimeOuts.ReadTotalTimeoutConstant = 0;
  CommTimeOuts.WriteTotalTimeoutMultiplier = 0;
  CommTimeOuts.WriteTotalTimeoutConstant = 0;

  if (!SetCommTimeouts(comhandle, &CommTimeOuts))
  {
    messagebox("SetCommTimeouts failed\n");
    CloseHandle(comhandle);
    return 0;
  }

  //assert DTR

  if (!EscapeCommFunction(comhandle, SETDTR))
  {
    messagebox("EscapeCommFunction failed\n");
    CloseHandle(comhandle);
    return 0;
  }

  return comhandle;
}
/************************************************************/
/* write line to the mud ses is connected to - add \n first */
/************************************************************/
void write_line_mud(char *line, struct session *ses)
{
  switch (ses->comtype)
  {
  case ASYNC:
    async_write_line_mud(line, ses);
    break;

  case TELNET:
    telnet_write_line_mud(line, ses);
    break;

  default:
    break;
  }
}

void async_write_line_mud(char *line, struct session *ses)
{
  int fWriteStat;
  DWORD dwBytesWritten, len, error;

  len = strlen(line);
  line[len] = '\r';
  line[len + 1] = 0;

  fWriteStat = WriteFile(ses->asynchandle, line, len + 1,
			 &dwBytesWritten, ses->woverlap);

  line[len] = 0;

  error = GetLastError();

  if (!fWriteStat && (GetLastError() == ERROR_IO_PENDING))
  {
    //wait for a second for this transmission to complete

    if (WaitForSingleObject(ses->woverlap->hEvent, 1000)
	!= WAIT_OBJECT_0)
      dwBytesWritten = 0;
    else
      GetOverlappedResult(ses->asynchandle, ses->woverlap,
			  &dwBytesWritten, FALSE);
  }
}

void telnet_write_line_mud(char *line, struct session *ses)
{
  char outtext[BUFFER_SIZE + 2];
  char errbuf[512];

  strcpy(outtext, line);
  strcat(outtext, "\n");

  if (send(ses->socket, outtext, strlen(outtext), 0) == SOCKET_ERROR)
  {
    winsockerrmsg(WSAGetLastError(), errbuf);
    messagebox(errbuf);
    conn_has_closed = 1;
    return;
    //connection has shut down:clean up later
  }
}

/*******************************************************************/
/* read at most BUFFER_SIZE chars from mud - parse protocol stuff  */
/*******************************************************************/

int read_buffer_mud(char *buffer, struct session *ses)
{
  switch (ses->comtype)
  {
  case ASYNC:
    return async_read_buffer_mud(buffer, ses);
    break;

  case TELNET:
    return telnet_read_buffer_mud(buffer, ses);
    break;

  default:
    return 0;
    break;
  }
}

int async_read_buffer_mud(char *buffer, struct session *ses)
{
  DWORD dwLength, dwErrorFlags;
  COMSTAT ComStat;
  int fReadStat;

  ClearCommError(ses->asynchandle, &dwErrorFlags, &ComStat);

  dwLength = max(BUFFER_SIZE - 1, ComStat.cbInQue);

  if (dwLength > 0)
  {
    fReadStat = ReadFile(ses->asynchandle, buffer,
			 dwLength, &dwLength, ses->roverlap);
    if (!fReadStat)
    {
      if (GetLastError() == ERROR_IO_PENDING)
      {
	//wait for a second for this transmission to complete

	if (WaitForSingleObject(ses->roverlap->hEvent, 1000))
	  dwLength = 0;
	else
	  GetOverlappedResult(ses->asynchandle, ses->roverlap,
			      &dwLength, FALSE);
      }
      else
      {
	//some other error occurred

	dwLength = 0;
      }
    }
  }

  buffer[dwLength] = 0;

  //Clear 'posted notification' flag

  SetEvent(ses->postevent);

  return (int) dwLength;

}

int telnet_read_buffer_mud(char *buffer, struct session *ses)
{
  static int max = 0;
  int i, didget;
  unsigned char s2, s3;
  char tmpbuf[BUFFER_SIZE], *cpsource, *cpdest;
  char errbuf[512];

  didget = recv(ses->socket, tmpbuf, 1500, 0);
  ses->old_more_coming = ses->more_coming;

  if (didget == 1500)
    ses->more_coming = 1;
  else
    ses->more_coming = 0;

  if (didget > max)
    max = didget;
  //max is a debug variable to see how much
  // we ever swallow at once...
  if (didget < 0 && WSAGetLastError() != WSAEWOULDBLOCK)
  {
    winsockerrmsg(WSAGetLastError(), errbuf);
    messagebox(errbuf);
    conn_has_closed = 1;
    return 0;
//connection has shut down:clean up later
  }
  /*
   * we do this here instead - dunno quite why, but i got some mysterious
   * connection read by peer on some hps
   */

  else if (didget == 0)
  {
    conn_has_closed = 1;
    return 0;
  }
  else
  {
    cpsource = tmpbuf;
    cpdest = buffer;
    i = didget;
    while (i > 0)
    {
      if (*(unsigned char *) cpsource == 255)
      {
        s2 = *(unsigned char *) (cpsource + 1);
        s3 = *(unsigned char *) (cpsource + 2);

	      do_telnet_protocol(*cpsource, *(cpsource + 1), *(cpsource + 2), ses);

        if(s2 > 250 && s2 < 255)
        {
	        i -= 3;
	        cpsource += 3;
        }
        else if(s2 != 255)
        {
	        i -= 2;
	        cpsource += 2;
        }
      }
      else
      {
	if (*cpsource)
	  *cpdest++ = *cpsource++;
	else
	{
	  *cpdest++ = ' ';
	  cpsource++;
	}

	i--;
      }
    }
    *cpdest = '\0';
  }

  return didget;
}

/*****************************************************************/
/* respond according to the telnet protecol - weeeeelllllll..... */
/*****************************************************************/
void do_telnet_protocol(unsigned char dat0, unsigned char dat1, unsigned char dat2, struct session *ses)
{
  unsigned char outtext[10];
  char errbuf[200];

  // respond WONT to DO, DONT to WILL

  outtext[0] = 255;
  outtext[1] = 0;
  outtext[2] = dat2;
  outtext[3] = 0;

  if(dat1 == 253) // DO
  {
    outtext[1] = 252;
  }
  else if(dat1 == 251) // WILL
  {
    outtext[1] = 254;
  }
  
  if(outtext[1])
  {
    if (send(ses->socket, outtext, strlen(outtext), 0) == SOCKET_ERROR)
    {
      winsockerrmsg(WSAGetLastError(), errbuf);
      messagebox(errbuf);
      conn_has_closed = 1;
      return;
      //connection has shut down:clean up later
    }
  }
}
//Thread to monitor rx queue

DWORD FAR PASCAL CommWatchProc(struct session *ses)
{
  DWORD dwTransfer, dwEvtMask;
  OVERLAPPED os;

  memset(&os, 0, sizeof(OVERLAPPED));

  //create I / O event used for overlapped read

  os.hEvent = CreateEvent(NULL,	//no security
			   TRUE,	//explicit reset req
			   FALSE,	//initial event reset
			   NULL);
  //no name
  if (os.hEvent == NULL)
    return (FALSE);

  if (!SetCommMask(ses->asynchandle, EV_RXCHAR))
    return (FALSE);

  while (ses->comtype == ASYNC)
  {
    dwEvtMask = 0;

    if (!WaitCommEvent(ses->asynchandle, &dwEvtMask, &os))
    {
      if (ERROR_IO_PENDING == GetLastError())
      {
	GetOverlappedResult(ses->asynchandle, &os, &dwTransfer, TRUE);
	os.Offset += dwTransfer;
      }
    }

    if (ses->comtype == ASYNC && (dwEvtMask & EV_RXCHAR) == EV_RXCHAR)
    {
      //wait for "posted notification" flag to clear

      WaitForSingleObject(ses->postevent, 0xFFFFFFFF);

      //reset event

      ResetEvent(ses->postevent);

      //last message was processed, O.K.to post

      PostMessage(ses->hmainwind, WM_COMMNOTIFY, (WPARAM) ses, 0L);

    }
  }

  //get rid of event handle

  CloseHandle(os.hEvent);
  ses->commthreadid = 0;
  ses->hcommthread = 0;

  return TRUE;

}
