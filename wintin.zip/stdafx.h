// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifdef __cplusplus
#include <afx.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC OLE automation classes
#include <afxpriv.h>
#include <afxcmn.h>
#include <afxtempl.h>
#else
#include "forcelib.h"
#endif
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <winsock2.h>
#include <io.h>
#include <time.h>
#include <sys/types.h>
#include <vfw.h>

#ifdef __cplusplus
extern "C"
{
#endif
#include "tintin.h"
#include "tindecl.h"
#ifdef __cplusplus
}
#endif
