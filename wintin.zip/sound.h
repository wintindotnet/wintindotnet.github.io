/*  Declarations for sound/msp support 

    WL 4/10/99
    
*/


/* This structure is used to describe the currently
   playing sound or music effect */

struct effect
{
  char fname[1024];
  int vol;
  int repeats;        /* repeats left */
  int priority;
  int cont;
  char type[1024];
  char url[1024];
  int active;         /* 1 if the effect is playing, 0 otherwise */
};



extern int msp_active;
extern void process_msp(char *buf);