//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TELNET.RC
//
#define IDR_MAINFRAME                   2
#define IDCLOSE3                        10
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_DIALOG1                     101
#define IDC_PORT                        101
#define IDC_ADDRESS                     102
#define IDC_TREE                        102
#define IDD_EDITVIEW                    102
#define ID_INDICATOR_TIME               103
#define IDD_CONTENT_PAGE                103
#define IDC_EDIT_VALUE                  104
#define IDD_CONNECT                     104
#define ID_INDICATOR_1                  104
#define IDC_EDIT_NAME                   105
#define IDD_WRAPLENGTH                  105
#define ID_INDICATOR_2                  105
#define IDNEW                           106
#define IDD_SOUND_OPTIONS               106
#define ID_INDICATOR_3                  106
#define IDC_SESSION                     107
#define IDD_ANSICOLOUR                  107
#define IDDELETE                        108
#define IDC_CONTENT_LIST                109
#define IDC_MUD_ADDRESS                 110
#define IDC_MUD_PORT                    111
#define IDC_EDIT1                       111
#define IDC_MSP_ENABLED                 112
#define IDC_ALLOW_TELLS                 113
#define IDC_DISPLAY_DEBUG               114
#define IDC_SOUND_PATH                  115
#define IDC_COLOR                       117
#define IDC_CHANGE_COLOR                118
#define IDC_TEXT_ORD                    121
#define IDR_TELNETTYPE                  129
#define ID_EDIT_SAVETOFILE              32768
#define ID_VIEW_COLOUR                  32769
#define ID_VIEW_COLOR                   32771
#define ID_VIEW_TEXT_COLOR              32773
#define ID_VIEW_BACKGROUNDCOLOR         32774
#define ID_VIEW_FONT                    32775
#define ID_VIEW_DEFINITIONS             32776
#define ID_VIEW_SMART                   32777
#define ID_FILE_CONNECT                 32778
#define ID_VIEW_WRAP                    32779
#define ID_EDIT_SELECTALL               32780
#define ID_VIEW_MSP                     32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         124
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
