// telnevw.cpp : implementation of the CTelnetView class
//

#include "stdafx.h"
							   
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "telnevw.h"
#include "TinEditView.h"
#include "ascii.h"
#include "enhstr.h"
#include "colorstate.h"
#include "mspoptions.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

extern "C" void tinchar(unsigned);
extern "C" int tinspecchar(char *);
extern "C" void   displaysmartmud();

/////////////////////////////////////////////////////////////////////////////
// CTelnetView

IMPLEMENT_DYNCREATE(CTelnetView, CScrollView)

BEGIN_MESSAGE_MAP(CTelnetView, CScrollView)
	//{{AFX_MSG_MAP(CTelnetView)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_WM_PAINT()
	ON_COMMAND(ID_EDIT_SAVETOFILE, OnEditSavetofile)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SAVETOFILE, OnUpdateEditSavetofile)
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_COMMAND(ID_VIEW_DEFINITIONS, OnViewDefinitions)
	ON_COMMAND(ID_VIEW_SMART, OnViewSmart)
	ON_WM_SYSKEYDOWN()
	ON_COMMAND(ID_EDIT_SELECTALL, OnEditSelectall)
	ON_WM_CHAR()
	ON_COMMAND(ID_VIEW_MSP, OnViewMsp)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTelnetView construction/destruction

CTelnetView::CTelnetView()
{
	hFont = ((CTelnetApp *)AfxGetApp())->hfont;
	bHighlight = FALSE;
	bMouseTracking = FALSE;
}

CTelnetView::~CTelnetView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CTelnetView drawing

void CTelnetView::OnInitialUpdate()
{
  TEXTMETRIC   tm;
  OSVERSIONINFO info;
  int iMaxLines;

	CClientDC dc(this);
	dc.SetMapMode(MM_LOENGLISH);
  dc.SelectObject(hFont);
  dc.GetTextMetrics(&tm);

  xChar = tm.tmMaxCharWidth;
  yChar = tm.tmHeight + tm.tmExternalLeading;


	// need to calc max lines for buffer

	POINT p;
	p.x = 0;
	p.y = yChar;
  //	dc.LPtoDP(&p);

  info.dwOSVersionInfoSize  = sizeof(info);
  GetVersionEx(&info);

  // in windows 95 and 98 the screen coordinates are limited to 32k or less.
  // in NT the limit is 2 gig. We set the number of lines as high as
  // we can in Windows, and a lot higher in NT.

  if(info.dwPlatformId == VER_PLATFORM_WIN32_NT)
	  iMaxLines = 200000;
  else
	  iMaxLines = 24000/p.y;

	CTelnetDoc* pDoc = GetDocument();
	pDoc->ScreenBuffer.SetMaxLines(iMaxLines);

 	SetSize();

}

void CTelnetView::OnDraw(CDC* pDC)
{
	int iVertPos, iCount, iPaintRow, iEndRow;
   	RECT rect ;
	CString *pcs;
	CSize cs;

	CTelnetDoc* pDoc = GetDocument();
   	
	pDC->GetClipBox(&rect);

	// set default colours

	pDC->SetBkColor(((CTelnetApp *)AfxGetApp())->backcolor);
	pDC->SetTextColor(((CTelnetApp *)AfxGetApp())->textcolor);

	// clear it out to get rid of scroll crap

	CBrush cbw;
	cbw.CreateSolidBrush(((CTelnetApp *)AfxGetApp())->backcolor);
	pDC->FillRect(&rect, &cbw);
	
	// Find offset on screen of first and last row to draw

	iPaintRow = rect.top/yChar*(-1);		// mapping mode sign change  
	iEndRow = rect.bottom/yChar*(-1);

	// Set starting point in screen buffer

	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, iPaintRow);

	// Draw the lines

   	for (; iPaintRow <= iEndRow; iPaintRow++)
   	{
		pcs = pDoc->ScreenBuffer.GetCurrent();
		
//		TRACE(*pcs);
//		TRACE("\n");

		if(pcs == NULL)
			break;
		
		iCount = pcs->GetLength();
		
      	iVertPos = iPaintRow*yChar*(-1);
      	rect.top = iVertPos;
      	rect.bottom = iVertPos + yChar*(-1);

		// check for ANSI escape sequences

		if(pcs->Find("\x1b[") < 0)
		{
	      	pDC->ExtTextOut(0, iVertPos, ETO_OPAQUE | ETO_CLIPPED, &rect,
                   pcs->GetBuffer(1), iCount, NULL);
		}
		else
		{
			AnsiTextOut(pDC, 0, iVertPos, ETO_OPAQUE | ETO_CLIPPED, pcs);
		}

		if(!pDoc->ScreenBuffer.SetCurrentLine(SBCURR, 1))
			break;
   	}
   
   	// Check for highlighting 
   
   	if(bHighlight)
   	{   
   		CRgn crg;
		CalcScrHighlightRgn(&crg);
   		
		pDC->GetClipBox(&rect);
		pDC->LPtoDP(&rect);
		
		if(crg.RectInRegion(&rect))
		{
			// Switch fg and bg colours in affected region

			int i = crg.GetRegionData(NULL, 0);
			RGNDATA *rd = (RGNDATA *) new char[i];
			crg.GetRegionData(rd, i);
			RECT *pr = (LPRECT) rd->Buffer;
			CRect crect;

			for(i=0; i<(int)rd->rdh.nCount; i++)
			{
				crect = pr[i];
				pDC->DPtoLP(&crect);
				pDC->InvertRect(&crect);
			}

			delete rd;
		}
		
		// Delete the region
		
		crg.DeleteObject();
	}	      
}

// Display line with ANSI graphics formatting
// In this implementation I've simplified things by not allowing the formatting
// to spill over one line and by ignoring any selection highlighting issues
// The ScreenBuffer class makes sure that ansi sequences are carried over
// line boundaries by repeating them as necessary.

void CTelnetView::AnsiTextOut(CDC *pDC, int x, int y, UINT nOptions, CString* pcStr)
{
	CString csCopy, csPrint, csTemp;
	int iPos, iCount, i;
	int iCurPos = 0;
	int iCurX = x;
	int bold, pri;
	RECT rect;
	int p0, p1, p2;
	int pp0, pp1, pp2;
	ColorState cs;

	p0 = p1 = p2 = pp0 = pp1 = pp2 = 98;	// initialise to a do-nothing value

	pDC->GetClipBox(&rect);
	pDC->SetBkColor(((CTelnetApp *)AfxGetApp())->backcolor);
	pDC->SetTextColor(((CTelnetApp *)AfxGetApp())->textcolor);

	csCopy = pcStr->GetBuffer(1);

	while(!csCopy.IsEmpty())
	{
		iPos = csCopy.Find("\x1b[");
		
		if(iPos > 0 || iPos < 0)
		{
			// emit anything before the escape sequence with the current brush

			if(iPos < 0)
				iPos = csCopy.GetLength();	//fudge to get all of string into csTemp

			csPrint = csCopy.Left(iPos);
		
			iCount = csPrint.GetLength();

	    rect.top = y;
    	rect.bottom = y - yChar;
			rect.left = iCurX;
  
			CSize cs = pDC->GetTextExtent(csPrint.GetBuffer(1), iCount);
			rect.right = rect.left + cs.cx;
			pDC->ExtTextOut(iCurX, y, nOptions, &rect, csPrint.GetBuffer(1), iCount, NULL);

			iCurX = rect.right;

			// truncate the string

			csCopy = csCopy.Mid(iCount);
		}
		else
		{
			// parse the escape sequence and change brush

			i = cs.CrackAnsi(csCopy);

			if(!i)
			{
				csCopy = csCopy.Mid(1);
				continue;			// not an ANSI colour sequence: emit, but without Esc at beginning
			}

			// strip out from text

			csCopy = csCopy.Mid(csCopy.Find('m')+1);

			bold = 0;
			pri = 200;

			if(cs.Bold)
			{
				pri = 255;
				bold = 100;
			}

			if(cs.Light)
			{
				pri = 255;
			}

			if(cs.Reset)
			{
				pDC->SetBkColor(((CTelnetApp *)AfxGetApp())->backcolor);
				pDC->SetTextColor(((CTelnetApp *)AfxGetApp())->textcolor);
			}

			pDC->SetBkColor(((CTelnetApp *)AfxGetApp())->backcolor);

			switch(cs.Fore)
			{
			case 30:	pDC->SetTextColor(RGB(bold, bold, bold));			// black
						break;
			case 31:	pDC->SetTextColor(RGB(pri, bold, bold));			// red
						break;
			case 32:	pDC->SetTextColor(RGB(bold, pri, bold));			// green
						break;
			case 33:	pDC->SetTextColor(RGB(pri, pri, bold));		// yellow
						break;
			case 34:	pDC->SetTextColor(RGB(bold, bold, pri));			// blue
						break;
			case 35:	pDC->SetTextColor(RGB(pri, bold, pri));		// magenta
						break;
			case 36:	pDC->SetTextColor(RGB(bold, pri, pri));		// cyan
						break;
			case 37:	pDC->SetTextColor(RGB(pri, pri, pri));		// white
						break;

			default:
						break;								
			}

			switch(cs.Back)
			{
			case 40:	pDC->SetBkColor(RGB(0, 0, 0));				// black
						break;
			case 41:	pDC->SetBkColor(RGB(1, 0, 0));			// red
						break;
			case 42:	pDC->SetBkColor(RGB(0, 1, 0));			// green
						break;
			case 43:	pDC->SetBkColor(RGB(1, 1, 0));			// yellow
						break;
			case 44:	pDC->SetBkColor(RGB(0, 0, 1));			// blue
						break;
			case 45:	pDC->SetBkColor(RGB(1, 0, 1));			// magenta
						break;
			case 46:	pDC->SetBkColor(RGB(0, 1, 1));			// cyan
						break;
			case 47:	pDC->SetBkColor(RGB(1, 1, 1));		// white
						break;

			default:
						break;								
			}		
		}
	}

	// back to sanity
	pDC->SetBkColor(((CTelnetApp *)AfxGetApp())->backcolor);
	pDC->SetTextColor(((CTelnetApp *)AfxGetApp())->textcolor);
} 

/////////////////////////////////////////////////////////////////////////////
// CTelnetView printing

BOOL CTelnetView::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}

void CTelnetView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{

}

void CTelnetView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTelnetView diagnostics

#ifdef _DEBUG
void CTelnetView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTelnetView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CTelnetDoc* CTelnetView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTelnetDoc)));
	return (CTelnetDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTelnetView message handlers
void CTelnetView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	safe_tinchar(nChar);
}

void CTelnetView::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);

	GetClientRect(crClientRect);
}


void CTelnetView::SetSize()
{   	
	CClientDC dc(this);
//	OnPrepareDC(&dc);
	dc.SetMapMode(MM_LOENGLISH);
  	dc.SelectObject(hFont);
	CRect lClientRect = crClientRect;

	dc.DPtoLP(&lClientRect);
	
   	SIZE sizeTotal, sizePage, sizeLine;
	CTelnetDoc* pDoc = GetDocument();

   	sizeTotal.cx = 120*xChar;
   	sizeTotal.cy = yChar*(int)pDoc->ScreenBuffer.Range() + yChar/4;              
   	          
   	sizePage.cx = 10*xChar;          
   	sizePage.cy = lClientRect.top-lClientRect.bottom+yChar;
   	
   	sizeLine.cx = xChar;
   	sizeLine.cy = yChar;

   	SetScrollSizes(MM_LOENGLISH, sizeTotal, sizePage, sizeLine);
/*
	CEnhString cs;
	cs.printf("total: %d  page: %d  line: %d\n", sizeTotal.cy, sizePage.cy, sizeLine.cy);
	TRACE(cs);
  */	
}

void CTelnetView::OnSetFocus(CWnd* pOldWnd)
{
	CScrollView::OnSetFocus(pOldWnd);

	// if this is the WinTin window, show the caret
	
	HaveCaret = 0;
	
	CDocument *pdoc = GetDocument();

	if(pdoc != ((CTelnetApp*)AfxGetApp())->GetDocument(((CTelnetApp*)AfxGetApp())->iCaretHandle))
		return;

	POSITION pos = pdoc->GetFirstViewPosition();

	if(pos != NULL && (CTelnetView*)(pdoc->GetNextView(pos)) != this)
		return;


	HaveCaret = 1;
	
	CreateSolidCaret(8,8);
	SetCaret();
	ShowCaret( );
}

void CTelnetView::OnKillFocus(CWnd* pNewWnd)
{
	CScrollView::OnKillFocus(pNewWnd);

	HaveCaret = 0;
	DestroyCaret();
}

void CTelnetView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CScrollView::OnLButtonDown(nFlags, point);   
	
	if(nFlags&MK_SHIFT)
	{
		// extend highlighted region, if any, by modifying cpH2
		
		if(!bHighlight)
			return;
			
		// Cancel any outstanding highlight
	
		if(bHighlight)
		{
			bHighlight = FALSE;
			InvalidateHighlight();
		}                          
		
		MarkHighlightRegion(point);
	}
	else
	{		
		// Cancel any outstanding highlight
		
		if(bHighlight)
		{
			bHighlight = FALSE;
			InvalidateHighlight();
		}
		
		// Store point (in logical units)
		
		StorePoint(&point, &cpH1);
	
		// Capture mouse and note we are tracking
	
		bMouseTracking = TRUE;	                     
		SetCapture();
	}	
}
	

void CTelnetView::OnLButtonUp(UINT nFlags, CPoint point)
{   
	CScrollView::OnLButtonUp(nFlags, point);

	// ignore if we're not tracking

	if(!bMouseTracking)
		return;
	
	// Cancel timer if running
	
    if(nTimer)
    {                  
		KillTimer(nTimer);	
		nTimer = 0;
	}	

	if(!crClientRect.PtInRect(point))
	{
		// Cancel any outstanding highlight
	
		if(bHighlight)
		{
			bHighlight = FALSE;
			InvalidateHighlight();
		}	                   
	}
	else
		MarkHighlightRegion(point);
		
	ReleaseCapture();
	bMouseTracking = FALSE;
}

void CTelnetView::OnMouseMove(UINT nFlags, CPoint point)
{
	CScrollView::OnMouseMove(nFlags, point);
	
	cpMousePos = point;
	
	// See if we are tracking
	
	if(!bMouseTracking)
		return;

	// Check whether we are in client area
	
	if(!crClientRect.PtInRect(point))
	{
		DoMouseMove(&point);

	    // Set timer for repeats, unless it's already going
	    
	    if(!nTimer)
	    	nTimer = SetTimer(1, 200, NULL);
	}
	else
	{
		// Disable timer, if actice
	                      
	    if(nTimer)
	    {                  
			KillTimer(nTimer);	
			nTimer = 0;
		}	
	}

	MarkHighlightRegion(point);
}


// Convert a point to logical co-ords, trim to character boundary and store

void CTelnetView::StorePoint(const CPoint *cpsource, CPoint *cptarg)	
{
	// Get a device context to use for mapping co-ords
	
	CClientDC dc(this);
	OnPrepareDC(&dc);

	// Store point in cpH1 and convert to logical
	
	*cptarg = *cpsource;
	dc.DPtoLP(cptarg);
	AdjustPoint(cptarg);
}

 
// Adjust point to boundary of nearest character
// Use logical co-ords to ensure we hit a character boundary whatever the scroll position
 
void CTelnetView::AdjustPoint(CPoint *cp)
{
	int i;
	CSize cs;

	CClientDC dc(this);
	OnPrepareDC(&dc);
  	dc.SelectObject(hFont);

	CTelnetDoc* pDoc = GetDocument();
	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, cp->y/yChar*(-1));
	CString* pcs = pDoc->ScreenBuffer.GetCurrent();
	char *pcBuf = pcs->GetBuffer(1);

	for(i=0; pcBuf[i]; i++)
	{
		cs = dc.GetTextExtent(pcBuf, i);

		if(cp->x - cs.cx < xChar)
			break;
	}

	// check if we were past the end of the line

	if(cp->x - cs.cx > xChar)
		cs.cx += xChar;

	cp->x = cs.cx;
	cp->y = (cp->y/yChar)*yChar;
}
                                                

// Invalidate rectangle currently occupied by highlighted text

void CTelnetView::InvalidateHighlight()
{
	CRect cr;

	CClientDC dc(this);
	OnPrepareDC(&dc);
	
	cr.left = 0;
	cr.right = 120*xChar;
	cr.top = max(cpH1.y, cpH2.y);
	cr.bottom = min(cpH1.y-yChar, cpH2.y-yChar);
	
	dc.LPtoDP(&cr);	
	InvalidateRect(&cr);
}

// Calculate region (in screen co-ords)  occupied by highlighted text
                                                
void CTelnetView::CalcScrHighlightRgn(CRgn *pcrg)
{
	CPoint cp1, cp2, cp3;
		
	CClientDC dc(this);
	OnPrepareDC(&dc);

	cp1 = cpH1;
	cp2 = cpH2;

	// Get the points the right way round 
	
	if(cp1.y < cp2.y)
	{
		cp3 = cp1;
		cp1 = cp2;
		cp2 = cp3;		
	}

	// There are potentially three parts to the region:
	// starting line, ending line, and the lines in between.
	// All of these are rectangles.
	
	CRect crStart, crEnd, crBetween;
	
	// Starting rect always exists
	
	crStart.top = cp1.y;
	crStart.bottom = crStart.top - yChar;
	
	// See whether the region continues over more than one line
	
	if(cp1.y != cp2.y)
	{
		crStart.left = cp1.x;
	    crStart.right = 120*xChar;
	}    
	else
	{
		crStart.left = min(cp1.x, cp2.x);
		crStart.right = max(cp1.x, cp2.x);	
	}	
	
	// Add starting rect to highlight region
	
	dc.LPtoDP(&crStart);
	pcrg->CreateRectRgnIndirect(crStart);           
	
	// Ending region exists if highlight covers > 1 line
	
	if(cp2.y != cp1.y)
	{
		crEnd.top = cp2.y+1;			// for rounding errors
		crEnd.bottom = cp2.y - yChar;
		crEnd.left = 0;
		crEnd.right = cp2.x;
		
		// Add to highlight region

		dc.LPtoDP(&crEnd);		
		CRgn crt;
		crt.CreateRectRgnIndirect(crEnd);
		pcrg->CombineRgn(pcrg, &crt, RGN_OR);
		crt.DeleteObject();
	}	                   
	
	// Between region exists if there is anything in between
	// nudge it up a little to avoid rounding errors
	
	if(cp1.y - cp2.y > yChar)
	{
		crBetween.bottom = cp2.y - 1;
		crBetween.top = cp1.y - yChar + 1;
		crBetween.left = 0;
		crBetween.right = 120*xChar;
		
		// Add to highlight region
		
		dc.LPtoDP(&crBetween);
		CRgn crt;
		crt.CreateRectRgnIndirect(crBetween);
		pcrg->CombineRgn(pcrg, &crt, RGN_OR);
		crt.DeleteObject();   
	}	                   
}

//	Scroll in the direction of the cursor, which is outside the client area
//  'point' gets adjusted to be within client area

void CTelnetView::DoMouseMove(CPoint *point)
{
	CPoint cpScrollPos = GetScrollPosition();
		
	// Modify cpScrollPos depending on where we are
		
	if(point->x < crClientRect.left)                      
	{
		cpScrollPos.x = max(0, cpScrollPos.x - xChar);
		point->x = crClientRect.left;
	}
	else if(point->x > crClientRect.right)
	{
		cpScrollPos.x += xChar;
		point->x = crClientRect.right;
	}
		
	if(point->y < crClientRect.top)
	{
		cpScrollPos.y = min(0, cpScrollPos.y + yChar);
		point->y = crClientRect.top;
	}
	else if(point->y > crClientRect.bottom)
	{
		cpScrollPos.y -= yChar;
		point->y = crClientRect.bottom;
	}
		            
	ScrollToPosition(cpScrollPos);
}                           


// Timer event is used to keep scrolling a window when the user is dragging
// a selection and the mouse is outside the client area

void CTelnetView::OnTimer(UINT nIDEvent)
{
	CScrollView::OnTimer(nIDEvent);
	
	// Check for mouse scrolling
	
	CPoint point = cpMousePos;
	
	if(bMouseTracking && !crClientRect.PtInRect(point))
	{
		DoMouseMove(&point);
		MarkHighlightRegion(point);
	}	
}

//	Store the end of the highlight region, and display it

void CTelnetView::MarkHighlightRegion(CPoint point)
{   
	// Check whether we are in client area
	
	if(bHighlight)
	{
		// calc region which has changed, and invalidate it

		CRgn OldRgn, NewRgn;

		CalcScrHighlightRgn(&OldRgn);
		StorePoint(&point, &cpH2);
		CalcScrHighlightRgn(&NewRgn);

		NewRgn.CombineRgn(&OldRgn, &NewRgn, RGN_XOR);
		InvalidateRgn(&NewRgn);
	}
	else
	{
		StorePoint(&point, &cpH2);
		InvalidateHighlight();
	}

	bHighlight = (cpH1 != cpH2);
	UpdateWindow();
}

// Find character-based indexes of first and last points in hghlight region

void CTelnetView::FindHighlightRegion(RECT *pr)
{
   	TEXTMETRIC   tm;
	CClientDC dc(this);
	OnPrepareDC(&dc);
	dc.SelectObject(hFont);
  	dc.GetTextMetrics(&tm);

  	int xmChar = tm.tmMaxCharWidth/4;

	CTelnetDoc* pDoc = GetDocument();
 	
 	// Find indexes of first and last row to draw

	pr->top = cpH1.y/yChar*(-1);
	pr->bottom = cpH2.y/yChar*(-1);

	// Find indexes of first and last chars

	int i;
	CSize cs;
	CString *pcs;

	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, pr->top);
	pcs = pDoc->ScreenBuffer.GetCurrent();
	char *pcBuf = pcs->GetBuffer(1);
	
	for(i=0; pcBuf[i]; i++)
	{
		cs = dc.GetTextExtent(pcBuf, i);

		if(cs.cx + xmChar/2 > cpH1.x)
			break;
	}

	pr->left = i;

	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, pr->bottom);
	pcs = pDoc->ScreenBuffer.GetCurrent();
	pcBuf = pcs->GetBuffer(1);

	for(i=0; pcBuf[i]; i++)
	{
		cs = dc.GetTextExtent(pcBuf, i);

		if(cs.cx + xmChar/2 > cpH2.x)
			break;
	}

	pr->right = i;

	// Get points the right way around

	if(pr->top > pr->bottom)
	{
		i = pr->top;
		pr->top = pr->bottom;
		pr->bottom = i;

		i = pr->left;
		pr->left = pr->right;
		pr->right = i;
	}
	else if(pr->top == pr->bottom && pr->right < pr->left)
	{
		i = pr->left;
		pr->left = pr->right;
		pr->right = i;
	}
}

// Copy highlighted text to the clipboard
                                   
void CTelnetView::OnEditCopy()
{         
	if(!bHighlight)
		return;
		
	if(!OpenClipboard())
		return;
		
	if(!EmptyClipboard())
	{
		CloseClipboard();
		return;
	}
	
	int iRow;
	RECT r;
	int iTotalChars = 0;                                       
	int iEnd = 0;
	CTelnetDoc* pDoc = GetDocument();
	CEnhString cscopy;

	FindHighlightRegion(&r);
	
	// Loop over highlighted chars to calc required size of buffer
	
	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, r.top);

   	for (iRow=r.top; iRow <= r.bottom; iRow++)
   	{
		cscopy = *(pDoc->ScreenBuffer.GetCurrent());
//#ifndef _DEBUG
		cscopy.StripAnsi();
//#endif

    	if(iRow == r.top && iRow == r.bottom)
    	{
    		iTotalChars += r.right-r.left;
    	}
    	else if(iRow == r.top)
    	{
    		iTotalChars += cscopy.GetLength()-r.left;
    	}	
    	else if(iRow == r.bottom)
    	{
    		iTotalChars += r.right;	
    	}
    	else
		{
		    iTotalChars += cscopy.GetLength();
		}                                 
		
		if(iRow != r.bottom)
			iTotalChars += 2;
		
		if(!pDoc->ScreenBuffer.SetCurrentLine(SBCURR, 1))
			break;
	}
	
	// Allocate some far memory
	
	HGLOBAL hg;
	char FAR *gb;

	hg = GlobalAlloc(GMEM_MOVEABLE|GMEM_DDESHARE, iTotalChars+1);  // +1 for trailing zero
	
	if(hg == NULL)
	{
		CloseClipboard();
		return;
	}
		
	gb = (char *) GlobalLock(hg);   // we are in large model...
	
	if(gb == NULL)
	{
		CloseClipboard();
		return;
	}
		
	// Go back and get the characters	

	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, r.top);
	
   	for (iRow=r.top; iRow <= r.bottom; iRow++)
   	{
		cscopy = *(pDoc->ScreenBuffer.GetCurrent());

//#ifndef _DEBUG
		cscopy.StripAnsi();
//#endif
    	
    	if(iRow == r.top && iRow == r.bottom)
    	{
    		// Selection just on one line
    		
    		cscopy = cscopy.Mid(r.left, r.right-r.left);
    	}
    	else if(iRow == r.top)
        {
    	    cscopy = cscopy.Right(cscopy.GetLength()-r.left);
    	}	
    	else if(iRow == r.bottom)
		{
		    cscopy = cscopy.Left(r.right);
		}
		
		strcpy(&gb[iEnd], cscopy);                        

		if(iRow != r.bottom)
			strcat(&gb[iEnd], "\r\n");

		iEnd += strlen(&gb[iEnd]);

		if(!pDoc->ScreenBuffer.SetCurrentLine(SBCURR, 1))
			break;
	}                                    
	
	// Set the data 
	
	GlobalUnlock(hg);
	
	SetClipboardData(CF_TEXT, hg);
	CloseClipboard();

	// Remove the highlight

	bHighlight = FALSE;
	InvalidateHighlight();
}


void CTelnetView::OnEditPaste() 
{
	if(!OpenClipboard())
		return;
		
 	HGLOBAL hg = GetClipboardData(CF_TEXT);
	char *gb = (char *) GlobalLock(hg);   // we are in large model...

	if(gb == NULL)
	{
		CloseClipboard();
		return;
	}

	while(*gb)
	{
		if(*gb != '\n')
			safe_tinchar(*gb);					// pump the clipboard through tinchar

		if(*gb == '\r')
		{
			MSG Message;
			while(PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&Message);
				DispatchMessage(&Message);
			}
		}

		gb++;
	}

	GlobalUnlock(hg);
	CloseClipboard();
}
                               

void CTelnetView::OnUpdateEditCopy(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(bHighlight);
}


/*
 * Scroll up one if at bottom of the screen
 */

void CTelnetView::ScrollUp(int lines)
{
	RECT rect;
	int range;
	
	CClientDC dc(this);
	OnPrepareDC(&dc);

	CPoint cpDepth;
	cpDepth.x = 0;
	cpDepth.y = crClientRect.bottom-crClientRect.top;
	dc.DPtoLP(&cpDepth);

	// remember current size of scroll buffer

	CSize OldSize = GetTotalSize();
	
	// (sigh) need to find whether we are at bottom of screen
	
	CPoint cpt = GetScrollPosition();
	CTelnetDoc *pDoc = (CTelnetDoc*) GetDocument();
	
	range = (int)pDoc->ScreenBuffer.Range();
    		
	if((cpDepth.y/yChar - 2 - lines) <= 0-range)
	{		                 
		SetSize();

		CSize ScrollSize = GetTotalSize();
		cpt.y = 0 - ScrollSize.cy;		// this will always stuff us at the end
		ScrollToPosition(cpt);
		UpdateWindow();
		OnPrepareDC(&dc);
	}
	else
	{
		SetSize();
		OnPrepareDC(&dc);		// size has changed
	}

	// check to see if scroll buffer has purged

	CSize NewSize = GetTotalSize();
	rect.bottom = 0 - NewSize.cy;
	rect.left = 0;
	rect.right = 0;

	if(NewSize.cy < OldSize.cy)	
		rect.top = 0;		   // it's purged
	else
		rect.top = rect.bottom + yChar*(lines + 2);

	dc.LPtoDP(&rect);

	rect.right = crClientRect.right;
	InvalidateRect(&rect);
	UpdateWindow();

	if(HaveCaret)
		SetCaret();
}


void CTelnetView::InvalidateLastChar(int nchars)	// nchars = number to invalidate
{
	CRect cRect;
	CTelnetDoc* pDoc = GetDocument();	
	CClientDC dc(this);
	OnPrepareDC(&dc);
   	dc.SelectObject(hFont);

	// Calculate rectangle to update

   	cRect.top = 0-yChar*(int)(pDoc->ScreenBuffer.GetInsertLine());
	cRect.bottom = cRect.top-yChar;
	pDoc->ScreenBuffer.SetCurrentLine(SBEND, 0);
	CEnhString cstr = *(pDoc->ScreenBuffer.GetCurrent());

	// strip ANSI colour sequences, adjust insert pos to compensate
	
	cstr.Left(pDoc->ScreenBuffer.GetInsertPos());
	cstr.StripAnsi();

	// check we aren't invalidating more than we actually have (cos of ansi codes etc)

	if(nchars > cstr.GetLength())
		nchars = cstr.GetLength();

	CSize cs = dc.GetTextExtent(cstr.GetBuffer(1), cstr.GetLength());
	cRect.right = cs.cx;

	cs = dc.GetTextExtent((cstr.Right(nchars)).GetBuffer(1), nchars);
	cRect.left = cRect.right - cs.cx;

	// make it a lot bigger to see if this clears win 95 problem

	cRect.left = max(0, cRect.left - xChar);
	cRect.right += xChar;

	dc.LPtoDP(&cRect);
/*
	cstr.printf("Inv: left %d right %d top %d bottom %d\n",
				cRect.left, cRect.right, cRect.top, cRect.bottom);
	TRACE(cstr);
*/
	InvalidateRect(&cRect, TRUE);

	if(HaveCaret)
		SetCaret();
}

void CTelnetView::InvalidateNextChar()		// Used for backspace
{
	CRect cRect;
	CTelnetDoc* pDoc = GetDocument();
	CClientDC dc(this);
	OnPrepareDC(&dc);
  	dc.SelectObject(hFont);

   	cRect.top = 0-yChar*(int)(pDoc->ScreenBuffer.GetInsertLine());
   	cRect.bottom = cRect.top-yChar;

	pDoc->ScreenBuffer.SetCurrentLine(SBEND, 0);
	CEnhString cstr = *(pDoc->ScreenBuffer.GetCurrent());
	
	// strip ANSI colour sequences, adjust insert pos to compensate
	
	cstr.Left(pDoc->ScreenBuffer.GetInsertPos());
	cstr.StripAnsi();

	CSize cs = dc.GetTextExtent(cstr.GetBuffer(1), cstr.GetLength());
	cRect.left = cs.cx;
	cRect.right = cRect.left+xChar;

	dc.LPtoDP(&cRect);
	InvalidateRect(&cRect, TRUE);
}

void CTelnetView::SetCaret()
{
	// If this is the WinTin window, set the carat pos

	CClientDC dc(this);
	OnPrepareDC(&dc);
  	dc.SelectObject(hFont);

	POINT pt;
	CTelnetDoc *pDoc = (CTelnetDoc*) GetDocument();
	CEnhString cstr = *(pDoc->ScreenBuffer.GetCurrent());
	
	// strip ANSI colour sequences, adjust insert pos to compensate
	
	cstr = cstr.Left(pDoc->ScreenBuffer.GetInsertPos());
	cstr.StripAnsi();

	CSize cs = dc.GetTextExtent(cstr.GetBuffer(1), cstr.GetLength());

	pt.x = cs.cx;
	pt.y = yChar * pDoc->ScreenBuffer.GetInsertLine() * -1;

	dc.LPtoDP(&pt);
	SetCaretPos(pt);
}


void CTelnetView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	// recalc character height and width

	TEXTMETRIC tm;
	int scy, scx;

	OnPrepareDC(pDC, pInfo);

	scy = yChar;
	scx = xChar;

	CFont Font;
	Font.CreateFont(200, 0, 0, 0, 400, FALSE, FALSE, 0,
					ANSI_CHARSET, OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
					DEFAULT_PITCH | FF_MODERN, "Courier");

   	HFONT holdfont = (HFONT)(pDC->SelectObject(&Font));

  	pDC->GetTextMetrics(&tm);

  	xChar = tm.tmMaxCharWidth;
  	yChar = tm.tmHeight + tm.tmExternalLeading;

	// round to an integral number of lines

	pInfo->m_rectDraw.bottom = pInfo->m_rectDraw.top - ((pInfo->m_rectDraw.top - pInfo->m_rectDraw.bottom)/yChar)*yChar;

	// set viewport origin

	CPoint ptVpOrg((pInfo->m_rectDraw).BottomRight());
	char buf[120];
	sprintf(buf, "OnPrint: top %d bottom %d left %d right %d\n",
		pInfo->m_rectDraw.top,
		pInfo->m_rectDraw.bottom, 
		pInfo->m_rectDraw.left, 
		pInfo->m_rectDraw.right);
	TRACE(buf);	 

	int lines =  (pInfo->m_rectDraw.top - pInfo->m_rectDraw.bottom)/yChar;

	ptVpOrg.y = (pInfo->m_nCurPage-1)*yChar*lines*(-1);
	ptVpOrg.x = 0;

	sprintf(buf, "viewport x %d, y %d\n", ptVpOrg.x, ptVpOrg.y);
	TRACE(buf);
	pDC->SetWindowOrg(ptVpOrg);
 	
	CScrollView::OnPrint(pDC, pInfo);

	yChar = scy;
	xChar = scx;

	// for some reason using pDC->SelectObject fails an assert

	SelectObject(pDC->GetSafeHdc(), holdfont);
}


void CTelnetView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	OnPrepareDC(&dc);

   	HFONT holdfont = (HFONT)SelectObject(dc.GetSafeHdc(), hFont);
	OnDraw(&dc);
	SelectObject(dc.GetSafeHdc(), holdfont);
}

void CTelnetView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{
	if(pDC->IsPrinting())
	{
	 	pDC->SetMapMode(MM_TWIPS);
		pInfo->m_bContinuePrinting = 1; 
	}
	else
	{
		CScrollView::OnPrepareDC(pDC, pInfo);
	 	pDC->SetMapMode(MM_LOENGLISH);
	}
}

void CTelnetView::OnEditSavetofile() 
{
	// Save highlighted selection to a file

	// Find file name

	CFileDialog cfd(FALSE, "*.txt", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT);

	int rc = cfd.DoModal();

	if(!rc || rc == IDCANCEL)
		return;

	// Open file

	FILE *fp;
	CString csf= cfd.GetPathName();		   

	if((fp = fopen((LPCSTR)csf, "w")) == NULL)
	{
		CString cse = "Unable to open file " + csf;
		MessageBox(cse);
		return;
	}

	// write characters to file and close

	RECT r;
	FindHighlightRegion(&r);

	CEnhString cscopy;
	CTelnetDoc* pDoc = GetDocument();
	pDoc->ScreenBuffer.SetCurrentLine(SBSTART, r.top);
	
	int iRow;

   	for (iRow=r.top; iRow <= r.bottom; iRow++)
   	{
		cscopy = *(pDoc->ScreenBuffer.GetCurrent());
		cscopy.StripAnsi();
    	
    	if(iRow == r.top && iRow == r.bottom)
    	{
    		// Selection just on one line
    		
    		fputs(cscopy.Mid(r.left, r.right-r.left), fp);
    	}
    	else if(iRow == r.top)
        {
    	    fputs(cscopy.Right(cscopy.GetLength()-r.left), fp);
    	}	
    	else if(iRow == r.bottom)
		{
		    fputs(cscopy.Left(r.right), fp);
		}
		else
		{
		    fputs(cscopy.GetBuffer(1), fp);
		}                          

		if(iRow != r.bottom)
			fputs("\r\n", fp);

		if(!pDoc->ScreenBuffer.SetCurrentLine(SBCURR, 1))
			break;
	}             
	
	fclose(fp);                       

}

void CTelnetView::OnEditSelectall() 
{
	cpH1 = crClientRect.TopLeft();

	// StorePoint(&point, &cpH1);
	MarkHighlightRegion(crClientRect.BottomRight());
}


void CTelnetView::OnUpdateEditSavetofile(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(bHighlight);		// same as UpdateEditCopy
	
}


BOOL CTelnetView::OnEraseBkgnd(CDC* pDC) 
{
	CBrush cbw;
	cbw.CreateSolidBrush(((CTelnetApp *)AfxGetApp())->backcolor);
	FillOutsideRect(pDC, &cbw);

	return 1;
	
	// return CScrollView::OnEraseBkgnd(pDC);
}

// Change font

void CTelnetView::ChangeFont(HFONT hf)
{
	
	hFont = hf;
	OnInitialUpdate();
	InvalidateRect(NULL);

}

void CTelnetView::OnDestroy() 
{
	WINDOWPLACEMENT wndpl;
	CEnhString cs;

	CFrameWnd *CWnd = GetParentFrame();
	CWnd->GetWindowPlacement(&wndpl);

	cs.printf("Child%2d", ((CTelnetApp *)AfxGetApp())->GetDocHandle(GetDocument()));
	((CTelnetApp *)AfxGetApp())->WriteWindowDetails(cs, &wndpl);	

	CScrollView::OnDestroy();	
}

void CTelnetView::OnViewDefinitions() 
{
	CTinEditView ctv;

	ctv.DoModal();
	
}

void CTelnetView::OnViewSmart() 
{
  displaysmartmud();  	
}

struct 
{
	UINT vk;
	char *str;
}
VK_to_string [] =
{
	{VK_F1, "VK_F1"},
	{VK_F2, "VK_F2"},
	{VK_F3, "VK_F3"},
	{VK_F4, "VK_F4"},
	{VK_F5, "VK_F5"},
	{VK_F6, "VK_F6"},
	{VK_F7, "VK_F7"},
	{VK_F8, "VK_F8"},
	{VK_F9, "VK_F9"},
	{VK_F10, "VK_F10"},
	{VK_F11, "VK_F11"},
	{VK_F12, "VK_F12"},
	{VK_BACK, "VK_BACK"},
	{VK_TAB, "VK_TAB"},
	{VK_ESCAPE, "VK_ESCAPE"},
	{VK_PRIOR, "VK_PGUP"},
	{VK_NEXT, "VK_PGDN"},
	{VK_END, "VK_END"},
	{VK_HOME, "VK_HOME"},
	{VK_LEFT, "VK_LEFT"},
	{VK_RIGHT, "VK_RIGHT"},
	{VK_UP, "VK_UP"},
	{VK_DOWN, "VK_DOWN"},
	{VK_INSERT, "VK_INSERT"},
	{VK_DELETE, "VK_DELETE"},
	{VK_NUMPAD0, "VK_NUMPAD0"},
	{VK_NUMPAD1, "VK_NUMPAD1"},
	{VK_NUMPAD2, "VK_NUMPAD2"},
	{VK_NUMPAD3, "VK_NUMPAD3"},
	{VK_NUMPAD4, "VK_NUMPAD4"},
	{VK_NUMPAD5, "VK_NUMPAD5"},
	{VK_NUMPAD6, "VK_NUMPAD6"},
	{VK_NUMPAD7, "VK_NUMPAD7"},
	{VK_NUMPAD8, "VK_NUMPAD8"},
	{VK_NUMPAD9, "VK_NUMPAD9"},
	{VK_MULTIPLY, "VK_MULTIPLY"},
	{VK_ADD, "VK_ADD"},
	{VK_SUBTRACT, "VK_SUBTRACT"},
	{VK_DECIMAL, "VK_DECIMAL"},
	{VK_DIVIDE, "VK_DIVIDE"},
	{VK_NUMLOCK, "VK_NUMLOCK"},
	{VK_SCROLL, "VK_SCROLL"},
	{0, ""}
};


BOOL CTelnetView::PreTranslateMessage(MSG* pMsg) 
{
	int i;
	
	if(pMsg->message == WM_KEYDOWN)
	{
		for(i=0; VK_to_string[i].vk; i++)
		{
			if(VK_to_string[i].vk == pMsg->wParam)
			{
				if(tinspecchar(VK_to_string[i].str))
					return 1;
			
				break;
			}

      if(pMsg->wParam == VK_PRIOR || pMsg->wParam == VK_NEXT)
      {
        PageUp(pMsg->wParam == VK_PRIOR);
        return 1;
      }

      if(pMsg->wParam == VK_DOWN || pMsg->wParam == VK_UP
				 || pMsg->wParam == VK_LEFT || pMsg->wParam == VK_RIGHT || pMsg->wParam == VK_DELETE)
      {
        safe_tinchar((pMsg->wParam)|0x80);
        return 1;
      }

		}
	}

	return CScrollView::PreTranslateMessage(pMsg);
}

afx_msg void CTelnetView::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	int i;
	
		for(i=0; VK_to_string[i].vk; i++)
		{
			if(VK_to_string[i].vk == nChar)
			{
				if(tinspecchar(VK_to_string[i].str))
					return;
			
				break;
			}
		}

	CScrollView::OnSysKeyDown(nChar, nRepCnt, nFlags);
}

// Page up if iUp is true, otherwise page down

void CTelnetView::PageUp(int iUp)
{
  if(iUp)
    OnScroll(MAKEWORD(-1, SB_PAGEUP), 0);
  else
    OnScroll(MAKEWORD(-1, SB_PAGEDOWN), 0);
}



BOOL CTelnetView::OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll) 
{
	// Handle a scroll range of > 32k (See MS Q note Q166473)
  // - used on NT only

  SCROLLINFO info;
  info.cbSize = sizeof(SCROLLINFO);
  info.fMask = SIF_TRACKPOS;

  if(LOBYTE(nScrollCode) == SB_THUMBTRACK)
  {
    GetScrollInfo(SB_HORZ, &info);
    nPos = info.nTrackPos;
  }

  if(HIBYTE(nScrollCode) == SB_THUMBTRACK)
  {
    GetScrollInfo(SB_VERT, &info);
    nPos = info.nTrackPos;
  }
  
	
	return CScrollView::OnScroll(nScrollCode, nPos, bDoScroll);
}

void CTelnetView::OnViewMsp() 
{
	CMSPOptions cmsp;

	cmsp.DoModal();
	
}
