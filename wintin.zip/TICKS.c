/*********************************************************************/
/* file: ticks.c - functions for the ticker stuff                    */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

/* externs 
   struct session *sessionlist;
 */

/* local globals */

int sec_to_tick, time0, tick_size = 10;

/*********************/
/* the #tick command */
/*********************/
void tick_command(struct session *ses)
{
  if (ses)
  {
    if (ses->tickstatus)
    {
      char buf[100];

      sprintf(buf, "THERE'S NOW %d SECONDS TO NEXT TICK.", sec_to_tick);
      tintin_puts(buf, ses);
    }
    else
      tintin_puts("MY TICKER IS OFF! DUNNO SECONDS TO TICK", ses);
  }
  else
    tintin_puts("#NO SESSION ACTIVE => NO TICKER!", ses);
}
/************************/
/* the #tickoff command */
/************************/
void tickoff_command(struct session *ses)
{
  if (ses)
  {
    ses->tickstatus = FALSE;
    tintin_puts("#TICKER IS NOW OFF.", ses);
  }
  else
    tintin_puts("#NO SESSION ACTIVE => NO TICKER!", ses);
}
/***********************/
/* the #tickon command */
/***********************/
void tickon_command(struct session *ses)
{
  if (ses)
  {
    ses->tickstatus = TRUE;
    tintin_puts("#TICKER IS NOW ON.", ses);
  }
  else
    tintin_puts("#NO SESSION ACTIVE => NO TICKER!", ses);
}
/************************/
/* the #tickset command */
/************************/
void tickset_command(char *arg, struct session *ses)
{
  time_t secs_to_go;
  int window;

  if (!ses)
  {
    tintin_puts("#NO SESSION ACTIVE => NO TICKER!", ses);
    return;
  }

  // wdl new parameter: only adjust within a window

  if (*arg && isdigit(*arg))
  {
    window = atoi(arg);
    secs_to_go = (time(NULL) - time0) % tick_size;

    if (secs_to_go < window || tick_size - secs_to_go < window)
		{
      time0 = time(NULL);
		}
  }
  else
  {
    time0 = time(NULL);		/* we don't prompt! too many
				   * ticksets... */
  }
}
/*************************/
/* the #ticksize command */
/*************************/
void ticksize_command(char *arg, struct session *ses)
{
  if (*arg != '\0')
  {
    if (isdigit(*arg))
    {
      tick_size = atoi(arg);
      time0 = time(NULL);
      tintin_puts("#OK NEW TICKSIZE SET", ses);
    }
    else
      tintin_puts("#SPECIFY A NUMBER!!!!TRYING TO CRASH ME EH?", ses);
  }
  else
    tintin_puts("#SET THE TICK-SIZE TO WHAT?", ses);
}
