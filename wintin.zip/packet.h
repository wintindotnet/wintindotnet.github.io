/*
 * Header file for packet classes
 * 
 * WL 6/10/96
 */

/* CCommand holds details of a command */

class CCommand
{
public:
  CCommand();
  CCommand(LPCTSTR Name, LPCTSTR Text);
  ~CCommand();
  void Format(CEnhString *Output, LPCTSTR TargetRef, LPCTSTR TargetDesc);
  void AddToPopup(CMenu *PopupMenu, int iCmd);

private:
  CString csCommandName;
  CString csCommandText;
};

/* CContent holds details of a content item */

class CContent
{
public:
  CContent();
  CContent(LPCTSTR Desc, LPCTSTR Ref, int iCmd);
  ~CContent();
  void AddToLb(CListBox *clb);
  int CompareRef(LPCTSTR Ref);
  void Replace(LPCTSTR Desc, LPCTSTR Ref, int iCmd);

private:
  CString Description;
  CString Reference;
  int iCommands;
};

/* CService holds details of a single service available on a session */

class CService
{
public:
    CService();
		CService(CService& cs);
    CService(LPCTSTR Name);
		~CService();
    void operator=(CService cs);
    int AddCommand(LPCTSTR Name, LPCTSTR Text);
    POSITION AddContent(LPCTSTR Desc, LPCTSTR Ref, int iCmd);
    int CompareName(LPCTSTR Name);
    void DeleteContents();
    void FillServicePage();
    void AddPageToSheet(class CMudSheet *MudSheet);
    void DisplayPopUp(CPoint point, int iCmd);
    void InsertContent(int iPos, LPCTSTR PrevRef, LPCTSTR Desc, LPCTSTR Ref, int iCmd);
    void DeleteContent(int iPos, LPCTSTR PrevRef);


private:
  CString Name;
  CContentPage CPage;
  CArray<CCommand, CCommand&> Commands;
  CList<CContent, CContent&> Contents;
};

/* CMud holds details about all the services available on a session */

class CMud
{
public:
		CMud();
		~CMud();
    void DisplayMudSheet();
    void ParseBlock(char *buf[]);

private:
  int ParseUpdateBlock(char **block);
  int ParseConfigBlock(char **block);
  int ParseContentBlock(char **block);

  POSITION AddService(LPCTSTR Name);
  POSITION FindService(LPCTSTR Name);
  CList<CService, CService&> Services;
  class CMudSheet *MudSheet;
};


#define CMD_OFFSET   32900  // offset for popup menu command ids