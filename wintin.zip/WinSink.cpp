// WinSink.cpp : implementation file
//

#include "stdafx.h"
//#include "telnet.h"
#include "WinSink.h"
#include "afxpriv.h"
#include "tindecl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinSink

IMPLEMENT_DYNCREATE(CWinSink, CCmdTarget)

CWinSink::CWinSink()
{
	EnableAutomation();
}

CWinSink::~CWinSink()
{
}

void CWinSink::OnWintinCmd(BSTR *bs)
{
	USES_CONVERSION;

	char *buf = W2A(*bs);
	char *p = buf;

	while(*p)
		safe_tinchar(*p++);
}


void CWinSink::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(CWinSink, CCmdTarget)
	//{{AFX_MSG_MAP(CWinSink)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CWinSink, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CWinSink)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CWinSink, "WintinCmd", 1, OnWintinCmd, VT_EMPTY, VTS_PBSTR)
END_DISPATCH_MAP()

// Note: we add support for IID_IWinSink to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {54FC8F55-38DE-4703-9C4E-250351302B1B}
static const IID IID_IWinSink =
{ 0x54FC8F55, 0x38DE, 0x4703, { 0x9c, 0x4e, 0x25, 0x03, 0x51, 0x30, 0x2b, 0x1b } };

BEGIN_INTERFACE_MAP(CWinSink, CCmdTarget)
	INTERFACE_PART(CWinSink, IID_IWinSink, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinSink message handlers
