
/*********************************************************************/
/* file: text.c  - funtions for logfile and reading/writing comfiles */
/*                             TINTIN + +                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*                    New code by Joann Ellsworth                    */
/*********************************************************************/
#include "stdafx.h"

/**********************************/
/* load a file for input to mud.  */
/**********************************/
void read_file(char *arg, struct session *ses)
{
  FILE *myfile;
  char buffer[BUFFER_SIZE], *cptr;

  get_arg_in_braces(arg, arg, 1);
  if (ses == NULL)
  {
    tintin_puts("You can't read any text in without a session being active.", NULL);
    prompt(NULL);
    return;
  }

  if ((myfile = fopen(arg, "r")) == NULL)
  {
    tintin_puts("ERROR: No file exists under that name.\n", (struct session *) NULL);
    prompt(NULL);
    return;
  }
  while (fgets(buffer, sizeof(buffer), myfile))
  {
    for (cptr = buffer; *cptr && *cptr != '\n'; cptr++) ;
    *cptr = '\0';
    write_line_mud(buffer, ses);
  }
  fclose(myfile);
  tintin_puts("File read - Success.\n", (struct session *) NULL);
  prompt(NULL);
  tintin_puts("\n", (struct session *) NULL);

}
