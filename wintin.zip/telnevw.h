// telnevw.h : interface of the CTelnetView class
//
/////////////////////////////////////////////////////////////////////////////

class CTelnetView : public CScrollView
{
protected: // create from serialization only
	CTelnetView();
	DECLARE_DYNCREATE(CTelnetView)

// Attributes
public:
	CTelnetDoc* GetDocument();

// Operations
public:

    // temporarily public
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetView)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll = TRUE);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTelnetView();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual void OnInitialUpdate();
	virtual void InvalidateLastChar(int);
	virtual void InvalidateNextChar();
	void ScrollUp(int);
  void PageUp(int);
	void ChangeFont(HFONT);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

//protected
	void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	void SetSize(void);
	void AdjustPoint(CPoint *cp);
//	void CalcLogHighlightRgn(CRgn *crg); 
	void CalcScrHighlightRgn(CRgn *crg); 
	void StorePoint(const CPoint* cpsource, CPoint* cptarg);
	void InvalidateHighlight(void);
	void DoMouseMove(CPoint *point);
	void MarkHighlightRegion(CPoint point);
	void AnsiTextOut(CDC *pDC, int x, int y, UINT nOptions, CString* pcStr);
	void FindHighlightRegion(RECT *pr);
	void SetCaret(void);

// Generated message map functions
protected:
	//{{AFX_MSG(CTelnetView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnPaint();
	afx_msg void OnEditSavetofile();
	afx_msg void OnUpdateEditSavetofile(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnViewDefinitions();
	afx_msg void OnViewSmart();
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEditSelectall();
	afx_msg void OnViewMsp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
// Data 
private:
	HFONT hFont;            // Font handle to use when writing to screen
	int xChar, yChar;		// Width and height of one character
	CRect crClientRect;		// Client rectangle dimensions, kept up to date         
	BOOL bHighlight;		// nonzero if text currently highlighted 
	BOOL bMouseTracking;    // nonzero if currently tracking mouse
	CPoint cpH1, cpH2;		// Starting and ending points of highlighted text (logical co-ords)
	CPoint cpMousePos;		// Last recorded mouse position
	int nTimer;				// Timer number (nonzero if active)
	int HaveCaret;			// nonzero if we own the caret
};

#ifndef _DEBUG  // debug version in telnevw.cpp
inline CTelnetDoc* CTelnetView::GetDocument()
   { return (CTelnetDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

extern int CrackAnsi(const char *str, int *format, int *constituents);

