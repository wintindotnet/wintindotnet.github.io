// mainfrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#define MAXSTATUS 20		// max length of a status message for small panes
#define PANELS 4				// number of panels (including time)

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	int m_nTimePaneNo;
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;

#endif
	void CMainFrame::EnableWSNotify();
	void paneltext(int ind, char *str);
protected:  // control bar embedded members
	afx_msg void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnUpdateTime(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePanel(CCmdUI* pCmdUI);
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
  afx_msg LRESULT OnMCINotifyError(WPARAM wParam, LPARAM lParam); 
  afx_msg LRESULT OnMCINotifyMode(WPARAM wParam, LPARAM lParam); 
	int GetStatusTextWidth(const char *);

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	//}}AFX_MSG
	afx_msg LONG OnAsyncSelect(WPARAM wParam, LPARAM lParam);
	afx_msg LONG OnCommNotify(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

// Data
	int NotifyCount;		// number of notifies until we idle
	CPtrList NotifySockList;	// socks to re-enable on idle
private:
	UINT m_nStatusPane1ID;
private:
	UINT m_nStatusPane1Style;
private:
	INT  m_nStatusPane1Width;
private:
	BOOL m_bMenuSelect;
private:
	BOOL InitStatusBar(UINT *pIndicators, int nSize, int nSeconds);
	struct
	{
		char text[MAXSTATUS];		// text to display
		int length;							// in screen units
	}
	statustext[PANELS];
};

/////////////////////////////////////////////////////////////////////////////

// the DocList structure

struct doclist
{
	CTelnetDoc *pDoc;
	int iHandle;
};
				
