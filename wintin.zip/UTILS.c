/*********************************************************************/
/* file: utils.c - some utility-functions                            */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

/*********************************************/
/* return: TRUE if s1 is an abrevation of s2 */
/*********************************************/
int is_abrev(char *s1, char *s2)
{
  return (!strncmp(s2, s1, strlen(s1)));
}
/********************************/
/* strdup - duplicates a string */
/* return: address of duplicate */
/********************************/
char *mystrdup(char *s)
{
  char *dup;

  if ((dup = (char *) mymalloc(strlen(s) + 1)) == NULL)
    syserr("Not enought memory for strdup.");
  strcpy(dup, s);
  return dup;
}

/*************************************************/
/* print system call error message and terminate */
/*************************************************/
void syserr(char *msg)
{
  extern int errno, sys_nerr;
  extern char *sys_errlist[];
  char buf[256];

  //lgk on windows nt errno is bogus for winsock errors use wsagetlasterror also

  sprintf(buf, "ERROR: %s (errno=%d) (wsaerr=%d)", msg, errno, WSAGetLastError());
  conio(buf);

  myhandler(0);
}
