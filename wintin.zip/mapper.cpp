// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "mapper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// _Script properties

/////////////////////////////////////////////////////////////////////////////
// _Script operations

CString _Script::GetToString()
{
	CString result;
	InvokeHelper(0x0, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

BOOL _Script::Equals(const VARIANT& obj)
{
	BOOL result;
	static BYTE parms[] =
		VTS_VARIANT;
	InvokeHelper(0x60020001, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		&obj);
	return result;
}

long _Script::GetHashCode()
{
	long result;
	InvokeHelper(0x60020002, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

LPDISPATCH _Script::GetType()
{
	LPDISPATCH result;
	InvokeHelper(0x60020003, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

void _Script::add_WintinCmd(LPUNKNOWN value)
{
	static BYTE parms[] =
		VTS_UNKNOWN;
	InvokeHelper(0x60020004, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 value);
}

void _Script::remove_WintinCmd(LPUNKNOWN value)
{
	static BYTE parms[] =
		VTS_UNKNOWN;
	InvokeHelper(0x60020005, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 value);
}

long _Script::StartMain()
{
	long result;
	InvokeHelper(0x60020006, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long _Script::MapCommand(LPCTSTR command)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x60020007, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		command);
	return result;
}

void _Script::Clear()
{
	InvokeHelper(0x60020008, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void _Script::Block()
{
	InvokeHelper(0x60020009, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void _Script::ScriptCommand(LPCTSTR s)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x6002000a, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 s);
}
