// mainfrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"

#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "mainfrm.h"

#include <winsock.h>

extern "C" HWND hwMusicMCIWnd, hwSoundMCIWnd;
extern "C" HWND hwMusicMCIWnd, hwSoundMCIWnd;
extern "C" void MCIErrorHandler(HWND wnd, long lParam);
extern "C" void MCIModeHandler(HWND wnd, long lParam);


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	ON_WM_INITMENUPOPUP()
	ON_WM_MENUSELECT()
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTime)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_1, OnUpdatePanel)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_2, OnUpdatePanel)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_3, OnUpdatePanel)

	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_INDEX, CMDIFrameWnd::OnHelpIndex)
	ON_COMMAND(ID_HELP_USING, CMDIFrameWnd::OnHelpUsing)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpIndex)

	ON_MESSAGE(WM_USER+1, OnAsyncSelect)
	ON_MESSAGE(WM_COMMNOTIFY, OnCommNotify)	 // this event faked by thread
  ON_MESSAGE(MCIWNDM_NOTIFYERROR, OnMCINotifyError)
  ON_MESSAGE(MCIWNDM_NOTIFYMODE, OnMCINotifyMode)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// arrays of IDs used to initialize control bars
	
// toolbar buttons - IDs are command buttons
static UINT BASED_CODE buttons[] =
{
	// same order as in the bitmap 'toolbar.bmp'
	ID_EDIT_COPY,
	ID_EDIT_PASTE,
		ID_SEPARATOR,
	ID_FILE_PRINT,
		ID_SEPARATOR,
	ID_HELP_INDEX,
	ID_CONTEXT_HELP,
};

static UINT BASED_CODE indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
	ID_INDICATOR_1,
	ID_INDICATOR_2,
	ID_INDICATOR_3
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// CG: The following block was inserted by 'Status Bar' component.
	{
		m_nStatusPane1Width = -1;
		m_bMenuSelect = FALSE;
	}

		NotifyCount = 1;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadBitmap(IDR_MAINFRAME) ||
		!m_wndToolBar.SetButtons(buttons,
		  sizeof(buttons)/sizeof(UINT)))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	LoadBarState("Toolbars");

	// start the timer

	SetTimer(1, 1000, NULL);

	// CG: The following block was inserted by 'Status Bar' component.
	{
		// Find out the size of the static variable 'indicators' defined
		// by AppWizard and copy it
		int nOrigSize = sizeof(indicators) / sizeof(UINT);

		UINT* pIndicators = new UINT[nOrigSize + 2];
		memcpy(pIndicators, indicators, sizeof(indicators));

		// Call the Status Bar Component's status bar creation function
		if (!InitStatusBar(pIndicators, nOrigSize, 60))
		{
			TRACE0("Failed to initialize Status Bar\n");
			return -1;
		}
		delete[] pIndicators;
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
LONG CMainFrame::OnAsyncSelect(WPARAM wParam, LPARAM lParam)
{
	// wParam holds socket id, LOWORD(lParam) is event, HIWORD(lParam) is any error
	
	/* Check for error

	if(WSAGETSELECTERROR(lParam) != 0)
		return 0L;
	*/

	switch(WSAGETSELECTEVENT(lParam))
	{
	case FD_READ:
		/* cancel event notification until message queue is empty */
//		TRACE("FD_READ\n");

		if(--NotifyCount <= 0)
		{
			WSAAsyncSelect((int)wParam, m_hWnd, 0, 0);
			NotifySockList.AddTail((void *) wParam);
//			TRACE("ASYNCNOTIFY off\n");
		}
 
		tinread(wParam);
		break;

	case FD_CLOSE:
		tinclose(wParam);
		break;
		
	default:
		break;
	}
	
	return 0L;			
}

LONG CMainFrame::OnCommNotify(WPARAM wParam, LPARAM lParam)
{
	// wParam specifes the device (nCid)
	// lParam LOWORD contains event trigger
	//        HIWORD is NULL

//	if(LOWORD(lParam) == CN_RECEIVE)
		tinasyncread((struct session *)wParam);
		
	return 0L;			
}


void CMainFrame::OnTimer(UINT nIDEvent) 
{
	tintick();
	
	CMDIFrameWnd::OnTimer(nIDEvent);
}


void CMainFrame::EnableWSNotify()
{
	while(!NotifySockList.IsEmpty())
	{
//		TRACE("ASYNCNOTIFY on\n");
		int sock = (int)NotifySockList.RemoveHead();

		// FD_CLOSE added per Feng Chen

		WSAAsyncSelect(sock, m_hWnd, WM_USER+1, FD_READ|FD_CLOSE);
	}

	NotifyCount = 1;
}

void CMainFrame::OnClose() 
{
	WINDOWPLACEMENT wndpl;

	GetWindowPlacement(&wndpl);
	((CTelnetApp *)AfxGetApp())->WriteWindowDetails("Mainframe", &wndpl);
	SaveBarState("Toolbars");

  MCIWndClose(hwMusicMCIWnd);
  MCIWndClose(hwSoundMCIWnd);

	tinquit();

	CMDIFrameWnd::OnClose();
}

void CMainFrame::OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu)
{
  	CMDIFrameWnd::OnMenuSelect(nItemID, nFlags, hSysMenu);
  
	// CG: The following block was inserted by 'Status Bar' component.
	{
		// Restore first pane of the statusbar?
		if (nFlags == 0xFFFF && hSysMenu == 0 && m_nStatusPane1Width != -1)
		{
			m_bMenuSelect = FALSE;
			m_wndStatusBar.SetPaneInfo(0, 
				m_nStatusPane1ID, m_nStatusPane1Style, m_nStatusPane1Width);
			m_nStatusPane1Width = -1;   // Set it to illegal value
		}
		else 
		{
			m_bMenuSelect = TRUE;
		}
	}

}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
  	CMDIFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
  
	// CG: The following block was inserted by 'Status Bar' component.
	{
		// store width of first pane and its style
		if (m_nStatusPane1Width == -1 && m_bMenuSelect)
		{
			m_wndStatusBar.GetPaneInfo(0, m_nStatusPane1ID, 
				m_nStatusPane1Style, m_nStatusPane1Width);
			m_wndStatusBar.SetPaneInfo(0, m_nStatusPane1ID, 
				SBPS_NOBORDERS|SBPS_STRETCH, 16384);
		}
	}

}

int CMainFrame::GetStatusTextWidth(const char *str)
{
	CSize size;
	HGDIOBJ hOldFont = NULL;
	HFONT hFont = (HFONT)m_wndStatusBar.SendMessage(WM_GETFONT);
	CClientDC dc(NULL);

	if (hFont != NULL) 
		hOldFont = dc.SelectObject(hFont);
	
	size = dc.GetTextExtent(str);
	
	if (hOldFont != NULL) 
		dc.SelectObject(hOldFont);

	return size.cx;
}

void CMainFrame::OnUpdateTime(CCmdUI* pCmdUI)
{
	UINT nStyle, nID;
	
	// Get current date and format it
	CTime time = CTime::GetCurrentTime();
	CString strTime = time.Format(_T("%X"));

	if(!statustext[3].length)
	{
		m_wndStatusBar.GetPaneInfo(m_nTimePaneNo, nID, nStyle, statustext[3].length);
		statustext[3].length = GetStatusTextWidth("99:99:99");
		m_wndStatusBar.SetPaneInfo(m_nTimePaneNo, nID, nStyle, statustext[3].length);
	}

	pCmdUI->SetText(strTime);
	pCmdUI->Enable(TRUE);
}

extern int sec_to_tick;

void CMainFrame::OnUpdatePanel(CCmdUI* pCmdUI)
{
	UINT nStyle, nID;
	int i;

	switch(pCmdUI->m_nID)
	{
	case ID_INDICATOR_1:
		i = 0;
		break;
	case ID_INDICATOR_2:
		i = 1;
		break;
	case ID_INDICATOR_3:
		i = 2;
		if(activesession && activesession->tickstatus)
		{
			sprintf(statustext[i].text, "%3d", sec_to_tick);
			statustext[i].length = 0;
		}
		else
		{
			statustext[i].text[0] = 0;
			statustext[i].length = 0;
		}

		break;
	}

	if(!statustext[i].length)
	{
		m_wndStatusBar.GetPaneInfo(i+1, nID, nStyle, statustext[i].length);
		statustext[i].length = GetStatusTextWidth(statustext[i].text);
		m_wndStatusBar.SetPaneInfo(i+1, nID, nStyle, statustext[i].length);
	}

	pCmdUI->SetText(statustext[i].text);
	pCmdUI->Enable(TRUE);
}

BOOL CMainFrame::InitStatusBar(UINT *pIndicators, int nSize, int nSeconds)
{
	// CG: This function was inserted by 'Status Bar' component.

	int i;

	for(i=0; i<PANELS; i++)
	{
		statustext[i].text[0] = 0;
		statustext[i].length = 0;
	}

	// Create an index for the TIME pane
	m_nTimePaneNo = nSize++;
	nSeconds = 1;
	pIndicators[m_nTimePaneNo] = ID_INDICATOR_TIME;

	// TODO: Select an appropriate time interval for updating
	// the status bar when idling.
	m_wndStatusBar.SetTimer(0x1000, nSeconds * 1000, NULL);

	return m_wndStatusBar.SetIndicators(pIndicators, nSize);

}

// change the panel text

void CMainFrame::paneltext(int ind, char *str)
{
	char buf[MAXSTATUS+1];

	if(ind<PANELS-1)
	{
		strncpy(statustext[ind].text, str, MAXSTATUS-1);
		buf[MAXSTATUS-1] = 0;
		statustext[ind].length = 0;
	}
}

// Handle an MCI Window error notification

afx_msg LRESULT CMainFrame::OnMCINotifyError(WPARAM wParam, LPARAM lParam)
{
  MCIErrorHandler((HWND) wParam, lParam);
  return 0;
}

// Handle an MCI Window error notification

afx_msg LRESULT CMainFrame::OnMCINotifyMode(WPARAM wParam, LPARAM lParam)
{
  MCIModeHandler((HWND) wParam, lParam);
  return 0;
}
