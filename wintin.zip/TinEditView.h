// TinEditView.h : header file
//


// Masks for definition types

#define TTV_ACTION		1
#define TTV_ALIAS		2
#define TTV_HIGHLIGHT	3
#define TTV_SUB			4
#define TTV_MYVAR		5
#define TTV_ANTISUB		6

/////////////////////////////////////////////////////////////////////////////
// CTinEditView dialog

class CTinEditView : public CDialog
{
// Construction
public:
	CTinEditView(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTinEditView)
	enum { IDD = IDD_EDITVIEW };
	CButton	m_cbDelete;
	CComboBox	m_cbSession;
	CButton	m_cbnew;
	CTreeCtrl	m_ctValueTree;
	CString	m_szName;
	CString	m_szValue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTinEditView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	void CTinEditView::AddListToTree(char *szName, struct listnode *node);
	void CTinEditView::InitTree(void);
	void CTinEditView::UpdateButtons(void);

	struct session *CurrentSession;
	int namechanged, valuechanged;
	
	// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTinEditView)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNew();
	afx_msg void OnSelchangeSession();
	afx_msg void OnChangeEditName();
	afx_msg void OnChangeEditValue();
	afx_msg void OnDelete();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
