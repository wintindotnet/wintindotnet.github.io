// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// _Script wrapper class

class _Script : public COleDispatchDriver
{
public:
	_Script() {}		// Calls COleDispatchDriver default constructor
	_Script(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	_Script(const _Script& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetToString();
	BOOL Equals(const VARIANT& obj);
	long GetHashCode();
	LPDISPATCH GetType();
	void add_WintinCmd(LPUNKNOWN value);
	void remove_WintinCmd(LPUNKNOWN value);
	long StartMain();
	long MapCommand(LPCTSTR command);
	void Clear();
	void Block();
	void ScriptCommand(LPCTSTR s);
};
