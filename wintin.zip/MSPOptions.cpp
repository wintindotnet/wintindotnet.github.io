// MSPOptions.cpp : implementation file
//

#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "MSPOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern "C"
{
extern int msp_active;             /* do we allow msp? */
extern int msp_require_newline;    /* do we require a newline before !!? */
extern int msp_echo;               /* do we echo msp commands to the screen? */
extern char msp_dir[256];              /* pathname for sound files */
}


/////////////////////////////////////////////////////////////////////////////
// CMSPOptions dialog


CMSPOptions::CMSPOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CMSPOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMSPOptions)
	m_allow_tells = FALSE;
	m_display_debug = FALSE;
	m_msp_enabled = FALSE;
	m_sound_path = _T("");
	//}}AFX_DATA_INIT
}


void CMSPOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMSPOptions)
	DDX_Check(pDX, IDC_ALLOW_TELLS, m_allow_tells);
	DDX_Check(pDX, IDC_DISPLAY_DEBUG, m_display_debug);
	DDX_Check(pDX, IDC_MSP_ENABLED, m_msp_enabled);
	DDX_Text(pDX, IDC_SOUND_PATH, m_sound_path);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMSPOptions, CDialog)
	//{{AFX_MSG_MAP(CMSPOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMSPOptions message handlers

BOOL CMSPOptions::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  m_allow_tells = !msp_require_newline;
  m_display_debug = msp_echo;
  m_msp_enabled = msp_active;
  m_sound_path = CString(msp_dir);
  UpdateData(FALSE);
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMSPOptions::OnOK() 
{
	UpdateData(TRUE);
	msp_require_newline = !m_allow_tells;
  msp_echo = m_display_debug;
  msp_active = m_msp_enabled;
  strcpy(&msp_dir[0], m_sound_path);
	
	AfxGetApp()->WriteProfileString("msp", "directory", msp_dir);
	AfxGetApp()->WriteProfileInt("msp", "echo", msp_echo);
	AfxGetApp()->WriteProfileInt("msp", "active", msp_active);
	AfxGetApp()->WriteProfileInt("msp", "newline", msp_require_newline);

	CDialog::OnOK();
}
