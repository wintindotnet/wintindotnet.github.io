/*********************************************************************/
/* file: alias.c - funtions related the the alias command            */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

/**********************/
/* the #alias command */
/**********************/
void alias_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE];
  struct listnode *myaliases, *ln;

  myaliases = (ses) ? ses->aliases : common_aliases;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left)
  {
    tintin_puts2("#Defined aliases:", ses);
    show_list(myaliases);
    prompt(ses);
  }
  else if (*left && !*right)
  {
    if ((ln = search_node_with_wild(myaliases, left)) != NULL)
    {
      while ((myaliases = search_node_with_wild(myaliases, left)) != NULL)
      {
	shownode_list(myaliases);
      }

      prompt(ses);
    }
    else if (mesvar[0])
    {
      sprintf(right, "#No match(es) found for {%s}", left);
      tintin_puts2(right, ses);
    }
  }
  else
  {
    if ((ln = searchnode_list(myaliases, left)) != NULL)
      deletenode_list(myaliases, ln);

    insertnode_list(myaliases, left, right, "0", ALPHA);

    if (mesvar[0])
    {
      sprintf(arg2, "#Ok. {%s} aliases {%s}.", left, right);
      tintin_puts2(arg2, ses);
    }

    alnum++;
  }
}

/************************/
/* the #unalias command */
/************************/
void unalias_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], result[BUFFER_SIZE];
  struct listnode *myaliases, *ln;
  int flag;

  flag = FALSE;
  myaliases = (ses) ? ses->aliases : common_aliases;
  arg = get_arg_in_braces(arg, left, 1);

  while ((ln = search_node_with_wild(myaliases, left)) != NULL)
  {
    flag = TRUE;

    if (mesvar[0])
    {
      sprintf(result, "#Ok. {%s} is no longer an alias.", ln->left);
      tintin_puts2(result, ses);
    }

    deletenode_list(myaliases, ln);
  }

  if (!flag && mesvar[0])
  {
    sprintf(result, "#No match(es) found for {%s}", left);
    tintin_puts2(result, ses);
  }
}
