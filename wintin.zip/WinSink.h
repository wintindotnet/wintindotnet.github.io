#if !defined(AFX_WINSINK_H__35B95D79_4A29_4416_9B01_84AD15BA14B2__INCLUDED_)
#define AFX_WINSINK_H__35B95D79_4A29_4416_9B01_84AD15BA14B2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WinSink.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CWinSink command target

class CWinSink : public CCmdTarget
{
	DECLARE_DYNCREATE(CWinSink)

	CWinSink();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	void CWinSink::OnWintinCmd(BSTR *bs);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinSink)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWinSink();

	// Generated message map functions
	//{{AFX_MSG(CWinSink)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CWinSink)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

extern const IID IID_IWinSink;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINSINK_H__35B95D79_4A29_4416_9B01_84AD15BA14B2__INCLUDED_)
