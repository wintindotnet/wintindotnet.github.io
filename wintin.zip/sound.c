/*********************************************************************/
/* file: sound.c - sound and music commands                          */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by william lees 1999                    */
/*********************************************************************/
#include "stdafx.h"
#include <errno.h>
#include "sound.h"



struct effect curr_sound, curr_music;

int msp_active = 1;             /* do we allow msp? */
int msp_require_newline = 0;    /* do we require a newline before !!? */
int msp_echo = 1;               /* do we echo msp commands to the screen? */
char msp_dir[256];              /* pathname for sound files */

void process_msp_effect(struct effect *eff, char *cmd);

/*********************/
/* the #bell command */
/*********************/
void bell_command(struct session *ses)
{
	char buf[200];

	strcpy(buf, "ding.wav");  
	sound_command(buf, ses);
}


/**************************/
/* the #sound command     */
/**************************/
void sound_command(char *arg, struct session *ses)
{
  get_arg_in_braces(arg, arg, 1);

  if (*arg)
  {    
    MCIWndOpen(hwSoundMCIWnd, arg, NULL);
    MCIWndPlay(hwSoundMCIWnd);     
  }
  else
    tintin_puts3("#What sound?", ses);

  prompt(NULL);
}

/**************************/
/* the #music command     */
/**************************/
void music_command(char *arg, struct session *ses)
{
  get_arg_in_braces(arg, arg, 1);

  if (*arg)
  {    
    MCIWndOpen(hwMusicMCIWnd, arg, NULL);
    MCIWndPlay(hwMusicMCIWnd);     
  }
  else
    tintin_puts3("#What music?", ses);

  prompt(NULL);
}


/******************************************/
/* msp support - process !!SOUND, !!MUSIC */
/******************************************/


void process_msp(char *inbuf)
{
  char *p, *q, mspcmd[1024];

  if(msp_require_newline)
  {
    if(strstr(inbuf, "!!SOUND(") != inbuf 
      && strstr(inbuf, "!!MUSIC(") != inbuf)
      return;
  }

  /* Check we have a complete command, extract it from the
     buffer */

  p = strstr(inbuf, "!!SOUND(");

  if(!p)
    p = strstr(inbuf, "!!MUSIC(");

  if(!p)
    return;

  q = strchr(p, ')');

  if(!q)
    return;

  *++q = 0;
  strncpy(mspcmd, p, 1023);
  mspcmd[1023] = 0;
  memmove(p, q, strlen(q)+1);

  if(msp_echo)
    tintin_puts3(mspcmd, activesession);

  if(strstr(mspcmd, "SOUND"))
    process_msp_effect(&curr_sound, mspcmd);
  else
    process_msp_effect(&curr_music, mspcmd);
}

/* helper function to remove parameter from command string */

void ex_par(char *cmd, char *par)
{
  char *p, *q;

  par[0] = 0;

  p = strchr(cmd, '=');

  if(!p)
    return;

  p++;
  q = par;

  while(*p && *p != ' ' && *p != ')')
    *q++ = *p++;

  *q = 0;
}

/* Extract all supported parameters from the command */

int parse_msp_command(char *cmd, struct effect *eff)
{
  char *p, *q;
  char buf[1024];

  /* Apply defaults */

  memset(eff, 0, sizeof(struct effect));
  eff->priority = 50;
  eff->vol = 100;
  eff->repeats = 1;
  
  p = strchr(cmd, '(');
  
  if(!p)
    return 0;

  p++;
  q = eff->fname;

  while(*p && *p != ' ' && *p != ')')
    *q++ = *p++;

  *q = 0;

  if((p = strstr(cmd, "V=")) != NULL)
  {
    ex_par(p, buf);
    eff->vol = atoi(buf);
  }

  if((p = strstr(cmd, "P=")) != NULL)
  {
    ex_par(p, buf);
    eff->priority = atoi(buf);
  }

  if((p = strstr(cmd, "L=")) != NULL)
  {
    ex_par(p, buf);
    eff->repeats = atoi(buf);
  }

  if((p = strstr(cmd, "C=")) != NULL)
  {
    ex_par(p, buf);
    eff->cont = atoi(buf);
  }

  if((p = strstr(cmd, "T=")) != NULL)
  {
    ex_par(p, eff->type);
  }

  if((p = strstr(cmd, "U=")) != NULL)
  {
    ex_par(p, eff->url);
  }

  return 1;
}

/* change / separators to \ */

void twiddle(char *buf)
{
  char *p = buf;

  while(*p)
  {
    if(*p == '/')
      *p = '\\';
    p++;
  }
}

/* prefix with msp_dir directory name */

void prefix_dir(char *buf)
{
  char temp[256];

  strcpy(temp, msp_dir);

  if(temp[0] && temp[strlen(temp)-1] != '\\')
    strcat(temp, "\\");

  strcat(temp, buf);
  strcpy(buf, temp);
}

int findfile(char *patt, char *fname)
{
  struct _finddata_t fileinfo;
  long hf, choice;
  int count;
  char *p;

  if(!strchr(patt, '.'))
    strcat(patt, ".*");

  if(!_access(fname, 4))
  {
    strcpy(fname, patt);
    return 1;
  }

  // Check for wildcard

  hf = _findfirst(patt, &fileinfo);

  if(hf < 0)
    return 0;

  // work out how many matches we have

  count = 1;

  while(!_findnext(hf, &fileinfo))
    count++;

  _findclose(hf);

  // choose one at random

  choice = time(NULL);
  choice = choice % (count+1);

  hf = _findfirst(patt, &fileinfo);

  count = 0;

  while(count < choice && !_findnext(hf, &fileinfo))
    count++;

  _findclose(hf);

  // sigh, the returned filename is missing the path

  strcpy(fname, patt);

  p = &fname[strlen(fname)-1];

  while(p > fname && *p != '\\')
    p--;

  strcpy(p, "\\");
  strcat(fname, fileinfo.name);
  return 1;
}


void fetchurl(struct effect *eff)
{

}

/* Apply the sound in the curr_xx effect */

void play_msp_effect(struct effect *eff)
{
  char fbuf[256], buf[256];
  HWND hwnd;

  strcpy(fbuf, eff->fname);
  twiddle(fbuf);
  prefix_dir(buf);

  if(!findfile(fbuf, buf))
  {
    if(msp_echo)
    {
      sprintf(buf, "#Fetching file %s", fbuf);
      tintin_puts3(buf, activesession);
    }

    fetchurl(eff);

    return;
  }

  eff->active = 1;

  if(eff->repeats > 0)
    eff->repeats--;

  if(eff == &curr_sound)
    hwnd = hwSoundMCIWnd;
  else
    hwnd = hwMusicMCIWnd;

  MCIWndOpen(hwnd, buf, NULL);
  MCIWndSetVolume(hwnd, eff->vol);
  MCIWndPlay(hwnd);     

}

/* Process a !!SOUND or !!MUSIC command */

void process_msp_effect(struct effect *eff, char *cmd)
{
  struct effect tmpeff;

  parse_msp_command(cmd, &tmpeff);

  if(curr_sound.active)
  {
    if(tmpeff.priority <= eff->priority)
      return;
  }

  /* We're going active */

  memmove(eff, &tmpeff, sizeof(struct effect));

  play_msp_effect(eff);
}



/******************************************/
/* Callbacks from the MCI windows         */
/******************************************/

   
/* the error handlers display error feedback
   from the MCI windows */


void MCIErrorHandler(HWND hwnd, long lMode)
{
  char buf[1024];
  
  buf[0] = '#';

  MCIWndGetError(hwnd, &buf[1], 1022);
  tintin_puts3(buf, activesession);
}

/* the mode handlers deal with interesting mode 
   feedback from the MCI windows */

void MCIModeHandler(HWND wnd, long lMode)
{
  struct effect *eff;

  if(wnd == hwMusicMCIWnd)
    eff = &curr_music;
  else
    eff = &curr_sound;

  if(!eff->active)
    return;
  
  if(lMode == MCI_MODE_STOP)
  {
    if(eff->repeats > 0)
      eff->repeats--;

    if(eff->repeats != 0)
      play_msp_effect(eff);
    else
      eff->active = 0;
  }
}

