// ConnectDialog.cpp : implementation file
//

#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "ConnectDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConnectDialog dialog


CConnectDialog::CConnectDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectDialog)
	m_Address = _T("");
	m_Port = _T("");
	//}}AFX_DATA_INIT
}


void CConnectDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectDialog)
	DDX_Text(pDX, IDC_MUD_ADDRESS, m_Address);
	DDX_Text(pDX, IDC_MUD_PORT, m_Port);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectDialog, CDialog)
	//{{AFX_MSG_MAP(CConnectDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnectDialog message handlers

void CConnectDialog::OnOK() 
{
	int i;
	
	UpdateData(TRUE);

	// Check that the mud address contains at least one dot

	if(m_Address.IsEmpty() || m_Address.Find('.') < 0)
	{
		MessageBox("Specify the full address of the Mud (eg slothmud.org)", "Connect To Mud");
		return;
	}

	// Check that the port is sensible

	if(m_Port.IsEmpty())
	{
		MessageBox("Specify the port number (eg 6101)", "Connect To Mud");
		return;
	}

	for(i=0; i<m_Port.GetLength(); i++)
	{
		if(!(isdigit(m_Port[i])))
		{
			MessageBox("The port must be a number", "Connect To Mud");
			return;
		}
	}

	AfxGetApp()->WriteProfileString("Settings", "address", m_Address);
	AfxGetApp()->WriteProfileString("Settings", "port", m_Port);
	
	CDialog::OnOK();
}


BOOL CConnectDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_Address = AfxGetApp()->GetProfileString("Settings", "address", "slothmud.org");
	m_Port = AfxGetApp()->GetProfileString("Settings", "port", "6101");
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
