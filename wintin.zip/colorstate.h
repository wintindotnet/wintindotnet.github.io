/*
 * Colour State class definition file
 * 
 * WL 22/7/99
 */


class ColorState
{
public:

	ColorState() {Fore = Back = Bold = Light = Reset = 0;}
	
	int CrackAnsi(const char *buf);
	int MergeAnsi(const char *buf);
	void FormatAnsi(CString *str);
	int FindLast(CString *str);
	int FindPenul(CString *str);
	void Assign(int iCode);

	void Clear() {Fore = Back = Bold = Light = Reset = 0;}

	int Fore, Back, Bold, Light, Reset;
};


