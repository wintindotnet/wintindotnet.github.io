/*********************************************************************/
/* file: variables.c - functions related to the variables            */
/*                             TINTIN ++                             */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

time_t time_started;

/*************************/
/* the #variable command */
/*************************/
void var_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE];
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left)
  {
    tintin_puts2("#THESE VARIABLES HAVE BEEN SET:", ses);
    show_list(tempvars);
    prompt(ses);
  }
  else if (*left && !*right)
  {
    if ((ln = search_node_with_wild(tempvars, left)) != NULL)
    {
      while ((tempvars = search_node_with_wild(tempvars, left)) != NULL)
      {
      	shownode_list(tempvars);
      }

      prompt(ses);
    }
    else if (mesvar[5])
    {
      tintin_puts2("#THAT VARIABLE IS NOT DEFINED.", ses);
    }
  }
  else
  {
    if ((ln = searchnode_list(tempvars, left)) != NULL)
      deletenode_list(tempvars, ln);

    insertnode_list(tempvars, left, right, "0", ALPHA);
    varnum++;

    if (mesvar[5])
    {
      sprintf(arg2, "#Ok. $%s is now set to {%s}.", left, right);
      tintin_puts2(arg2, ses);
    }
  }
}
/*********************/
/* the #push command */
/*********************/
void push_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE], *p;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!left[0] || !right[0])
  {
    tintin_puts2("#Push what, where?", ses);
    prompt(ses);
    return;
  }

  if ((ln = searchnode_list(tempvars, left)) == NULL)
  {
    insertnode_list(tempvars, left, right, "0", ALPHA);
    varnum++;
  }
  else
  {
    p = mymalloc(strlen(ln->right)+strlen(right)+4);
    strcpy(p, ln->right);

    if(p[0])
      strcat(p, ", ");

    strcat(p, right);
    myfree(ln->right);
    ln->right = p;
  }

  if (mesvar[5])
  {
    sprintf(arg2, "#Ok. $%s is now set to {%s}.", left, right);
    tintin_puts2(arg2, ses);
  }
}
/***********************/
/* the #select command */
/***********************/

// helper fn to remove whitespace

void nowsp(char *buf)
{
  char *p = buf;

  while(*p == ' ')
    p++;

  if(p != buf)
    memmove(buf, p, strlen(p)+1);

  p = &buf[strlen(p)-1];

  while(p >= buf && *p == ' ')
  {
    *p = 0;
    p--;
  }
}

// extract the first list element from the buffer

void element(char *buf, char *ele)
{
  char *p, *q, c;

  p = buf;

  if(*p == ',')
    p++;

  while(*p == ' ')
    p++;

  q = p;

  while(*q && *q != ',')
    q++;


  if(*(q-1) == ' ')
  {
    q--;

    while(q > p && *q == ' ')
      q--;

    q++;
  }

  c = *q;
  *q = 0;
  strcpy(ele, p);
  *q = c;
}

void select_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], buf[BUFFER_SIZE],
    list[BUFFER_SIZE], place[BUFFER_SIZE], mode[BUFFER_SIZE], *p, *q;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, buf, 0);
  substitute_myvars(buf, left, ses);
  arg = get_arg_in_braces(arg, right, 1);

  if (!left[0] || !right[0])
  {
    tintin_puts2("#Select what, where?", ses);
    prompt(ses);
    return;
  }


  // extract args

  p = left;
  q = list;

  while(*p && *p != ',')
    *q++ = *p++;

  *q = 0;

  if(*p)
    p++;

  q = mode;

  while(*p && *p != ',')
    *q++ = *p++;

  *q = 0;

  if(*p)
    p++;

  q = place;

  while(*p && *p != ',')
    *q++ = *p++;

  *q = 0;

  nowsp(list);
  nowsp(place);
  nowsp(mode);

  if ((ln = searchnode_list(tempvars, list)) == NULL)
  {
    tintin_puts2("#Unknown list in #select.", ses);
    prompt(ses);
    return;  
  }

  // find the 'place' in the list

  p = ln->right;

  do
  {
    element(p, buf);

    if(!strcmp(place, buf))
      break;

    if(*p == ',')
      p++;

    while(*p && *p != ',')
      p++;
  }
  while(*p);

	if(!(*p) && strcmp(mode, "missing"))
		return;

  if(!strcmp(mode, "missing"))
	{
		if(!(*p))
			strcpy(vars[0], place);
		else
			return;  
	}
	else if(!strcmp(mode, "found"))
	{
		strcpy(vars[0], place);		
	}
  else if(!strcmp(mode, "prev"))
  {
    if(p == ln->right)
      p = &ln->right[strlen(ln->right)-1];

    do
    {
      p--;
    }
    while(p > ln->right && *p != ',');

		element(p, vars[0]);
  }
  else if(!strcmp(mode, "next"))
  {
    do
    {
      p++;
    }
    while(*p && *p != ',');

    if(!(*p))
      p = ln->right;

		element(p, vars[0]);
  }
  else
  {
    tintin_puts2("#Bad syntax in #select.", ses);
    prompt(ses);
    return;  
  }

  substitute_vars(right, buf);
  parse_input(buf, ses);
}

/***********************/
/* the #remove command */
/***********************/



void remove_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], buf[BUFFER_SIZE], *p, *q;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!left[0] || !right[0])
  {
    tintin_puts2("#Remove what, where?", ses);
    prompt(ses);
    return;
  }

  if ((ln = searchnode_list(tempvars, left)) == NULL)
  {
    tintin_puts2("#Bad list name in #remove.", ses);
    prompt(ses);
    return;
  }

  // trim any white space

  nowsp(right);

  // extract each element in turn and compare

  p = ln->right;

  do
  {
    element(p, buf);

    if(!strcmp(right, buf))
    {
      q = p+1;

      while(*q && *q != ',')
        q++;

      if(*p == ',' && *q)
        p++;

      if(*q == ',')
        q++;

      memmove(p, q, strlen(q)+1);
      break;
    }

    if(*p == ',')
      p++;

    while(*p && *p != ',')
      p++;
  }
  while(*p);
}


/************************/
/* the #unvar   command */
/************************/
void unvar_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], result[BUFFER_SIZE];
  struct listnode *tempvars, *ln;
  int flag;

  flag = FALSE;
  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 1);

  while ((ln = search_node_with_wild(tempvars, left)) != NULL)
  {
    if (mesvar[5])
    {
      sprintf(result, "#Ok. $%s is no longer a variable.", ln->left);
      tintin_puts2(result, ses);
    }

    deletenode_list(tempvars, ln);
    flag = TRUE;
  }

  if (!flag && mesvar[5])
    tintin_puts2("#THAT VARIABLE IS NOT DEFINED.", ses);
}
/*************************************************************************/
/* copy the arg text into the result-space, but substitute the variables */
/* $<string> with the values they stand for                              */
/*************************************************************************/
void substitute_myvars(char *arg, char *result, struct session *ses)
{
  char varname[20], buf[80], *p;
  int nest = 0, counter, varlen, time_now, popflag = 0;
  struct listnode *ln, *tempvars;

  tempvars = (ses) ? ses->myvars : common_myvars;

  while (*arg)
  {
    if (*arg == '$')
    {				/* substitute variable */
      counter = 0;

      while (*(arg + counter) == '$')
      	counter++;

      if(*(arg + counter) == '@')
        popflag = 1;
    
      varlen = 0;

      while (isalpha(*(arg + varlen + counter + popflag)))
	      varlen++;
        
      if (varlen > 0)
	      strncpy(varname, arg + counter + popflag, varlen);

      *(varname + varlen) = '\0';

      if (counter == nest + 1 && !isdigit(*(arg + counter + 1 + popflag)))
      {
	      if ((ln = searchnode_list(tempvars, varname)) != NULL)
	      {
          if(popflag)
          {
            p = &ln->right[strlen(ln->right)];

            while(p > ln->right && *p != ',')
              p--;

            if(p == ln->right)
            {
              strcpy(result, ln->right);
              result += strlen(ln->right);
              arg += counter + varlen + popflag;
              *(ln->right) = 0;
            }
            else
            {
              *p = 0;

              p++;

              while(*p == ' ')
                p++;

              strcpy(result, p);
              result += strlen(p);
              arg += counter + varlen + popflag;
            }
          }
          else
          {
	          strcpy(result, ln->right);
	          result += strlen(ln->right);
	          arg += counter + varlen;
          }
	      }
	      else if (!strcmp(varname, "time"))
	      {
	        // wdl new 'time' variable set to secs since started

	        time_now = (int) (time(NULL) - time_started);
	        sprintf(buf, "%d", time_now);
	        strcpy(result, buf);
	        result += strlen(buf);
	        arg += counter + varlen;
	      }
	      else
	      {
	        strncpy(result, arg, counter + varlen);
	        result += varlen + counter;
	        arg += varlen + counter;
	      }
      }
      else
      {
  	    strncpy(result, arg, counter + varlen);
	      result += varlen + counter;
  	    arg += varlen + counter;
      }
    }
    else if (*arg == DEFAULT_OPEN)
    {
      nest++;
      *result++ = *arg++;
    }
    else if (*arg == DEFAULT_CLOSE)
    {
      nest--;
      *result++ = *arg++;
    }
    else if (*arg == '\\' && *(arg + 1) == '$' && nest == 0)
    {
      arg++;
      *result++ = *arg++;
    }
    else
      *result++ = *arg++;
  }

  *result = '\0';
}

/*************************/
/* the #tolower command */
/*************************/
void tolower_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE], *p;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left || !*right)
  {
    tintin_puts2("#Syntax: #tolower <var> <text>", ses);
  }
  else
  {
    if ((ln = searchnode_list(tempvars, left)) != NULL)
      deletenode_list(tempvars, ln);

    for (p = right; *p; p++)
      *p = tolower(*p);

    insertnode_list(tempvars, left, right, "0", ALPHA);
    varnum++;

    if (mesvar[5])
    {
      sprintf(arg2, "#Ok. $%s is now set to {%s}.", left, right);
      tintin_puts2(arg2, ses);
    }
  }
}

/*************************/
/* the #toupper command */
/*************************/
void toupper_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE], *p;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left || !*right)
  {
    tintin_puts2("#Syntax: #toupper <var> <text>", ses);
  }
  else
  {
    if ((ln = searchnode_list(tempvars, left)) != NULL)
      deletenode_list(tempvars, ln);

    for (p = right; *p; p++)
      *p = toupper(*p);

    insertnode_list(tempvars, left, right, "0", ALPHA);
    varnum++;

    if (mesvar[5])
    {
      sprintf(arg2, "#Ok. $%s is now set to {%s}.", left, right);
      tintin_puts2(arg2, ses);
    }
  }
}
/*************************/
/* the #capture command */
/*************************/

void capture_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE];
  struct listnode *ln;

  if(!ses)
  {
    tintin_puts2("#No session active.", ses);
    return;
  }

  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left || !*right)
  {
    tintin_puts2("#Syntax: #capture <var> <starttext>", ses);
    return;
  }
  
  if ((ln = searchnode_list(ses->myvars, left)) != NULL)
    deletenode_list(ses->myvars, ln);

  if ((ln = searchnode_list(ses->captures, left)) != NULL)
    deletenode_list(ses->myvars, ln);

  insertnode_list(ses->captures, left, right, "0", ALPHA);
}
/***********************/
/* the #loop command   */
/***********************/
void loop_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], var[BUFFER_SIZE], *p, *q, *r;
  char result[BUFFER_SIZE];
  int flag, bound1, bound2, counter, atflag;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;

  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);
  flag = 1;

  p = strchr(left, ',');

  if(!p)
  {
    p = strchr(left, '$');

    if(!p)
    {
      tintin_puts2("#Bad listname in #loop", ses);
      return;
    }

    atflag = (*++p == '@');

    if(atflag)
      p++;
     
    strcpy(var, p);

    p = var;

    while(isalpha(*p))
      p++;

    *p = 0;

    if ((ln = search_node_with_wild(tempvars, var)) != NULL)
    {
      p = &ln->right[strlen(ln->right)];

      while(p > ln->right)
      {
        while(p > ln->right && *p != ',')
          p--;

        q = p;

        if(*q == ',')
          q++;

        while(*q == ' ')
          q++;

        if(!atflag)
        {
          r = strchr(q, ',');

          if(r)
            *r = 0;
        }

        strcpy(vars[0], q);
        substitute_vars(right, result);
        parse_input(result, ses);

        if(!atflag)
        {
          if(r != NULL)
            *r = ',';
          p--;
        }
        else
          *p = 0;
      }
    }
    else
    {
      tintin_puts2("#Bad listname in #loop", ses);
    }

    return;
  }
  
  strcpy(result, left);
  substitute_myvars(result, left, ses);
  
  if (sscanf(left, "%d,%d", &bound1, &bound2) != 2)
    tintin_puts2("#Wrong number of arguments in #loop", ses);
  else
  {
    flag = 1;
    counter = bound1;
    while (flag == 1)
    {
      sprintf(vars[0], "%d", counter);
      substitute_vars(right, result);
      parse_input(result, ses);
      if (bound1 < bound2)
      {
	      counter++;
	      if (counter > bound2)
	        flag = 0;
      }
      else
      {
	      counter--;
	      if (counter < bound2)
	        flag = 0;
      }
    }
  }
}

/***********************/
/* the #match command  */
/***********************/
void match_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], match[BUFFER_SIZE], format[BUFFER_SIZE], buf[BUFFER_SIZE], result[BUFFER_SIZE], buf2[BUFFER_SIZE], *p;
  struct listnode *tempvars, *ln;

  tempvars = (ses) ? ses->myvars : common_myvars;

  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 0);
  arg = get_arg_in_braces(arg, match, 0);
  arg = get_arg_in_braces(arg, format, 1);

  if (!*left || !*right)
  {
    tintin_puts2("#Syntax: #match <outvar> <invar> <match> <format>", ses);
    return;
  }
  
  if ((ln = searchnode_list(tempvars, left)) != NULL)
    deletenode_list(ses->myvars, ln);

  result[0] = 0;

  if ((ln = searchnode_list(tempvars, right)) == NULL)
  {
    tintin_puts2("#Bad list name in #match.", ses);
    prompt(ses);
    return;
  }

  // trim any white space

  nowsp(right);

  // extract each element in turn and compare

  p = ln->right;

  do
  {
    element(p, buf);

    if(check_one_action(buf, match, ses))
    {
      prepare_actionalias(format, buf2, ses);

      if(result[0])
        strcat(result, ", ");
      strcat(result, buf2);
    }
    
    if(*p == ',')
      p++;

    while(*p && *p != ',')
      p++;
  }
  while(*p);

 insertnode_list(tempvars, left, result, "0", ALPHA);

}


