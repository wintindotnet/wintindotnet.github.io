/*********************************************************************/
/* file: highlight.c - functions related to the highlight command    */
/*                             TINTIN ++                             */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by Bill Reiss 1993                      */
/*********************************************************************/
#include "stdafx.h"

/***************************/
/* the #highlight command  */
/***************************/
void parse_high(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE], result[BUFFER_SIZE];
  struct listnode *myhighs, *ln;
  int colflag = TRUE;
  char *pright, *tmp1, *tmp2, tmp3[BUFFER_SIZE];

  pright = right;
  *pright = '\0';
  myhighs = (ses) ? ses->highs : common_highs;
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left)
  {
    tintin_puts("#THESE HIGHLIGHTS HAVE BEEN DEFINED:", ses);
    show_list(myhighs);
    prompt(ses);
  }
  else
  {
    tmp1 = left;
    tmp2 = tmp1;

    while (*tmp2 != '\0')
    {
      tmp2++;

      while (*tmp2 != ',' && *tmp2 != '\0')
	tmp2++;

      while (isspace(*tmp1))
	tmp1++;

      strncpy(tmp3, tmp1, tmp2 - tmp1);
      tmp3[tmp2 - tmp1] = '\0';
      colflag = is_high_arg(tmp3);
      tmp1 = tmp2 + 1;
    }

    if (colflag == TRUE)
    {
      if ((ln = searchnode_list(myhighs, right)) != NULL)
	deletenode_list(myhighs, ln);

      insertnode_list(myhighs, right, left, "0", ALPHA);
      hinum++;

      if (mesvar[4])
      {
	sprintf(result, "#Ok. {%s} is now highlighted %s.", right, left);
	tintin_puts2(result, ses);
      }
    }
    else
    {
      tintin_puts2("Invalid Highlighting color or effect, valid types are red, blue, cyan, green,", ses);
      tintin_puts2("yellow, magenta, white, grey, black, brown, charcoal, light red, light blue,", ses);
      tintin_puts2("light cyan, light magenta, light green, b red, b blue, b cyan, b green,", ses);
      tintin_puts2("b yellow, b magenta, b white, b grey, b black, b brown, b charcoal, b light", ses);
      tintin_puts2("red, b light blue, b light cyan, b light magenta, b light green,", ses);
      tintin_puts2(" or 1-32", ses);
    }
  }
}

int is_high_arg(char *s)
{
  int code;

  sscanf(s, "%d", &code);

  if (is_abrev(s, "red") || is_abrev(s, "blue") || is_abrev(s, "cyan") ||
      is_abrev(s, "green") || is_abrev(s, "yellow") ||
      is_abrev(s, "magenta") || is_abrev(s, "white") ||
      is_abrev(s, "grey") || is_abrev(s, "black") ||
      is_abrev(s, "brown") || is_abrev(s, "charcoal") ||
      is_abrev(s, "light red") || is_abrev(s, "light blue") ||
      is_abrev(s, "light cyan") || is_abrev(s, "light magenta") ||
      is_abrev(s, "light green") || is_abrev(s, "b red") ||
      is_abrev(s, "b blue") || is_abrev(s, "b cyan") ||
      is_abrev(s, "b green") || is_abrev(s, "b yellow") ||
      is_abrev(s, "b magenta") || is_abrev(s, "b white") ||
      is_abrev(s, "b grey") || is_abrev(s, "b black") ||
      is_abrev(s, "b brown") || is_abrev(s, "b charcoal") ||
      is_abrev(s, "b light red") || is_abrev(s, "b light blue") ||
      is_abrev(s, "b light cyan") || is_abrev(s, "b light magenta") ||
      is_abrev(s, "b light green") || 

      (isdigit(*s) && ((code < 8 && code > 0) || (code < 24 && code > 15) || (code < 70 && code > 49)))
    )
    return TRUE;
  else
    return FALSE;
}

/*****************************/
/* the #unhighlight command */
/*****************************/

void unhighlight_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], result[BUFFER_SIZE];
  struct listnode *myhighs, *ln;
  int flag;

  flag = FALSE;
  myhighs = (ses) ? ses->highs : common_highs;
  arg = get_arg_in_braces(arg, left, 1);

  while ((ln = search_node_with_wild(myhighs, left)) != NULL)
  {
    if (mesvar[4])
    {
      sprintf(result, "Ok. {%s} is no longer %s.", ln->left, ln->right);
      tintin_puts2(result, ses);
    }

    deletenode_list(myhighs, ln);
    flag = TRUE;
  }

  if (!flag && mesvar[4])
    tintin_puts2("#THAT HIGHLIGHT IS NOT DEFINED.", ses);
}

// strip an ansi sequence out of a string - needed by do_one_high

void stripansi(char *buf)
{
	int i=0;

	char *start = buf;
	char *end;

	while((start = strstr(start, "\x1b[")) != NULL)
	{
		end = start + 2;
		
		while(*end)
		{
			if(!((*end >= '0' && *end <= '9') || *end == ';'))
				break;

			end++;
		}

		if(!(*end))
			return;			// run out of string

		if(*end == 'm')
		{
			// found a valid ansi colour sequence

			end++;

			memmove(start, end, strlen(end) + 1);
		}
		else
			start = end;
	}
}


// find the earliest highlight which matches a string (earliest in
// the sense that the matched pattern starts earliest in the string)

struct listnode *find_earliest_highlight(char *buf, struct session *ses)
{
  struct listnode *ln = ses->highs;
  char *p, *firstch_ptr, temp[BUFFER_SIZE];
  struct listnode *earliest = NULL;
  char *qx = NULL;

  while(ln = ln->next)
  {
    if (check_one_action(buf, ln->left, ses))
    {
      firstch_ptr = ln->left;

      if (*(firstch_ptr) == '^')
	      firstch_ptr++;

      prepare_actionalias(firstch_ptr, temp, ses);
      p = strstr(buf, temp);

      if(p && qx == NULL || p < qx)
      {
        qx = p;
        earliest = ln;
      }
    }
  } 
  
  return earliest;
}


void do_one_high(char *line, struct session *ses)
{
  struct listnode *ln;
  char temp[BUFFER_SIZE], temp2[BUFFER_SIZE], result[BUFFER_SIZE];
  char *firstch_ptr;
  char *p, *q;
  int checkfrom;
  int fired = 0;

  // checkfrom lets us check several highlights on one line
  // without letting them overlap (which would bugger up the
  // highlighting)

  checkfrom = 0;

  while (line[checkfrom] && (ln = find_earliest_highlight(&line[checkfrom], ses)))
  {
		fired = 1;

		// set up the variables

		check_one_action(&line[checkfrom], ln->left, ses);
	  
		firstch_ptr = ln->left;

    if (*(firstch_ptr) == '^')
	    firstch_ptr++;

    prepare_actionalias(firstch_ptr, temp, ses);

    // temp now contains the string in the original line which
    // matched the highlight.

    // was there any string on the line before the match?
    // if so copy it into temp

    p = strstr(&line[checkfrom], temp);

    if(p != NULL && p != line)
    {
      memcpy(result, line, (p-line));
      result[(p-line)] = 0;

      // set up p to point to any remainder of the string after the match

      p = p + strlen(temp);
    }
    else if(p != NULL)
    {
      result[0] = 0;
      p = line + strlen(temp);
    }
    else
    {
      result[0] = 0;
      p = NULL;
    }

    // now do the highlight, and copy across the highlighted string.
    // remove any pre-existing color codes first, otherwise we'll
    // get unpredictable consequences because the '99' code won't
    // know what to revert to

    stripansi(temp);
    add_codes(temp, temp2, ln->right, 0);
    strcat(result, temp2);

    // from now onwards, only check the part of the line after
    // the part we have just highlighted - but check all the
    // highlight patterns in case one is repeated

    checkfrom = strlen(result);

    // was there anything on the line after the match?

    if(p != NULL)
    {
      if(*p)
        strcat(result, p);
    }

    strcpy(line, result);

    // reset the list pointer so we check all highlights in the rest
    // of the line

    ln = ses->highs;
  }

	if(fired)
	{
		// make sure that the terminating crlf pair lies at the end of the string
	
		p = line;

		while(*p)
		{
			if(*p == '\r' || *p == '\n')
				break;

			p++;
		}

		if(!*p)
			return;

		q = p;

		while(*q)
		{
			if(*q != '\r' && *q != '\n')
				break;

			q++;
		}

		if(!*q)
			return;

		while(*q)
			*p++ = *q++;

		*p = 0;
		strcat(line, "\r\n");
	}
}

void add_codes(char *line, char *result, char *htype, int flag)
{
  char *tmp1, *tmp2, tmp3[BUFFER_SIZE], tmp4[BUFFER_SIZE];
  int code;

  sprintf(result, "%s", DEFAULT_BEGIN_COLOR);
  tmp1 = htype;
  tmp2 = tmp1;

  while (*tmp2 != '\0')
  {
    tmp2++;

    while (*tmp2 != ',' && *tmp2 != '\0')
      tmp2++;

    while (isspace(*tmp1))
      tmp1++;

    strncpy(tmp3, tmp1, tmp2 - tmp1);
    tmp3[tmp2 - tmp1] = '\0';
    code = -1;

    if (isdigit(*tmp3))
    {
      sscanf(tmp3, "%d", &code);
      code--;
    }

    if (is_abrev(tmp3, "black") || code == 0)
      strcat(result, ";30");
    else if (is_abrev(tmp3, "red") || code == 1)
      strcat(result, ";31");
    else if (is_abrev(tmp3, "green") || code == 2)
      strcat(result, ";32");
    else if (is_abrev(tmp3, "brown") || code == 3)
      strcat(result, ";33");
    else if (is_abrev(tmp3, "blue") || code == 4)
      strcat(result, ";34");
    else if (is_abrev(tmp3, "magenta") || code == 5)
      strcat(result, ";35");
    else if (is_abrev(tmp3, "cyan") || code == 6)
      strcat(result, ";36");
    else if (is_abrev(tmp3, "white") || code == 7)
      strcat(result, ";37");
    else if (is_abrev(tmp3, "charcoal") || code == 8)
      strcat(result, ";30;2");
    else if (is_abrev(tmp3, "light red") || code == 9)
      strcat(result, ";31;2");
    else if (is_abrev(tmp3, "light green") || code == 10)
      strcat(result, ";32;2");
    else if (is_abrev(tmp3, "yellow") || code == 11)
      strcat(result, ";33;2");
    else if (is_abrev(tmp3, "light blue") || code == 12)
      strcat(result, ";34;2");
    else if (is_abrev(tmp3, "light magenta") || code == 13)
      strcat(result, ";35;2");
    else if (is_abrev(tmp3, "light cyan") || code == 14)
      strcat(result, ";36;2");
    else if (is_abrev(tmp3, "white") || code == 15)
      strcat(result, ";37;2");

    else if (is_abrev(tmp3, "b black") || code == 16)
      strcat(result, ";40");
    else if (is_abrev(tmp3, "b red") || code == 17)
      strcat(result, ";41");
    else if (is_abrev(tmp3, "b green") || code == 18)
      strcat(result, ";42");
    else if (is_abrev(tmp3, "b brown") || code == 19)
      strcat(result, ";43");
    else if (is_abrev(tmp3, "b blue") || code == 20)
      strcat(result, ";44");
    else if (is_abrev(tmp3, "b magenta") || code == 21)
      strcat(result, ";45");
    else if (is_abrev(tmp3, "b cyan") || code == 22)
      strcat(result, ";46");
    else if (is_abrev(tmp3, "b white") || code == 23)
      strcat(result, ";47");
    else if (is_abrev(tmp3, "b charcoal") || code == 24)
      strcat(result, ";40;2");
    else if (is_abrev(tmp3, "b light red") || code == 25)
      strcat(result, ";41;2");
    else if (is_abrev(tmp3, "b light green") || code == 26)
      strcat(result, ";42;2");
    else if (is_abrev(tmp3, "b yellow") || code == 27)
      strcat(result, ";43;2");
    else if (is_abrev(tmp3, "b light blue") || code == 28)
      strcat(result, ";44;2");
    else if (is_abrev(tmp3, "b light magenta") || code == 29)
      strcat(result, ";45;2");
    else if (is_abrev(tmp3, "b light cyan") || code == 30)
      strcat(result, ";46;2");
    else if (is_abrev(tmp3, "b white") || code == 31)
      strcat(result, ";47;2");

    else if (code > 48 && code < 69)
    {
      sprintf(tmp4, "%i", code + 1);
      strcat(result, tmp4);
    }

    tmp1 = tmp2 + 1;
  }

  strcat(result, "m");
  strcat(result, line);
  strcat(result, "\x1b[99m");	  // a special code to mean 'revert'
}
