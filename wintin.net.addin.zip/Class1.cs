using System;
using ScriptEngine;
using ICSharpCode.Core.Services;

namespace AddinTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Class1 : AbstractService, ICommand 
	{
		Interpreter interpreter;

		public Class1()
		{
			this.Initialize +=new EventHandler(LogonService_Initialize);
		}

		private void LogonService_Initialize(object sender, EventArgs e)
		{
			interpreter = (Interpreter) ServiceManager.Services.GetService(typeof(Interpreter));
		}

		public void HandleMenuItem()
		{
			interpreter.Display("\r\nAddinTest Menu Item Selected\r\n");
		}

		#region ICommand Members

		public void ProcessCommand(string verb, string args)
		{
			interpreter.Display("\r\nCommand " + verb + " called with arguments " + args + "\r\n");
		}

		#endregion

	}

	public class MenuTest : AbstractMenuCommand
	{
		public override void Run(object sender, System.EventArgs args)
		{
			Class1 class1 = (Class1) ServiceManager.Services.GetService(typeof(Class1));
			class1.HandleMenuItem();
		}
	}
}
