/*********************************************************************/
/* file: misc.c - misc commands                                      */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"
#include <errno.h>
#include <process.h>

void unhook_session(struct session *ses);

/****************************/
/* the cr command           */
/****************************/
void cr_command(struct session *ses)
{
  if (ses != NULL)
    write_line_mud("\n", ses);
}
/****************************/
/* the version command      */
/****************************/
void version_command()
{
  char temp[80];

  sprintf(temp, "#You are using Wintin 95 %s", VERSION_NUM);
  tintin_puts2(temp, NULL);
  strcpy(temp, "#http://www.wintin.org\n\r");
  tintin_puts2(temp, NULL);
  prompt(NULL);
}
/****************************/
/* the verbatim command,    */
/* used as a toggle         */
/****************************/
void verbatim_command()
{
  verbatim = !verbatim;
  if (verbatim)
    tintin_puts2("#All text is now sent 'as is'.", (struct session *) NULL);
  else
    tintin_puts2("#Text is no longer sent 'as is'.", (struct session *) NULL);
  prompt(NULL);
}
/********************/
/* the #all command */
/********************/
struct session *all_command(char *arg, struct session *ses)
{
  struct session *sesptr;

  if (sessionlist)
  {
    get_arg_in_braces(arg, arg, 1);
    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      parse_input(arg, sesptr);
  }
  else
    tintin_puts("BUT THERE ISN'T ANY SESSION AT ALL!", ses);
  return ses;
}

void redraw_command()
{
  redraw = !redraw;
  if (redraw)
    tintin_puts2("#Ok. I now redraw input line when text arrives.", (struct session *) NULL);
  else
    tintin_puts2("#Ok. I no longer redraw the input line.", (struct session *) NULL);
  prompt(NULL);
}

/*********************/
/* the #boss command */
/*********************/
void boss_command(struct session *ses)
{
  char temp[80];
  int i;

  for (i = 0; i < 50; i++)
  {
    sprintf(temp, "in-order traverse of tree starting from node %d resulted in %d red nodes\n", i, 50 - i);
    tintin_puts2(temp, (struct session *) NULL);
  }
  getchar();			/* stop screen from scrolling stuff */
}

/*********************/
/* the #bpp command  */
/*********************/
void bpp_command(struct session *ses)
{
  if (bppmode)
  {
    bppmode = 0;
    tintin_puts2("BPP mode off.\n", (struct session *) NULL);
  }
  else
  {
    bppmode = 1;
    tintin_puts2("BPP mode on.\n", (struct session *) NULL);
  }
}

/*********************/
/* the #char command */
/*********************/
void char_command(char *arg, struct session *ses)
{
  char strng[80];

  get_arg_in_braces(arg, arg, 1);
  if (ispunct(*arg))
  {
    tintin_char = *arg;
    sprintf(strng, "#OK. TINTIN-CHAR is now {%c}\n", tintin_char);
    tintin_puts2(strng, (struct session *) NULL);
  }
  else
    tintin_puts2("#SPECIFY A PROPER TINTIN-CHAR! SOMETHING LIKE # OR /!", (struct session *) NULL);
}

/*********************/
/* the #echo command */
/*********************/
void echo_command(char *arg, struct session *ses)
{
  char right[BUFFER_SIZE];

	arg = get_arg_in_braces(arg, right, 1);

	if(!strcmp(right, "on"))
		echo = 1;
	else if(!strcmp(right, "off"))
		echo = 0;
	else			
		echo = !echo;

  if (echo)
    tintin_puts("#ECHO IS NOW ON.", ses);
  else
    tintin_puts("#ECHO IS NOW OFF.", ses);
}
/*********************/
/* the #end command */
/*********************/
void end_command(char *command, struct session *ses)
{
  if (strcmp(command, "end"))
    tintin_puts("#YOU HAVE TO WRITE #end - NO LESS, TO END!", ses);
  else
  {
    while(sessionlist)
		{
      cleanup_session(sessionlist);
			unhook_session(sessionlist);
		}

    ses = NULL;
    tintin_puts2("TINTIN suffers from bloodlack, and the lack of a beating heart...", ses);
    tintin_puts2("TINTIN is dead! R.I.P.", ses);
    tintin_puts2("Your blood freezes as you hear TINTIN's death cry.", ses);
    myhandler(0);
  }
}
/***********************/
/* the #ignore command */
/***********************/
void ignore_command(struct session *ses)
{
  if (ses)
  {
    if (ses->ignore = !ses->ignore)
      tintin_puts("#ACTIONS ARE IGNORED FROM NOW ON.", ses);
    else
      tintin_puts("#ACTIONS ARE NO LONGER IGNORED.", ses);
  }
  else
    tintin_puts("#No session active => Nothing to ignore!", ses);
}
/**********************/
/* the #presub command */
/**********************/
void presub_command(struct session *ses)
{
  presub = !presub;
  if (presub)
    tintin_puts("#ACTIONS ARE NOW PROCESSED ON SUBSTITUTED BUFFER.", ses);
  else
    tintin_puts("#ACTIONS ARE NO LONGER DONE ON SUBSTITUTED BUFFER.", ses);
}
/**************************/
/* the #togglesubs command */
/**************************/
void togglesubs_command(struct session *ses)
{
  togglesubs = !togglesubs;
  if (togglesubs)
    tintin_puts("#SUBSTITUTES ARE NOW IGNORED.", ses);
  else
    tintin_puts("#SUBSTITUTES ARE NO LONGER IGNORED.", ses);
}
/***********************/
/* the #showme command */
/***********************/
void showme_command(char *arg, struct session *ses)
{
  char result[BUFFER_SIZE], strng[BUFFER_SIZE];

  get_arg_in_braces(arg, arg, 1);
  prepare_actionalias(arg, result, ses);
  sprintf(strng, "%s", result);
  tintin_puts(strng, ses);
}
/***********************/
/* the #debug command */
/***********************/
void debug_command(char *arg, struct session *ses)
{
  char result[BUFFER_SIZE], strng[BUFFER_SIZE];

  get_arg_in_braces(arg, arg, 1);
  prepare_actionalias(arg, result, ses);
  sprintf(strng, "%s", result);
  tintin_debug(strng, ses);
}
/***********************/
/* the #panel command */
/***********************/
void panel_command(char *arg, struct session *ses)
{
  char right[BUFFER_SIZE], left[BUFFER_SIZE], result[BUFFER_SIZE];
	int ind;

	arg = get_arg_in_braces(arg, left, 0);
	arg = get_arg_in_braces(arg, right, 1);

	ind = atoi(left);

	if(ind < 1 || ind > 2)
	{
    tintin_puts("#PANEL NUMBER MUST BE 1 OR 2", ses);
		return;
	}

  prepare_actionalias(right, result, ses);
  tintin_panel(ind-1, result, ses);
}
/**********************/
/* the #update command */
/**********************/
void update_command(struct session *ses)
{
  update_common = !update_common;

  if (update_common)
    tintin_puts("#COMMON LISTS WILL BE UPDATED WHEN SESSION ENDS", ses);
  else
    tintin_puts("#COMMON LISTS WILL NOT BE UPDATED", ses);
}
/************************/
/* the #message command */
/************************/
void message_command(char *arg, struct session *ses)
{
  char offon[2][20];
  int mestype;
  char ms[6][20], tpstr[80];

  sscanf("aliases actions substitutes antisubstitutes highlights variables",
	 "%s %s %s %s %s %s", ms[0], ms[1], ms[2], ms[3], ms[4], ms[5]);
  strcpy(offon[0], "OFF.");
  strcpy(offon[1], "ON.");
  get_arg_in_braces(arg, arg, 1);
  mestype = 0;
  while (!is_abrev(arg, ms[mestype]) && mestype < 6)
    mestype++;
  if (mestype == 6)
    tintin_puts2("#Invalid message type to toggle.", ses);
  else
  {
    mesvar[mestype] = !mesvar[mestype];
    sprintf(tpstr, "#Ok. messages concerning %s are now %s",
	    ms[mestype], offon[mesvar[mestype]]);
    tintin_puts2(tpstr, ses);
  }
}

/********************/
/* the #rnd command */
/********************/

void rndnum_command(char *arg, struct session *ses)
{
	char left[BUFFER_SIZE], right[BUFFER_SIZE], arg2[BUFFER_SIZE];
	unsigned short int myrandom, i;
	struct listnode *tempvars, *ln;

	tempvars = (ses) ? ses->myvars : common_myvars;
	arg = get_arg_in_braces(arg, left, 0);
	arg = get_arg_in_braces(arg, right, 1);
	
	if (!*left || !*right)
	{
		tintin_puts2("#Syntax: #rndnum <var> <(int)upperlimit>", ses);
	}
	else
	{
		if ((ln = searchnode_list(tempvars, left)) != NULL)
			deletenode_list(tempvars, ln);

		i = atoi(right);
		myrandom = (int)((rand() % i) + 1);
		_itoa(myrandom,right,10);
		insertnode_list(tempvars, left, right, "0", ALPHA);

	    if (mesvar[5])
		{
			sprintf(arg2, "#Ok. $%s is now set to {%s}.", left, right);
			tintin_puts2(arg2, ses);
		}
	}
}

/**********************/
/* the #snoop command */
/**********************/
void snoop_command(char *arg, struct session *ses)
{
  char buf[100];
  struct session *sesptr = ses;

  if (ses)
  {
    get_arg_in_braces(arg, arg, 1);
    if (*arg)
    {
      for (sesptr = sessionlist; sesptr && strcmp(sesptr->name, arg); sesptr = sesptr->next) ;
      if (!sesptr)
      {
	tintin_puts("#NO SESSION WITH THAT NAME!", ses);
	return;
      }
    }
    if (sesptr->snoopstatus)
    {
      sesptr->snoopstatus = FALSE;
      sprintf(buf, "#UNSNOOPING SESSION '%s'", sesptr->name);
      tintin_puts(buf, ses);
    }
    else
    {
      sesptr->snoopstatus = TRUE;
      sprintf(buf, "#SNOOPING SESSION '%s'", sesptr->name);
      tintin_puts(buf, ses);
    }
  }
  else
    tintin_puts("#NO SESSION ACTIVE => NO SNOOPING", ses);
}
/**************************/
/* the #speedwalk command */
/**************************/
void speedwalk_command(char *arg, struct session *ses)
{
  get_arg_in_braces(arg, arg, 1);
  if (*arg) {
    if (_stricmp("off", arg) == 0)
      speedwalk = FALSE;
    else if (_stricmp("on", arg) == 0)
      speedwalk = TRUE;
    else {
      tintin_puts("format: #SPEEDWALK <on/off>", ses);
      return;
    }
  }
  else
    speedwalk = !speedwalk;
  if (speedwalk)
    tintin_puts("#SPEEDWALK IS NOW ON.", ses);
  else
    tintin_puts("#SPEEDWALK IS NOW OFF.", ses);
}
/***********************/
/* the #system command */
/***********************/
void system_command(char *arg, struct session *ses)
{
  get_arg_in_braces(arg, arg, 1);
  if (*arg)
  {
    tintin_puts3("^#OK EXECUTING SHELL COMMAND.", ses);
    system(arg);
    tintin_puts3("!#OK COMMAND EXECUTED.", ses);
  }
  else
    tintin_puts2("#EXECUTE WHAT COMMAND?", ses);
  prompt(NULL);

}

/********************/
/* the #zap command */
/********************/
struct session *zap_command(struct session *ses)
{
  tintin_puts("#ZZZZZZZAAAAAAAAPPPP!!!!!!!!! LET'S GET OUTTA HERE!!!!!!!!", ses);
  if (ses)
  {
    cleanup_session(ses);
		unhook_session(ses);
    return newactive_session();
  }
  else
  {
    end_command("end", (struct session *) NULL);
	return NULL;
  }
}

/************************/
/* the #wizlist command */
/************************/
/* void wizlist_command(ses)
   struct session *ses;
   {
   tintin_puts2("==========================================================================", ses);
   tintin_puts2("                           Implementor:", ses);
   tintin_puts2("                              Valgar ", ses);
   tintin_puts2("", ses);
   tintin_puts2("          Special thanks to Grimmy for all her help :)", ses);
   tintin_puts2("\n\r                         TINTIN++ testers:", ses);
   tintin_puts2(" Nemesis, Urquan, Elvworn, Kare, Merjon, Grumm, Tolebas, Winterblade ", ses);
   tintin_puts2("\n\r A very special hello to Zoe, Oura, GODDESS, Reyna, Randela, Kell, ", ses);
   tintin_puts2("                  and everyone else at GrimneDIKU\n\r", ses);
   tintin_puts2("==========================================================================", ses);
   prompt(ses);
   } */

void wizlist_command(struct session *ses)
{

  tintin_puts2("==========================================================================", ses);
  tintin_puts2("  There are too many people to thank for making tintin++ into one of the", ses);
  tintin_puts2("finest clients available.  Those deserving mention though would be ", ses);
  tintin_puts2("Peter Unold, Bill Reiss, Joann Ellsworth, Jeremy Jack, and the many people", ses);
  tintin_puts2("who send us bug reports and suggestions.", ses);
  tintin_puts2("            Enjoy!!!  And keep those suggestions coming in!!\n\r", ses);
  tintin_puts2("                       The Management...", ses);
  tintin_puts2("==========================================================================", ses);
#ifdef WIN32
  prompt(ses);
#endif
}

/*********************************************************************/
/*   tablist will display the all items in the tab completion file   */
/*********************************************************************/
void tablist(struct completenode *tcomplete)
{
  int count, done;
  char tbuf[BUFFER_SIZE];
  struct completenode *tmp;

  done = 0;
  //lgk dont know if this is a fix or not but doesn 't work under nt
#ifdef WIN32
  if (tcomplete->next == NULL)
#else
  if (tcomplete == NULL)
#endif
  {
    tintin_puts2("Sorry.. But you have no words in your tab completion file", NULL);
#ifdef WIN32
    prompt(NULL);
#endif
    return;
  }
  count = 1;
  *tbuf = '\0';

/*
   I'll search through the entire list, printing thre names to a line then
   outputing the line.  Creates a nice 3 column effect.  To increase the #
   if columns, just increase the mod #.  Also.. decrease the # in the %s's
 */

  for (tmp = tcomplete->next; tmp != NULL; tmp = tmp->next)
  {
    if ((count % 3))
    {
      if (count == 1)
	sprintf(tbuf, "%25s", tmp->strng);
      else
	sprintf(tbuf, "%s%25s", tbuf, tmp->strng);
      done = 0;
      ++count;
    }
    else
    {
      sprintf(tbuf, "%s%25s", tbuf, tmp->strng);
      tintin_puts2(tbuf, NULL);
      done = 1;
      *tbuf = '\0';
      ++count;
    }
  }
  if (!done)
    tintin_puts2(tbuf, NULL);
  prompt(NULL);
}

/*********************************************************************/
/*   tabread  will write the tab list to the specified file          */
/*********************************************************************/
void tabread(char *arg, struct session *ses)
{
  char filename[BUFFER_SIZE], tbuf[BUFFER_SIZE];

  get_arg_in_braces(arg, filename, 1);

  if (!read_complete(filename))
  {
    sprintf(tbuf, "#ERROR - Couldn't open file '%s'.", filename);
    tintin_puts(tbuf, ses);
    prompt(NULL);
    return;
  }
}

/*********************************************************************/
/*   tabwrite will write the tab list to the specified file          */
/*********************************************************************/
void tabwrite(char *arg, struct session *ses)
{
  char tbuf[BUFFER_SIZE], filename[BUFFER_SIZE];
  struct completenode *tmp;
	FILE *fp;

  get_arg_in_braces(arg, filename, 1);

  if ((fp = fopen(filename, "w")) == NULL)
  {
    sprintf(tbuf, "#ERROR - Couldn't open file '%s'.", filename);
    tintin_puts(tbuf, ses);
    prompt(NULL);
    return;
  }

  if (complete_head->next == NULL)
  {
    tintin_puts2("Sorry.. But you have no words in your tab completion file", NULL);
    prompt(NULL);
    return;
  }

  for (tmp = complete_head->next; tmp != NULL; tmp = tmp->next)
				fprintf(fp, "%s\n", tmp->strng);

	fclose(fp);
  prompt(NULL);
}

void tab_add(char *arg)
{
  struct completenode *tmp, *tmpold, *tcomplete;
  struct completenode *newt;
  char *newcomp, buff[BUFFER_SIZE];

  tcomplete = complete_head;

  if ((arg == NULL) || (strlen(arg) <= 0))
  {
    tintin_puts("Sorry, you must have some word to add.", NULL);
    prompt(NULL);
    return;
  }
  get_arg_in_braces(arg, buff, 1);

  if ((newcomp = (char *) (mymalloc(strlen(buff) + 1))) == NULL)
  {
    fprintf(stderr, "Could not allocate enough memory for that Completion word.\n");
    syserr("Could not allocate enough memory for that Completion word.");
  }
  strcpy(newcomp, buff);
  tmp = tcomplete;
  while (tmp->next != NULL)
  {
    tmpold = tmp;
    tmp = tmp->next;
  }

  if ((newt = (struct completenode *) (mymalloc(sizeof(struct completenode)))) == NULL)
  {
    syserr("Could not allocate enough memory for that Completion word.");
  }

  newt->strng = newcomp;
  newt->next = NULL;
  tmp->next = newt;
  tmp = newt;
  sprintf(buff, "#New word %s added to tab completion list.", arg);
  tintin_puts(buff, NULL);
  prompt(NULL);
}

void tab_delete(char *arg)
{
  struct completenode *tmp, *tmpold, *tmpnext, *tcomplete;
  char s_buff[BUFFER_SIZE], c_buff[BUFFER_SIZE];

  tcomplete = complete_head;

  if ((arg == NULL) || (strlen(arg) <= 0))
  {
    tintin_puts("#Sorry, you must have some word to delete.", NULL);
    prompt(NULL);
    return;
  }
  get_arg_in_braces(arg, s_buff, 1);
  tmp = tcomplete->next;
  tmpold = tcomplete;
  if (tmpold->strng == NULL)
  {				/* (no list if the second node is null) */
    tintin_puts("#There are no words for you to delete!", NULL);
    prompt(NULL);
    return;
  }
  strcpy(c_buff, tmp->strng);
  while ((tmp->next != NULL) && (strcmp(c_buff, s_buff) != 0))
  {
    tmpold = tmp;
    tmp = tmp->next;
    strcpy(c_buff, tmp->strng);
  }
  if (tmp->next != NULL)
  {
    tmpnext = tmp->next;
    tmpold->next = tmpnext;
    myfree(tmp);
    tintin_puts("#Tab word deleted.", NULL);
    prompt(NULL);
  }
  else
  {
    if (strcmp(c_buff, s_buff) == 0)
    {				/* for the last node to delete */
      tmpold->next = NULL;
      myfree(tmp);
      tintin_puts("#Tab word deleted.", NULL);
      prompt(NULL);
      return;
    }
    tintin_puts("Word not found in list.", NULL);
    prompt(NULL);
  }
}

/*********************************************************************/
/*   winmap - interface to the mapper                                */
/*********************************************************************/

char mapbuf[10000];
int mapmarked;
int mapping;
/*
int threadstarted;

void check_wininput(void *arg)
{
	char buf[1000];
	
	while(wininput(buf))
	{
		char *p = buf;

		while(*p)
			safe_tinchar(*p++);
	}
}
*/

void winmap_command(char *arg, struct session *ses)
{
  char result[BUFFER_SIZE], strng[BUFFER_SIZE];
  char left[BUFFER_SIZE], right[BUFFER_SIZE];
	int rc = 1;

  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

	if(!strcmp(left, "start"))
	{
		mapping = 1;		
		rc = winmapper("<mapon/>");
		strcpy(mapbuf, "<room>");
		mapmarked = 0;
/*
		if(rc && !threadstarted)
		{
			_beginthread(check_wininput, 0, NULL);
		}
*/
	}
	else if(!mapping)
	{
		return;
	}
	
	if(!strcmp(left, "send"))
	{
		prepare_actionalias(right, result, ses);
		rc = winmapper(result);
	}
	else if(!strcmp(left, "prompt"))
	{
		if(mapmarked && strlen(mapbuf) < 9500)
		{
			strcat(mapbuf, "</room>");
			rc = winmapper(mapbuf);
		}

		strcpy(mapbuf, "<room>");
		mapmarked = 0;
	}
	else if(!strcmp(left, "mark"))
	{
		mapmarked = 1;		
	}
	else if(!strcmp(left, "stop"))
	{
		mapping = 0;		
		rc = winmapper("<mapoff/>");
	}
	else if(!strcmp(left, "block"))
	{
		rc = winmapper("<block/>");
	}
	else if(!strcmp(left, "clear"))
	{
		rc = winmapper("<clear/>");
	}
	else if(!strcmp(left, "profile"))
	{
		prepare_actionalias(right, result, ses);
		sprintf(strng, "<profile>%s</profile>", result);
		rc = winmapper(strng);
	}

	if(!rc)
	{
		tintin_puts("COM error - can't communicate with mapper.\n", NULL);
    prompt(NULL);
	}
}


void display_info(struct session *ses)
{
  char buf[BUFFER_SIZE];
  int actions = 0;
  int aliases = 0;
  int vars = 0;
  int subs = 0;
  int antisubs = 0;
  int highs = 0;
  int ignore;

  actions = count_list((ses) ? ses->actions : common_actions);
  aliases = count_list((ses) ? ses->aliases : common_aliases);
  subs = count_list((ses) ? ses->subs : common_subs);
  antisubs = count_list((ses) ? ses->antisubs : common_antisubs);
  vars = count_list((ses) ? ses->myvars : common_myvars);
  highs = count_list((ses) ? ses->highs : common_highs);
  if (ses)
    ignore = ses->ignore;
  else
    ignore = 0;

  tintin_puts2("You have defined the following:", ses);
  sprintf(buf, "Actions : %d", actions);
  tintin_puts2(buf, ses);
  sprintf(buf, "Aliases : %d", aliases);
  tintin_puts2(buf, ses);
  sprintf(buf, "Substitutes : %d", subs);
  tintin_puts2(buf, ses);
  sprintf(buf, "Antisubstitutes : %d", antisubs);
  tintin_puts2(buf, ses);
  sprintf(buf, "Variables : %d", vars);
  tintin_puts2(buf, ses);
  sprintf(buf, "Highlights : %d", highs);
  tintin_puts2(buf, ses);
  sprintf(buf, "Echo : %d (1 - on, 0 - off)    Speedwalking : %d   Redraw: %d", echo, speedwalk, redraw);
  tintin_puts2(buf, ses);
  sprintf(buf, "Toggle Subs: %d   Ignore Actions : %d   PreSub-ing: %d", togglesubs, ignore, presub);
  tintin_puts2(buf, ses);
  sprintf(buf, "Updating : %d", update_common);
  tintin_puts2(buf, ses);

  prompt(ses);
}

#define NBLOCKS 20480

void *allocs[NBLOCKS + 1];

void *mymalloc(size_t size)
{
  int i;

  for (i = 0; i < NBLOCKS; i++)
    if (!allocs[i])
      break;

  if (i >= NBLOCKS)
    messagebox("out of mem trackers!");

  return (allocs[i] = malloc(size));
}

void myfree(void *memblock)
{
  int i;

  for (i = 0; i < NBLOCKS; i++)
    if (allocs[i] == memblock)
      break;

  if (i < NBLOCKS)
  {
    allocs[i] = 0;
    free(memblock);
  }
  else
    messagebox("bad free");
}
