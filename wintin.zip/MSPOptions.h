#if !defined(AFX_MSPOPTIONS_H__D6EC1164_94C3_4980_9865_FC215AD65847__INCLUDED_)
#define AFX_MSPOPTIONS_H__D6EC1164_94C3_4980_9865_FC215AD65847__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MSPOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMSPOptions dialog

class CMSPOptions : public CDialog
{
// Construction
public:
	CMSPOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMSPOptions)
	enum { IDD = IDD_SOUND_OPTIONS };
	BOOL	m_allow_tells;
	BOOL	m_display_debug;
	BOOL	m_msp_enabled;
	CString	m_sound_path;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMSPOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMSPOptions)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSPOPTIONS_H__D6EC1164_94C3_4980_9865_FC215AD65847__INCLUDED_)
