/*********************************************************************/
/* file: session.c.c - funtions related to sessions                  */
/*                             TINTIN III                            */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/
#include "stdafx.h"

/************************/
/* the #session command */
/************************/
struct session *session_command(char *arg, struct session *ses)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE];
  struct session *sesptr;

  /* struct listnode *ln; */
  /* int i; */
  arg = get_arg_in_braces(arg, left, 0);
  arg = get_arg_in_braces(arg, right, 1);

  if (!*left)
  {
    tintin_puts("#THESE SESSIONS HAVE BEEN DEFINED:", ses);
    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      show_session(sesptr);
    prompt(ses);
  }

  else if (*left && !*right)
  {
    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      if (!strcmp(sesptr->name, left))
      {
	show_session(sesptr);
	break;
      }
    if (sesptr == NULL)
    {
      tintin_puts("#THAT SESSION IS NOT DEFINED.", ses);
      prompt(NULL);
    }
  }

  else
  {
    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      if (strcmp(sesptr->name, left) == 0)
      {
	tintin_puts("#THERE'S A SESSION WITH THAT NAME ALREADY.", ses);
	prompt(NULL);
	return ses;
      }

    /* format of async session command:

       #ses <name> async,<port>,<baud>,<bits>,<parity>,<stop>
       eg
       #ses foo {async,1,9600,8,n,1}
     */

    if (!strncmp(right, "async", 5))
      ses = new_async_session(left, right, ses);
    else
      ses = new_session(left, right, ses);
  }

  return ses;
}

/******************/
/* show a session */
/******************/
void show_session(struct session *ses)
{
  char temp[BUFFER_SIZE];

  sprintf(temp, "%-10s%s", ses->name, ses->address);

  if (ses == activesession)
    strcat(temp, " (active)");
  if (ses->snoopstatus)
    strcat(temp, " (snooped)");
  if (ses->logfile)
    strcat(temp, " (logging)");
  tintin_puts2(temp, (struct session *) NULL);
  prompt(NULL);
}
/**********************************/
/* find a new session to activate */
/**********************************/
struct session *newactive_session()
{

  if (sessionlist)
  {
    char buf[BUFFER_SIZE];

    activesession = sessionlist;
    sprintf(buf, "#SESSION '%s' ACTIVATED.", sessionlist->name);
    tintin_puts(buf, NULL);
  }
  else
    tintin_puts("#THERE'S NO ACTIVE SESSION NOW.", NULL);
  prompt(NULL);
  return sessionlist;
}

/**********************/
/* open a new session */
/**********************/
struct session *new_session(char *name, char *address, struct session *ses)
{
  int i, sock;
  char *host, *port;
  struct session *newsession;

  port = host = space_out(mystrdup(address));

  if (!*host)
  {
    tintin_puts("#HEY! SPECIFY AN ADDRESS WILL YOU?", ses);
    return ses;
  }

  while (*port && !isspace(*port))
    port++;
  *port++ = '\0';
  port = space_out(port);

  if (!*port)
  {
    tintin_puts("#HEY! SPECIFY A PORT NUMBER WILL YOU?", ses);
    return ses;
  }

  sock = connect_mud(host, port, ses);

  myfree(host);

  if (!sock)
    return ses;

  newsession = (struct session *) mymalloc(sizeof(struct session));

  newsession->name = mystrdup(name);
  newsession->address = mystrdup(address);
  newsession->tickstatus = FALSE;
  newsession->snoopstatus = FALSE;
  newsession->logfile = NULL;
  newsession->ignore = DEFAULT_IGNORE;
  newsession->aliases = copy_list(common_aliases, ALPHA);
  newsession->actions = copy_list(common_actions, PRIORITY);
  newsession->subs = copy_list(common_subs, ALPHA);
  newsession->myvars = copy_list(common_myvars, ALPHA);
  newsession->highs = copy_list(common_highs, ALPHA);
  newsession->pathdirs = copy_list(common_pathdirs, ALPHA);
  newsession->socket = sock;
  newsession->antisubs = copy_list(common_antisubs, ALPHA);
  newsession->socketbit = 1 << sock;
  newsession->next = sessionlist;
  for (i = 0; i < HISTORY_SIZE; i++)
    newsession->history[i] = NULL;
  newsession->path = init_list();
  newsession->path_list_size = 0;
  newsession->path_length = 0;
  newsession->more_coming = 0;
  newsession->old_more_coming = 0;
  newsession->comtype = TELNET;
  newsession->Mud = alloc_mud_object();
  newsession->in_bpp_packet = 0;
  newsession->watchdog = 0;
  newsession->captures = init_list();
  sessionlist = newsession;
  activesession = newsession;
  sessionsstarted++;

  return (newsession);
}

struct session *new_async_session(char *name, char *address, struct session *ses)
{
  struct session *newsession;
  HANDLE comhandle;

  int port, baud, bits, parity, stop, sock, i;

  if (sscanf(address, "async,%d,%d,%d,%c,%d",
	     &port, &baud, &bits, &parity, &stop) != 5)
  {
    tintin_puts("#specify async,<port>,<baud>,<bits>,<parity>,<stop>", ses);
    return ses;
  }

  sock = -1;
  if (!(comhandle = connect_async_mud(port, baud, bits, parity, stop, ses)))
    return ses;

  newsession = (struct session *) mymalloc(sizeof(struct session));

  newsession->name = mystrdup(name);
  newsession->address = mystrdup(address);
  newsession->tickstatus = FALSE;
  newsession->snoopstatus = FALSE;
  newsession->logfile = NULL;
  newsession->ignore = DEFAULT_IGNORE;
  newsession->aliases = copy_list(common_aliases, ALPHA);
  newsession->actions = copy_list(common_actions, PRIORITY);
  newsession->subs = copy_list(common_subs, ALPHA);
  newsession->myvars = copy_list(common_myvars, ALPHA);
  newsession->highs = copy_list(common_highs, ALPHA);
  newsession->pathdirs = copy_list(common_pathdirs, ALPHA);
  newsession->socket = sock;
  newsession->antisubs = copy_list(common_antisubs, ALPHA);
  newsession->socketbit = 1 << sock;
  newsession->next = sessionlist;
  for (i = 0; i < HISTORY_SIZE; i++)
    newsession->history[i] = NULL;
  newsession->path = init_list();
  newsession->path_list_size = 0;
  newsession->path_length = 0;
  newsession->more_coming = 0;
  newsession->old_more_coming = 0;
  newsession->comtype = ASYNC;
  newsession->captures = init_list();
  newsession->asynchandle = comhandle;
  newsession->woverlap = (OVERLAPPED *) mymalloc(sizeof(OVERLAPPED));
  newsession->roverlap = (OVERLAPPED *) mymalloc(sizeof(OVERLAPPED));
  newsession->hmainwind = mainwnd();
  sessionlist = newsession;
  activesession = newsession;
  sessionsstarted++;

  newsession->roverlap->hEvent = NULL;
  newsession->roverlap->Offset = 0;
  newsession->roverlap->OffsetHigh = 0;

  newsession->woverlap->hEvent = NULL;
  newsession->woverlap->Offset = 0;
  newsession->woverlap->OffsetHigh = 0;

  newsession->postevent = NULL;
  newsession->hcommthread = NULL;

  //create events for rx, tx, post

  newsession->roverlap->hEvent = CreateEvent(NULL,	//no security
					      TRUE,	//explicit reset req
					      FALSE,	//initial event reset
					      NULL);
  //no name
  if (newsession->roverlap->hEvent == NULL)
  {
    close_async(newsession);
    return ses;
  }

  newsession->woverlap->hEvent = CreateEvent(NULL,	//no security
					      TRUE,	//explicit reset req
					      FALSE,	//initial event reset
					      NULL);
  //no name
  if (newsession->woverlap->hEvent == NULL)
  {
    close_async(newsession);
    return ses;
  }

  newsession->postevent = CreateEvent(NULL,	//no security
				       TRUE,	//explicit reset req
				       TRUE,	//initial event set
				       NULL);
  //no name
  if (newsession->postevent == NULL)
  {
    close_async(newsession);
    return ses;
  }

  //Launch the RX monitoring thread

  if (NULL == (newsession->hcommthread =
	       CreateThread((LPSECURITY_ATTRIBUTES) NULL, 0,
			    (LPTHREAD_START_ROUTINE) CommWatchProc,
			  (LPVOID) newsession, 0, &newsession->commthreadid)))
  {
    messagebox("CreateThread failed\n");
    close_async(newsession);
    return ses;
  }

  //Adjust thread priority

  SetThreadPriority(newsession->hcommthread, THREAD_PRIORITY_BELOW_NORMAL);
  ResumeThread(newsession->hcommthread);

  return (newsession);
}
/* Close async session
 */

void close_async(struct session *ses)
{
  if (ses->hcommthread != NULL)
  {
    //disable event notification and wait for thread
    //to halt

    ses->comtype = 0;
    SetCommMask(ses->asynchandle, 0);

    //messagebox("waiting for thread to terminate");

    //block until thread has been halted

    while (ses->commthreadid != 0)
    {
      MSG Message;

      if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
      {
	TranslateMessage(&Message);
	DispatchMessage(&Message);
      }
    }
  }

  if (ses->woverlap->hEvent != NULL)
    CloseHandle(ses->woverlap->hEvent);

  if (ses->roverlap->hEvent != NULL)
    CloseHandle(ses->roverlap->hEvent);

  if (ses->postevent != NULL)
    CloseHandle(ses->postevent);

  myfree(ses->woverlap);
  myfree(ses->roverlap);

  CloseHandle(ses->asynchandle);
}

/*****************************************************************************/
/* cleanup after session died. if session=activesession, try find new active */
/*****************************************************************************/
void cleanup_session(struct session *ses)
{
  int i;
  char buf[BUFFER_SIZE];
  struct session *sesptr;

	if(ses == NULL)
		return;				/* this keeps getting called with null session */

  sessionsstarted--;
  kill_all(ses, END);
  /* printf("DEBUG: Hist: %d \n\r",HISTORY_SIZE); */
  /*
   * CHANGED to fix a possible memory leak for(i=0; i<HISTORY_SIZE; i++)
   * ses->history[i]=NULL;
   */
  for (i = 0; i < HISTORY_SIZE; i++)
    if ((ses->history[i]))
      myfree(ses->history[i]);

  if (ses == sessionlist)
  {
    sessionlist = ses->next;
  }
  else
  {
    for (sesptr = sessionlist; sesptr->next != ses; sesptr = sesptr->next) 
		;

    sesptr->next = ses->next;
  }

  sprintf(buf, "\n#SESSION '%s' DIED.", ses->name);
  tintin_puts(buf, NULL);

  if (ses->comtype == TELNET)
    closesocket(ses->socket);
  else
    close_async(ses);

  if (ses->logfile)
    fclose(ses->logfile);

  delete_mud_object(ses->Mud);

  myfree(ses->name);
  myfree(ses->address);
  myfree(ses);
}
