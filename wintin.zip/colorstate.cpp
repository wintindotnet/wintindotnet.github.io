/*
 * Colour State class definition file
 * 
 * WL 22/7/99
 */


#include "stdafx.h"                   
#include "colorstate.h"

// Assign an ANSI code to the appropriate variable

void ColorState::Assign(int iCode)
{
	if(iCode == 0)
	{
		Fore = Back = Bold = Light = 0;
		Reset = 1;
	}
	else if(iCode == 1)
		Bold = 1;
	else if(iCode == 2)
		Light = 1;
	else if(iCode >= 30 && iCode <= 39)
		Fore = iCode;
	else if(iCode >= 40 && iCode <= 49)
		Back = iCode;
}


// Set up the color variables from an ANSI string

int ColorState::CrackAnsi(const char *buf)
{
	int r;
  
  Clear();
	r = MergeAnsi(buf);

  if(!Fore && !Back && !Bold && !Light)
    Reset = 1;

  return r;
}

// Merge ANSI codes into an existing colorstate

int ColorState::MergeAnsi(const char *buf)
{
	int i, format[5];
	CString csTemp, csAnsi(buf);

	Reset = 0;

	// first check escape seq is genuine and is a colour control of some kind

	int iCount = csAnsi.GetLength();

	for(i=2; i < iCount;i++)
		if(!((csAnsi[i] >= '0' && csAnsi[i] <= '9') || csAnsi[i] == ';'))
			break;

	if(i >= iCount || csAnsi[i] != 'm')
	{
		return 0; 		// seem to have run out of string 
	}

	// ok better parse this thing

	if(csAnsi[2] == ';')
		csTemp = csAnsi.Mid(3, i-3);
	else
		csTemp = csAnsi.Mid(2, i-2);

	// csTemp now holds the numeric ANSI codes, separated by ;, without any initial ;

	// we will recognise at most 5 codes. seems silly to have any more

	format[0] = format[1] = format[2] = format[3] = format[4] = 0;

	iCount = sscanf(csTemp.GetBuffer(1), "%i;%i;%i;%i;%i", &format[0], &format[1], &format[2], &format[3], &format[4]);

	// check for special 'previous' code

	if(iCount == 1 && format[0] == 99)
		return 99;

	// check for a Reset

	for(i = 0; i < iCount; i++)
		if(format[i] == 0)
			Clear();
	
	for(i = 0; i < iCount; i++)
		if(format[i])
			Assign(format[i]);

	return iCount;

}

// Format an ANSI string from the colour variables

void ColorState::FormatAnsi(CString *csAnsi)
{
	char buf1[20];

	*csAnsi = "\x1b[";

	if(Fore)
	{
		sprintf(buf1, "%d;", Fore);
		*csAnsi += buf1;
	}

	if(Back)
	{
		sprintf(buf1, "%d;", Back);
		*csAnsi += buf1;
	}

	if(Bold)
		*csAnsi += "1;";

	if(Light)
		*csAnsi += "2;";

	if(Reset || (!Fore && !Bold && !Light))
		*csAnsi += "0;";

	csAnsi->Left(csAnsi->GetLength()-1);
	*csAnsi += 'm';
}

// Set up the color state from the last sequence in the string

int ColorState::FindLast(CString *csAnsi)
{
	char *p;
	char *buf = csAnsi->GetBuffer(1);

	Clear();
	
	p = &buf[strlen(buf)-1];

	while(p >= buf)
	{
		if(*p == 0x1b)
		{
			if(CrackAnsi((const char *)p))
				break;
		}

		p--;
	}

  if(!Fore && !Back && !Bold && !Light)
    Reset = 1;

  return(p >= buf);
}


// Set up the color state from the penultimate sequence in the string

int ColorState::FindPenul(CString *csAnsi)
{
	int flag = 0;
	char *p;
	char *buf = csAnsi->GetBuffer(1);

	Clear();
	
	p = &buf[strlen(buf)-1];

	while(p >= buf)
	{
		if(*p == 0x1b)
		{
			if(CrackAnsi(p))
			{
				if(flag)
					break;

				flag = 1;
			}
		}

		p--;
	}

  if(!Fore && !Back && !Bold && !Light)
    Reset = 1;

	return(p >= buf);
}

