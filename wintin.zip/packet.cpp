/*
 * The packet classes 
 *
 * Used to store and manipulate the 'enhanced client' commands
 * supported by the BPP protocol
 *
 * WL 6/10/96
 */

#include "stdafx.h"
#include "resource.h"

#include "MudSheet.h"
#include "enhstr.h"
#include "enhlistbox.h"
#include "ContentPage.h"
#include "packet.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/* Test config packet */

/*
char *config_test[] =
{
    "3",
    "Inventory",
    "4",
    "Wear",
    "Wear $1",
    "Hold",
    "Hold $1",
    "Recite",
    "Recite $1",
    "Eat",
    "Eat $1",
    "Equipment",
    "2",
    "Remove",
    "Remove $1",
    "Recite",
    "Recite $1",
    "Players",
    "3",
    "Tell",
    "Tell $1",
    "Look",
    "Look $1",
    "Poke",
    "Poke $1",
    ""
};

char *content_test1[] =
{
    "Inventory",
    "3",
    "Iron rations",
    "rations",
    "9",
    "A small bag",
    "bag",
    "2",
    "A scroll of recall",
    "recall",
    "6",
    ""
};
char *content_test2[] =
{
    "Equipment",
    "3",
    "(on head)   A Dragon-Crested Helmet",
    "helmet",
    "1",
    "(on arms)   Iron Sleeves",
    "sleeves",
    "1",
    "(on feet)   Sun Sandals",
    "sandals",
    "1",
    ""
};
char *content_test3[] =
{
    "Players",
    "3",
    "Eric",
    "Eric",
    "1",
    "John",
    "John",
    "3",
    "Frobisher",
    "Frobisher",
    "7",
    ""
};


extern "C" void packettest()
{
  	Mud.ParseConfigBlock(config_test);
  	Mud.ParseContentBlock(content_test1);
  	Mud.ParseContentBlock(content_test2);
  	Mud.ParseContentBlock(content_test3);
    Mud.DisplayMudSheet();
}

*/



extern"C" void *alloc_mud_object()
{
  return (void *) new CMud;  
}

extern"C" void delete_mud_object(void *Mud)
{
  delete ((CMud *) Mud);  
}

extern"C" void display_mud_object(void *Mud)
{
  ((CMud *) Mud)->DisplayMudSheet();  
}


extern"C" void parse_bpp_packet(void *Mud, char *bpp_packet[])
{
  ((CMud *) Mud)->ParseBlock(bpp_packet);  
}


/* CCommand - store and format a basic command to send
   to the Mud */

CCommand::CCommand()
{
  csCommandText = "";
}

CCommand::CCommand(LPCTSTR Name, LPCTSTR Text)
{
  csCommandName = Name;
  csCommandText = Text;
}

CCommand::~CCommand()
{

}

void CCommand::Format(CEnhString *csOutput, LPCTSTR TargetRef, LPCTSTR TargetDesc)
{
  *csOutput = csCommandText;

  csOutput->Replace("$1", TargetRef);
  csOutput->Replace("$2", TargetDesc);
}

void CCommand::AddToPopup(CMenu *PopupMenu, int iCommand)
{
  PopupMenu->AppendMenu(MF_STRING|MF_ENABLED, iCommand+CMD_OFFSET, csCommandName);
  PopupMenu->EnableMenuItem(iCommand+CMD_OFFSET, MF_ENABLED|MF_BYCOMMAND);
}


/* CContent holds details of a content item */

CContent::CContent()
{
  Description = "";
  Reference = "";
  iCommands = 0;
}

CContent::CContent(LPCTSTR Desc, LPCTSTR Ref, int iCmd)
{
  Description = Desc;
  Reference = Ref;
  iCommands = iCmd;
}

CContent::~CContent()
{

}

void CContent::AddToLb(CListBox *clb)
{
  int iPos = clb->AddString(Description);
  
  if(iPos >= 0)
    clb->SetItemData(iPos, iCommands);
}

int CContent::CompareRef(LPCTSTR Ref)
{
  return(strcmp(Reference, Ref));
}


/* CService - Manage commands and items relating to a single service */

CService::CService()
{

}

CService::CService(CService& cs)
{
  POSITION pos = cs.Contents.GetHeadPosition();
  int i, iMax;

  iMax = cs.Commands.GetSize();

  Name = cs.Name;

  for(i = 0; i < iMax; i--)
  {
    const CCommand& cmd = cs.Commands.GetAt(i);
    Commands.Add(CCommand(cmd));
  }

  while(pos)
    Contents.AddTail(cs.Contents.GetNext(pos));    
}

CService::CService(LPCTSTR sName)
{
  Name = sName;
}

CService::~CService()
{
  Commands.RemoveAll();
  Contents.RemoveAll();
}

void CService::operator=(CService cs)
{
  POSITION pos = cs.Contents.GetHeadPosition();
  int i, iMax;

  iMax = cs.Commands.GetSize();

  Name = cs.Name;

  for(i = 0; i < iMax; i--)
  {
    const CCommand& cmd = cs.Commands.GetAt(i);
    Commands.Add(CCommand(cmd));
  }

  while(pos)
    Contents.AddTail(cs.Contents.GetNext(pos));
}


int CService::AddCommand(LPCTSTR Name, LPCTSTR Text)
{
  return Commands.Add(CCommand(Name, Text));
}

POSITION CService::AddContent(LPCTSTR Desc, LPCTSTR Ref, int iCmd)
{
  return Contents.AddTail(CContent(Desc, Ref, iCmd));
}

void CService::DeleteContents()
{
  Contents.RemoveAll();
}                                                  
                                                  

int CService::CompareName(LPCTSTR sName)
{
  return Name.Compare(sName);
}

void CService::FillServicePage()
{
  POSITION pos = Contents.GetHeadPosition();

  CPage.UpdateData(TRUE);

  while(pos)
    (Contents.GetNext(pos)).AddToLb(&(CPage.m_clb));             
}

void CService::AddPageToSheet(class CMudSheet *MudSheet)
{
  CPage.m_psp.dwFlags |= PSP_USETITLE;
  CPage.m_psp.pszTitle = Name;
  CPage.pService = this;
  
  MudSheet->AddPage(&CPage);
}

// Display a popup menu containing the masked set of commands

void CService::DisplayPopUp(CPoint point, int iCmd)
{
  CMenu PopupMenu;
  int iMask = 1;
  int i;

  PopupMenu.CreatePopupMenu();

  for(i=0; i<Commands.GetSize(); i++)
  {
    if(iCmd&iMask)
      Commands[i].AddToPopup(&PopupMenu, iCmd);

    iMask <<= 1;
  }                    

  ((CFrameWnd *)AfxGetMainWnd())->m_bAutoMenuEnable = 0;
  PopupMenu.TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON, point.x, point.y, AfxGetMainWnd());
  ((CFrameWnd *)AfxGetMainWnd())->m_bAutoMenuEnable = 1;

}

// Insert an item at the specified point

void CService::InsertContent(int iPos, LPCTSTR PrevRef, LPCTSTR Desc, LPCTSTR Ref, int iCmd)
{
  if(iPos < 0)
  {
    AddContent(Desc, Ref, iCmd);
    return;
  }

  POSITION pos = Contents.FindIndex(iPos);

  if(pos == NULL)
    return;

  CContent& content = Contents.GetAt(pos);
  
  if(!content.CompareRef(PrevRef))
    Contents.InsertBefore(pos, CContent(Desc, Ref, iCmd));
}


void CService::DeleteContent(int iPos, LPCTSTR PrevRef)
{
  POSITION pos = Contents.FindIndex(iPos);

  if(pos == NULL)
    return;

  CContent& content = Contents.GetAt(pos);
  
  if(!content.CompareRef(PrevRef))
    Contents.RemoveAt(pos);
}



/* CMud manages all services available on a session */

CMud::CMud()
{
  MudSheet = NULL;
}

CMud::~CMud()
{
  Services.RemoveAll();

  if(MudSheet != NULL)
    delete MudSheet;
}


int CMud::ParseConfigBlock(char **block)
{
  int iServices, iCommands;
  int iBlockIndex = 0;
  CString csServiceName;
  POSITION pos;

  iServices = atoi(block[iBlockIndex++]);

  while(iServices && block[iBlockIndex][0] && block[iBlockIndex+1][0])
  { 
    /* Process a service */

    pos = AddService(block[iBlockIndex++]);
    CService& Service = Services.GetAt(pos);

    iCommands = atoi(block[iBlockIndex++]);

    while(iCommands && block[iBlockIndex][0] && block[iBlockIndex+1][0])
    {
      /* Process a command */

      Service.AddCommand(block[iBlockIndex], block[iBlockIndex+1]);
      iBlockIndex += 2;

      iCommands--;
    }

    iServices--;
  }

  return 1;   // really want some kind of error status
}

POSITION CMud::FindService(LPCTSTR Name)
{
  POSITION pos, opos;
  
  pos = Services.GetHeadPosition();

  while(pos)
  {
    opos = pos;
    CService& Service = Services.GetNext(pos);
    
    if(!Service.CompareName(Name))
      return opos;
  }

  return NULL;
}

POSITION CMud::AddService(LPCTSTR Name)
{
  POSITION pos;

  /* See whether the service is already defined */
  
  if((pos = FindService(Name)) != NULL)
  {
    CService& Service = Services.GetAt(pos);
      Services.RemoveAt(pos);
  }

  /* Add in the new service */

  return Services.AddTail(CService(Name));
}

int CMud::ParseContentBlock(char **block)
{
  int iItems;
  int iBlockIndex = 0;
  POSITION pos;

  if((pos = FindService(block[iBlockIndex++])) == NULL)
    return 0;
  
  CService& Service = Services.GetAt(pos);

  Service.DeleteContents();

  iItems = atoi(block[iBlockIndex++]);

  while(iItems && block[iBlockIndex][0] 
               && block[iBlockIndex+1][0]
               && block[iBlockIndex+2][0])
  {
    Service.AddContent(block[iBlockIndex],
                        block[iBlockIndex+1],
                        atoi(block[iBlockIndex+2]));
    iBlockIndex += 3;
    iItems--;
  }

  return 1;   // really want some better kind of error status
}

int CMud::ParseUpdateBlock(char **buf)
{
  // find the service

  POSITION pos = FindService(buf[0]);

  if(pos == NULL)
    return 0;

  CService& Service = Services.GetAt(pos);

  if(!strncmp(buf[1], "Insert", 6))
  	Service.InsertContent(atoi(buf[2]), buf[3], buf[4], buf[5], atoi(buf[6]));
 
  else if(!strncmp(buf[1], "Delete", 6))
  	Service.DeleteContent(atoi(buf[2]), buf[3]);

  return 1;
}

void CMud::DisplayMudSheet()
{
  POSITION pos;
  
  if(MudSheet != NULL)
    delete MudSheet;   

  MudSheet = new CMudSheet("", NULL, 0);
  
  pos = Services.GetHeadPosition();

  while(pos)
    (Services.GetNext(pos)).AddPageToSheet(MudSheet);

  MudSheet->Create();
}

void CMud::ParseBlock(char *buf[])
{
  if(!strncmp(buf[0], "Config", 6))
  	ParseConfigBlock(&buf[1]);
 
  else if(!strncmp(buf[0], "Content", 6))
  	ParseContentBlock(&buf[1]);

  else if(!strncmp(buf[0], "Update", 6))
  	ParseUpdateBlock(&buf[1]);

}