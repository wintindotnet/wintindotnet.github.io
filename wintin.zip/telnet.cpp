 // telnet.cpp : Defines the class behaviors for the application.
 //
 
#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"

#include "telnevw.h"
#include "mainfrm.h"
#include "childfrm.h"
#include "enhstr.h"
#include "wraplength.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

extern "C" void tininit(char *);
extern "C" int wraplength;
extern "C" HWND hwMusicMCIWnd, hwSoundMCIWnd;

extern "C"
{
extern int msp_active;             /* do we allow msp? */
extern int msp_require_newline;    /* do we require a newline before !!? */
extern int msp_echo;               /* do we echo msp commands to the screen? */
extern char msp_dir[256];              /* pathname for sound files */
}


 
 /////////////////////////////////////////////////////////////////////////////
 // CTelnetApp
 
 BEGIN_MESSAGE_MAP(CTelnetApp, CWinApp)
 	//{{AFX_MSG_MAP(CTelnetApp)
 	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_VIEW_TEXT_COLOR, OnViewTextColor)
	ON_COMMAND(ID_VIEW_BACKGROUNDCOLOR, OnViewBackgroundcolor)
	ON_COMMAND(ID_VIEW_FONT, OnViewFont)
	ON_COMMAND(ID_VIEW_WRAP, OnViewWrap)
	//}}AFX_MSG_MAP
 	// Standard file based document commands
 	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
 	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
 	// Standard print setup command
 	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
  // MCI Window error notification
 END_MESSAGE_MAP()
 
 /////////////////////////////////////////////////////////////////////////////
 // CTelnetApp construction
 
 CTelnetApp::CTelnetApp()
 {
 	// TODO: add construction code here,
 	// Place all significant initialization in InitInstance
 }
 
 /////////////////////////////////////////////////////////////////////////////
 // The one and only CTelnetApp object
 
 CTelnetApp theApp;
 
 // This identifier was generated to be statistically unique for your app.
 // You may change it if you prefer to choose a specific identifier.
 static const CLSID BASED_CODE clsid =
 { 0x1c8153c0, 0xd62a, 0x11ce, { 0xa3, 0x47, 0x0, 0x0, 0xc0, 0x78, 0xa1, 0x17 } };
 
 /////////////////////////////////////////////////////////////////////////////
 // CTelnetApp initialization
 
 BOOL CTelnetApp::InitInstance()
 {
   read_profile = (m_lpCmdLine[0] != '-');

 	// Initialize OLE libraries
 	if (!AfxOleInit())
 	{
 		AfxMessageBox(IDP_OLE_INIT_FAILED);
 		return FALSE;
 	}

 	// Standard initialization
 	// If you are not using these features and wish to reduce the size
 	//  of your final executable, you should remove from the following
 	//  the specific initialization routines you do not need.
 
 	Enable3dControls();

	m_pszProfileName = _tcsdup("wintin95.ini");
	SetRegistryKey("William");
 
 	if(read_profile)
    LoadStdProfileSettings();  // Load standard INI file options (including MRU)
 
 	// Register the application's document templates.  Document templates
 	//  serve as the connection between documents, frame windows and views.
 
 	CMultiDocTemplate* pDocTemplate;
 	pDocTemplate = new CMultiDocTemplate(
 		IDR_TELNETTYPE,
 		RUNTIME_CLASS(CTelnetDoc),
 		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
 		RUNTIME_CLASS(CTelnetView));
 	AddDocTemplate(pDocTemplate);
 
 	// Connect the COleTemplateServer to the document template.
 	//  The COleTemplateServer creates new documents on behalf
 	//  of requesting OLE containers by using information
 	//  specified in the document template.
 	// m_server.ConnectTemplate(clsid, pDocTemplate, FALSE);
 
 	// Register all OLE server factories as running.  This enables the
 	//  OLE libraries to create objects from other applications.
 	// COleTemplateServer::RegisterAll();
 		// Note: MDI applications register all server objects without regard
 		//  to the /Embedding or /Automation on the command line.
 
 	// create main MDI Frame window
 	CMainFrame* pMainFrame = new CMainFrame;
 	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
 		return FALSE;
 	m_pMainWnd = pMainFrame;
 
 	// Parse the command line to see if launched as OLE server
 	if (RunEmbedded() || RunAutomated())
 	{
 		// Application was run with /Embedding or /Automation.  Don't show the
 		//  main window in this case.
// 		return TRUE;
 	}

 	// When a server application is launched stand-alone, it is a good idea
 	//  to update the system registry in case it has been damaged.
	//m_server.UpdateRegistry(OAT_DISPATCH_OBJECT);
 	COleObjectFactory::UpdateRegistryAll();

	m_NextDocHandle = 100;
	iCaretHandle = 100;
 
	// The main window has been initialized, so show and update it.

	// retrieve the window size from the registry

	WINDOWPLACEMENT wndpl;

	GetWindowDetails("Mainframe", &wndpl);	
	pMainFrame->SetWindowPlacement(&wndpl);

 	pMainFrame->ShowWindow(SW_SHOW);
 	pMainFrame->UpdateWindow();
 	
 	// read profile strings

	CEnhString cs;
	
	backcolor = RGB(0, 0, 0);
	cs.printf("%ld", backcolor);

	if(read_profile && sscanf(GetProfileString("windows", "backcolor", cs), "%ld", &backcolor) != 1)
		backcolor = RGB(0,0,0);
		
	textcolor = RGB(255, 255, 255);
	cs.printf("%ld", textcolor);

	if(read_profile && sscanf(GetProfileString("windows", "textcolor", cs), "%ld", &textcolor) != 1)
		textcolor = RGB(255, 255, 255);

	if((!read_profile) || GetProfileString("font", "facename") == "")
		hfont = (HFONT)GetStockObject(ANSI_FIXED_FONT);
	else
	{
		hfont = CreateFont(GetProfileInt("font", "size", 10), 0, 0, 0,
					GetProfileInt("font", "weight", 400),
					GetProfileInt("font", "italic", 0),
					GetProfileInt("font", "underline", 0),
					GetProfileInt("font", "strikeout", 0),
					DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
					FF_DONTCARE|DEFAULT_PITCH,
					GetProfileString("font", "facename", "Arial"));

		if(hfont == NULL)
			hfont = (HFONT)GetStockObject(ANSI_FIXED_FONT);
	}

  wraplength = (read_profile ? GetProfileInt("wrap", "length", 80) : 80);

  if(read_profile)
  {
    msp_active = GetProfileInt("msp", "active", 0);
    msp_require_newline = GetProfileInt("msp", "newline", 0);
    msp_echo = GetProfileInt("msp", "echo", 0);
    strcpy(msp_dir, GetProfileString("msp", "directory", 0));
  }
  else
  {
    msp_active = msp_require_newline = msp_echo = 0;
    msp_dir[0] = 0;
  }

	if(wraplength < 10 || wraplength > 1000)
		wraplength = 80;

  // Make invisible MCI player windows to play sounds, midi etc. One for .wav, one for others

  hwMusicMCIWnd = MCIWndCreate(m_pMainWnd->m_hWnd, m_hInstance, MCIWNDF_NOERRORDLG|MCIWNDF_NOTIFYERROR|MCIWNDF_NOTIFYMODE , NULL);
  hwSoundMCIWnd = MCIWndCreate(m_pMainWnd->m_hWnd, m_hInstance, MCIWNDF_NOERRORDLG|MCIWNDF_NOTIFYERROR|MCIWNDF_NOTIFYMODE , NULL);

 	// initialise tintin
 
 	tininit(m_lpCmdLine);

 	return TRUE;
 }
 
 /////////////////////////////////////////////////////////////////////////////
 // CAboutDlg dialog used for App About
 
 class CAboutDlg : public CDialog
 {
 public:
 	CAboutDlg();
 
 // Dialog Data
 	//{{AFX_DATA(CAboutDlg)
 	enum { IDD = IDD_ABOUTBOX };
 	//}}AFX_DATA
 
 // Implementation
 protected:
 	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
 	//{{AFX_MSG(CAboutDlg)
 		// No message handlers
 	//}}AFX_MSG
 	DECLARE_MESSAGE_MAP()
 };
 
 CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
 {
 	//{{AFX_DATA_INIT(CAboutDlg)
 	//}}AFX_DATA_INIT
 }
 
 void CAboutDlg::DoDataExchange(CDataExchange* pDX)
 {
 	CDialog::DoDataExchange(pDX);
 	//{{AFX_DATA_MAP(CAboutDlg)
 	//}}AFX_DATA_MAP
 }
 
 BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
 	//{{AFX_MSG_MAP(CAboutDlg)
 		// No message handlers
 	//}}AFX_MSG_MAP
 END_MESSAGE_MAP()
 
 // App command to run the dialog
 void CTelnetApp::OnAppAbout()
 {
 	CAboutDlg aboutDlg;
 	aboutDlg.DoModal();
 }
 
 /////////////////////////////////////////////////////////////////////////////
 // CTelnetApp commands

 // Member function to create a new document and associated view, assigning 'handle'

int CTelnetApp::NewDocument(LPSTR lpszTitle)
{
	POSITION pos;
	struct doclist *pdl;
	CEnhString cs;
	WINDOWPLACEMENT wndpl;

	OnFileNew();
	
	for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
	{
    	pdl = (struct doclist *) m_DocList.GetNext(pos);

		if(pdl->iHandle == m_NextDocHandle-1)
		{
			if(lpszTitle != NULL)
				pdl->pDoc->SetTitle(lpszTitle);

			// Retrieve window co-ordinates from registry

			cs.printf("Child%2d", m_NextDocHandle-1);
	
			if(GetWindowDetails(cs, &wndpl))
			{
				POSITION pos = pdl->pDoc->GetFirstViewPosition();
				CTelnetView* pView = (CTelnetView*)(pdl->pDoc->GetNextView(pos));	
				CMDIFrameWnd* pWnd = (CMDIFrameWnd*) (pView->GetParentFrame());
				pWnd->SetWindowPlacement(&wndpl);
				pWnd->ShowWindow(SW_SHOW);
			}

			return pdl->iHandle;
		}
	}

	return -1;
}

// Member function to return pointer to a document given a 'handle'

CTelnetDoc* CTelnetApp::GetDocument(int handle)
{
	POSITION pos;
	struct doclist *pdl;

	for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
	{
    	pdl = (struct doclist *) m_DocList.GetNext(pos);

		if(pdl->iHandle == handle)
			return pdl->pDoc;
	}
	
	return NULL;		// never 'eard of it, Guv
}

// Record a document in the open document list (used by telnedoc)

void CTelnetApp::AddDocToList(CTelnetDoc *doc)
{
	struct doclist *pdl = new struct doclist;
	pdl->pDoc = doc;
	pdl->iHandle = m_NextDocHandle++;

	m_DocList.AddHead(pdl);
}

	// Remove document from the open document list (used by telnedoc)

void CTelnetApp::RemDocFromList(CTelnetDoc *doc)
{
	POSITION pos, oldpos;
	struct doclist *pdl;

	for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
	{
		oldpos = pos;
    	pdl = (struct doclist *) m_DocList.GetNext(pos);

		if(pdl->pDoc == doc)
		{
			m_DocList.RemoveAt(oldpos);
			delete pdl;
			break;
		}
	}
 }

int CTelnetApp::GetDocHandle(CTelnetDoc *doc)
{
	POSITION pos;
	struct doclist *pdl;

	for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
	{
    	pdl = (struct doclist *) m_DocList.GetNext(pos);

		if(pdl->pDoc == doc)
			return pdl->iHandle;
	}

	return 0;
}


 // Idle processing: re-establish async notification

BOOL CTelnetApp::OnIdle(LONG lCount)
{

    if (lCount == 0)
	{
		((CMainFrame *)AfxGetMainWnd())->EnableWSNotify();
		return 1;
	}
	else
    	return(CWinApp::OnIdle(lCount-1));
}

// helper fn to invalidate all views

void CTelnetApp::InvalidateAllViews() 
{
	POSITION pos;
	struct doclist *pdl;

	for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
	{
    	pdl = (struct doclist *) m_DocList.GetNext(pos);
		pdl->pDoc->UpdateAllViews(NULL);
	}
}

void CTelnetApp::OnViewTextColor() 
{
	CColorDialog ccd(textcolor);
	
	if(ccd.DoModal() == IDOK)
	{
		textcolor = ccd.GetColor();

		CEnhString cs;
		cs.printf("%ld", textcolor);
		WriteProfileString("windows", "textcolor", cs);

		InvalidateAllViews();
	}
}

void CTelnetApp::OnViewWrap() 
{
	CWrapLength cwl;
	
	if(cwl.DoModal() == IDOK)
	{
		wraplength = cwl.m_WrapLength;
		WriteProfileInt("wrap", "length", wraplength);
	}
}


void CTelnetApp::OnViewBackgroundcolor() 
{
	CColorDialog ccd(backcolor);
	
	if(ccd.DoModal() == IDOK)
	{
		backcolor = ccd.GetColor();

		CEnhString cs;
		cs.printf("%ld", backcolor);
		WriteProfileString("windows", "backcolor", cs);

		InvalidateAllViews();
	}
}

void CTelnetApp::OnViewFont() 
{
	LOGFONT lf;

	CClientDC dc(AfxGetMainWnd());
	dc.SetMapMode(MM_LOENGLISH);

	POINT p;
 	
	GetObject(hfont, sizeof(LOGFONT), &lf);

	p.y = lf.lfHeight;
	dc.LPtoDP(&p);
	lf.lfHeight = p.y;

	CFontDialog cfd(&lf, CF_INITTOLOGFONTSTRUCT|CF_EFFECTS | CF_SCREENFONTS);
	cfd.m_cf.rgbColors = textcolor;

	if(cfd.DoModal() == IDOK)
	{
		p.y = cfd.m_cf.lpLogFont->lfHeight;
		dc.DPtoLP(&p);
		cfd.m_cf.lpLogFont->lfHeight = p.y;

		if((hfont = CreateFont(cfd.m_cf.lpLogFont->lfHeight, 0, 0, 0, cfd.GetWeight(), 
			cfd.IsItalic(), cfd.IsUnderline(), cfd.IsStrikeOut(), 
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
			CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE|DEFAULT_PITCH,  
			cfd.GetFaceName())) != NULL)
		{
			WriteProfileString("font", "facename", cfd.GetFaceName());
			WriteProfileInt("font", "strikeout", cfd.IsStrikeOut());
			WriteProfileInt("font", "underline", cfd.IsUnderline());
			WriteProfileInt("font", "italic", cfd.IsItalic());
			WriteProfileInt("font", "weight", cfd.GetWeight());
			WriteProfileInt("font", "size", cfd.m_cf.lpLogFont->lfHeight);

			textcolor = cfd.GetColor();
			CEnhString cs;
			cs.printf("%ld", textcolor);
			WriteProfileString("windows", "textcolor", cs);

			POSITION pos, vpos;
			struct doclist *pdl;

			for(pos = m_DocList.GetHeadPosition(); pos != NULL; )
			{
    			pdl = (struct doclist *) m_DocList.GetNext(pos);
			
				vpos = pdl->pDoc->GetFirstViewPosition();
   
   				while (vpos != NULL)
   				{
      				CTelnetView* pView = (CTelnetView*)(pdl->pDoc->GetNextView(vpos));
      				pView->ChangeFont(hfont);
   				}   
			}
		}
	}
}


// Write window placement info to registry

void CTelnetApp::WriteWindowDetails(const char * window, WINDOWPLACEMENT* lpwndpl)
{
	WriteProfileInt(window, "state", lpwndpl->showCmd);

	WriteProfileInt(window, "min-x", lpwndpl->ptMinPosition.x);
	WriteProfileInt(window, "min-y", lpwndpl->ptMinPosition.y);

	WriteProfileInt(window, "max-x", lpwndpl->ptMaxPosition.x);
	WriteProfileInt(window, "max-y", lpwndpl->ptMaxPosition.y);

	WriteProfileInt(window, "rect-top", lpwndpl->rcNormalPosition.top);
	WriteProfileInt(window, "rect-left", lpwndpl->rcNormalPosition.left);
	WriteProfileInt(window, "rect-right", lpwndpl->rcNormalPosition.right);
	WriteProfileInt(window, "rect-bottom", lpwndpl->rcNormalPosition.bottom);
}


// Read window placement info from registry

int CTelnetApp::GetWindowDetails(const char * window, WINDOWPLACEMENT* lpwndpl)
{
	int rc = 1;
	
  lpwndpl->showCmd = (int) (read_profile ? GetProfileInt(window, "state", -1) : -1);

	if(lpwndpl->showCmd == -1)
	{
		lpwndpl->showCmd = SW_SHOWNORMAL;
		rc = 0;		// there doesn't seem to be an entry for this window
	}

  lpwndpl->ptMinPosition.x = (int) (read_profile ? GetProfileInt(window, "min-x", 0) : 0);
  lpwndpl->ptMinPosition.y = (int) (read_profile ? GetProfileInt(window, "min-y", 0) : 0);

  lpwndpl->ptMaxPosition.x = (int) (read_profile ? GetProfileInt(window, "max-x", 0) : 0);
  lpwndpl->ptMaxPosition.y = (read_profile ? GetProfileInt(window, "max-y", 0) : 0);

  lpwndpl->rcNormalPosition.top = (int) (read_profile ? GetProfileInt(window, "rect-top", 0x20) : 0x20);
  lpwndpl->rcNormalPosition.left = (int) (read_profile ? GetProfileInt(window, "rect-left", 0x20) : 0x20);
  lpwndpl->rcNormalPosition.right = (int) (read_profile ? GetProfileInt(window, "rect-right", 0x250) : 0x250);
  lpwndpl->rcNormalPosition.bottom = (int) (read_profile ? GetProfileInt(window, "rect-bottom", 0x180) : 0x180);

	return rc;
}


