/*********************************************************************/
/* file: main.c - main module - signal setup/shutdown etc            */
/*                             TINTIN++                              */
/*          (T)he K(I)cki(N) (T)ickin D(I)kumud Clie(N)t             */
/*                     coded by peter unold 1992                     */
/*********************************************************************/

#include "stdafx.h"
#include "sound.h"

extern void keyio(char *cptr);
extern void do_tab_complete(char c, struct session *ses);

BOOL started = FALSE;
BOOL splitting = FALSE;
WSADATA WSAData;
char lastline[255];

/*************** globals ******************/
int term_echoing = TRUE;
int echo = DEFAULT_ECHO;
int speedwalk = DEFAULT_SPEEDWALK;
int togglesubs = DEFAULT_TOGGLESUBS;
int presub = DEFAULT_PRESUB;
int redraw = DEFAULT_REDRAW;
int update_common = DEFAULT_UPDATE;
int sessionsstarted;
int puts_echoing = TRUE;
int verbose = FALSE;
int alnum = 0;
int acnum = 0;
int subnum = 0;
int varnum = 0;
int hinum = 0;
int pdnum = 0;
int antisubnum = 0;
int verbatim = 0;
int wraplength = 80;
char homepath[1025];
char E = 27;
int bppmode = 0;
int read_profile = 1;

struct session *sessionlist, *activesession;
struct listnode *common_aliases, *common_actions, *common_subs, *common_myvars;
struct listnode *common_highs, *common_antisubs, *common_pathdirs;
char vars[10][BUFFER_SIZE];	/* the %0, %1, %2,....%9 variables */
char remvars[BUFFER_SIZE];  /* the %r variable */
char tintin_char = DEFAULT_TINTIN_CHAR;
char verbatim_char = DEFAULT_VERBATIM_CHAR;
char system_com[80] = SYSTEM_COMMAND_DEFAULT;
int mesvar[7];
int term_columns;
char k_input[BUFFER_SIZE];
char done_input[BUFFER_SIZE], prev_command[BUFFER_SIZE];
int hist_num;

void strip(char *buf);

int conn_has_closed = 0;

int input_not_visible = 0;			// true when the keyboard input isn't visible for editing

HWND hwMusicMCIWnd, hwSoundMCIWnd;    /* window handle for invisible mci player window */

#define MAXTITLESIZE 40

// Types for SetCurrent (from scrbuf.h)

#define SBSTART 	0
#define SBEND   	1
#define SBCURR  	2

struct
{
  int handle;
  char window_title[MAXTITLESIZE + 1];
}
wins[12];

int last_line_length;

BOOL myhandler(DWORD cttype)
{
  /* tell telnet to close up shop */

  closemainwindow();

  if (started == TRUE)
  {
    return TRUE;		/* allow other handlers to function */
  }
  else
    return FALSE;
}

/**************************************************************************/
/* main() - show title - setup signals - init lists - readcoms - tintin() */
/**************************************************************************/

extern void packettest();

int read_command_file(char *name)
{
  int fd;
	char buf[200];

	if ((fd = _open(name, O_RDONLY)) > 0)
  {				/* Check if it exists */
    _close(fd);

		sprintf(buf, "Reading command file '%s'.\n\n", name);
    tintin_puts(buf, (struct session *) NULL);
    activesession = read_command(name, NULL);
		return 1;
  }

	return 0;
}

void tininit(char *cmdline)
{
  struct session *ses;
  char *strptr, temp[BUFFER_SIZE], *cptr;
  int err;
	int i = 0;

  sessionlist = NULL;
  
	if(!read_complete("tab.txt"))
	{
    if ((cptr = (char *) getenv("HOME")))
    {
      strcpy(temp, cptr);
      strcat(temp, "\\tab.txt");
      read_complete(temp);
    }
  }

#ifdef DEBUG_INIT
  tintin_puts("returned from read_complete\n", (struct session *) NULL);
#endif  
  *k_input = '\0';
  hist_num = -1;
  ses = NULL;
#ifdef DEBUG_INIT
  tintin_puts("calling time\n", (struct session *) NULL);
#endif
  time0 = time(NULL);
  time_started = time(NULL);
  srand( (unsigned)time0);


  /* initialize winsocket */
#ifdef DEBUG_INIT
  tintin_puts("initialising winsock\n", (struct session *) NULL);
#endif
  if ((err = WSAStartup((WORD) 0x0101, &WSAData)) != 0)		/* register task with */
  {				/* winsock tcp/ip API */
    syserr("Winsock Initialization failure");
		return;

  }


  started = TRUE;
#ifdef DEBUG_INIT
  tintin_puts("initialised winsock\n", (struct session *) NULL);
#endif
  common_aliases = init_list();
  common_actions = init_list();
  common_subs = init_list();
  common_myvars = init_list();
  common_highs = init_list();
  common_antisubs = init_list();
  common_pathdirs = init_list();
#ifdef DEBUG_INIT    
tintin_puts("back from init_list\n", (struct session *) NULL);
#endif
  mesvar[0] = DEFAULT_ALIAS_MESS;
  mesvar[1] = DEFAULT_ACTION_MESS;
  mesvar[2] = DEFAULT_SUB_MESS;
  mesvar[3] = DEFAULT_ANTISUB_MESS;
  mesvar[4] = DEFAULT_HIGHLIGHT_MESS;
  mesvar[5] = DEFAULT_VARIABLE_MESS;
  mesvar[6] = DEFAULT_PATHDIR_MESS;
#ifdef DEBUG_INIT
  tintin_puts("setting up homepath\n", (struct session *) NULL);
#endif
  *homepath = '\0';
  if (!strcmp(DEFAULT_FILE_DIR, "HOME"))
	{
    if (strptr = getenv("HOME"))
			strcpy(homepath, strptr);
    else
			*homepath = '\0';
	}
  else
    strcpy(homepath, DEFAULT_FILE_DIR);
#ifdef DEBUG_INIT
  tintin_puts("checking for rc file\n", (struct session *) NULL);
#endif
  	
  if(cmdline[0] && cmdline[0] != '-')
	{
		/* Read in the file specified on the command line */

		if(!read_command_file(cmdline))
		{
			sprintf(temp, "Can't find command file '%s'.\n", cmdline);
			tintin_puts(temp, (struct session *) NULL);
		}
	}
	else
	{
		/* Try four different command files, in order. Only read
			 a maximum of one */

		strcpy(temp, "tintinrc.");

		if(!read_command_file(temp))
		{
			strcat(temp, "txt");
			if(!read_command_file(temp) && homepath[0])
			{
				strcpy(temp, homepath);
				strcat(temp, "\\tintinrc.");

				if(!read_command_file(temp))
				{
					strcat(temp, "txt");
					read_command_file(temp);
				}
			}
		}
	}
  version_command();
}


/***************************/
/* quit handler            */
/***************************/

void unhook_session(struct session *ses)
{
	struct session *sesptr, **lastptr;

	sesptr = sessionlist;
	lastptr = &sessionlist;

	while(sesptr)
	{
		if(sesptr == ses)
		{
			*lastptr = sesptr->next;
			sesptr = sessionlist;
			lastptr = &sessionlist;
		}
		else
		{
			lastptr = &(sesptr->next);
			sesptr = sesptr->next;
		}
	}
}

void tinquit()
{
  while (sessionlist)
  {
    cleanup_session(sessionlist);
    unhook_session(sessionlist);
  }

  kill_all(NULL, END);

  WSACleanup();
}

/***************************/
/* keyboard handlers       */
/***************************/

void tinchar(unsigned c)
{
  int done;

  done = interpret_buffer((unsigned)(c&0xff), activesession);

  if (done)
  {
    hist_num = -1;

    if (term_echoing)
    {
      if (activesession && *done_input)
	if (strcmp(done_input, prev_command))
	  do_history(done_input, activesession);

      tintin_puts2("", activesession);
    }

    if (*done_input)
      strcpy(prev_command, done_input);

    activesession = parse_input(done_input, activesession);
  }

  if (conn_has_closed && activesession)
  {
    cleanup_session(activesession);
		unhook_session(activesession);
    activesession = newactive_session();
    conn_has_closed = 0;
  }
}

int tinspecchar(char *spec)
{
	struct listnode *ln;
	char buf[BUFFER_SIZE];
  
	if((ln = searchnode_list_begin((activesession) ? activesession->aliases : common_aliases, 
		spec, ALPHA)) != NULL)
	{
		/*
		tintin_puts2(ln->right, activesession);
    
		if (activesession)
			write_line_mud(ln->right, activesession);
		else
			write_com_arg_mud("", "", activesession);	// to provoke the 'no session' message
		*/

		strcpy(buf, ln->right);
//		strcat(buf, "\r\n");
		activesession = parse_input(buf, activesession);

		return 1;
	}
	else
		return 0;
}

/***************************/
/* rec'd data handler      */
/***************************/
void tinread(SOCKET rsock)
{
  fd_set sockset;
  int rvalue = 0;
  struct session *sesptr;
  TIMEVAL mytimeval =
  {0, 0};

  FD_ZERO(&sockset);

  for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
    FD_SET(sesptr->socket, &sockset);
	

  rvalue = select(32, &sockset, 0, 0, &mytimeval);

  if (rvalue == SOCKET_ERROR)
    syserr("select");

  for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
    if (sesptr->comtype == TELNET
	// && FD_ISSET(sesptr->socket, &sockset)
	&& sesptr->socket == rsock)
    {
      sesptr->watchdog = 0;
		read_mud(sesptr);
      break;
    }

  //wl somehow this got called with null activesession

  if (conn_has_closed && activesession)
  {
    cleanup_session(activesession);
		unhook_session(activesession);
    activesession = newactive_session();
    conn_has_closed = 0;
  }
}

void tinasyncread(struct session *sesptr)
{
  read_mud(sesptr);
}
/***************************/
/* session close handler   */
/***************************/

// Changes per Feng Chen 

void tinclose(SOCKET sock)
{
  struct session *sesptr;
  // fd_set sockset;

  if (started)
  {
    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      if (/*FD_ISSET(sesptr->socket, &sockset) && */ sesptr->socket == sock)
      {
				cleanup_session(sesptr);
				// unhook_session(activesession);
				activesession = newactive_session();
				break;
      }

    // WSACleanup();
  }
}


void display_string(char *buf)
{
	if (term_echoing)
	{
		if (splitting)
		{
			if (buf[0] == 0x0d)
				showinwin("\r\n> ", 10);
			else
				showinwin(buf, 10);
		}
		else
			keyio(buf);

		input_not_visible = 0;
	}
}


void display_char(unsigned c)
{
	char buf[2];

	buf[0] = (char)c;
	buf[1] = 0;

	display_string(buf);
}

// add a character to the buffer at the specified location

void addchar(char *buffer, char c, int loc)
{
	int len = strlen(buffer);

	if(loc >= len)
	{
		buffer[loc] = c;
		buffer[loc+1] = 0;
	}
	else if(loc >= 0)
	{
		memmove(&buffer[loc+1], &buffer[loc], len-loc+1);
		buffer[loc] = c;
	}
}

// clear the current input line

void clearline()
{
	int i;
	int j = strlen(k_input);

	for(i=0; i<j; i++)
		display_char(8);
}

/* The all-new interpret_buffer: handle keyboard input one character
   at a time

*/

int current_history = -1;
int current_insert_pos = 0;

int interpret_buffer(unsigned c, struct session *ses)
{
	switch(c)
	{
	case '\n':
	case '\r':
		display_char(c);
    strcpy(done_input, k_input);
    k_input[0] = 0;
		current_history = -1;
		current_insert_pos = 0;
		input_not_visible = 0;
    return 1;

	case 127:				// backspace
	case 8:					// 
    if (strlen(k_input) != 0 && current_insert_pos > 0)
    {
			if(input_not_visible)
				display_string(k_input);

			memmove(&k_input[current_insert_pos-1], &k_input[current_insert_pos], strlen(&k_input[current_insert_pos])+1);

			current_insert_pos--;
			display_char(c);
    }
		return 0;

	case 174:					// delete
	    if (strlen(k_input) != 0 && current_insert_pos > 0)
		{
			if(input_not_visible)
				display_string(k_input);

			memmove(&k_input[current_insert_pos], &k_input[current_insert_pos+1], strlen(&k_input[current_insert_pos])+1);

			if(current_insert_pos < (int)strlen(k_input))
			{
				setinsertpos(SBCURR, 1, splitting ? wins[10].handle : wins[0].handle);
				current_insert_pos++;
			}
			
			display_char(8);
		}
		return 0;
								
	case 0xA6:				// uparrow
		if(ses && current_history < HISTORY_SIZE - 1 && ses->history[current_history+1])
		{
			current_history++;
			clearline();
			strcpy(k_input, ses->history[current_history]);
			display_string(k_input);
			current_insert_pos = strlen(k_input);
		}
		return 0;

	case 0xA8:				// downarrow
		if(ses && current_history >= 0)
		{
			current_history--;
			clearline();

			if(current_history >= 0)
				strcpy(k_input, ses->history[current_history]);
			else
				k_input[0] = 0;

			display_string(k_input);
			current_insert_pos = strlen(k_input);
		}
		return 0;

	case 0xA5:				// leftarrow
		if(current_insert_pos > 0)
		{
			setinsertpos(SBCURR, -1, splitting ? wins[10].handle : wins[0].handle);
			current_insert_pos--;
		}
		return 0;

	case 0xA7:				// rightarrow
		if(current_insert_pos < (int)strlen(k_input))
		{
			setinsertpos(SBCURR, 1, splitting ? wins[10].handle : wins[0].handle);
			current_insert_pos++;
		}
		return 0;

	case 9:					// tab
		do_tab_complete((char)c, ses);
		current_insert_pos = strlen(k_input);
		return 0;
	
	case 27:				// escape
		current_insert_pos = strlen(k_input);	
		clearline(); 
		k_input[0] = 0;
		return 0;
	
	default:
		addchar(k_input, (char)c, current_insert_pos++);

		if(input_not_visible)
			display_string(k_input);
		else
			display_char(c);

		return 0;
	}
}

void do_tab_complete(char c, struct session *ses)
{
	int counter, flag;
	char *cptr, *cptr2;
	struct completenode *tcomp;

  cptr = k_input + strlen(k_input) - 1;
  counter = 0;
  while (*cptr != ' ' && cptr != k_input)
  {
		cptr--;
		counter++;
  }

  if (*cptr == ' ')
		cptr++;
  
	tcomp = complete_head;
  flag = TRUE;
  while ((tcomp = tcomp->next) && flag)
  {
		if (!strncmp(tcomp->strng, cptr, strlen(cptr)))
		{
			cptr2 = tcomp->strng + strlen(cptr);
			strcat(k_input, cptr2);
			display_string(cptr2);
			flag = FALSE;
		}
  }
}



/*************************************************************/
/* read text from mud and test for actions/snoop/substitutes */
/*************************************************************/

void read_mud(struct session *ses)
{
  char buffer[BUFFER_SIZE*2], linebuffer[BUFFER_SIZE*2], *cpsource, *cpdest;
  char temp[BUFFER_SIZE*2];
  char *result2, result[BUFFER_SIZE*2];
  int didget, n, count, i, inansi;
	static int length;

  didget = read_buffer_mud(buffer, ses);

  if (conn_has_closed)
  {
    cleanup_session(ses);
		unhook_session(ses);
    if (ses == activesession)
      activesession = newactive_session();

		// CL.Wu : reset this variable 

		// as the closed connection already removed!

		conn_has_closed = 0;

  }

	if(!didget)
		return;

	/* Log the input if logging is turned on */

  if (ses->logfile)
  {
		count = 0;

		for (n = 0; n <= didget; n++)
			if (buffer[n] != '\r')
			{
				temp[count] = buffer[n];
				count++;
			}
	
		temp[count] = 0;
		strip(temp);
		fwrite(temp, strlen(temp), 1, ses->logfile);
  }

	/* we'll copy into linebuffer as we process, using cpdest as
	   a pointer. Each complete line gets processed from linebuffer
		 before the next line is copied in. We may already have a 
		 fragment of a line from the last invocation - if so, copy
		 it into linebuffer before we start... */

  cpsource = buffer;
  cpdest = linebuffer;
  // length = 0;

  if (ses->old_more_coming == 1)
  {
    strcpy(linebuffer, ses->last_line);
		strip(linebuffer);
		length += strlen(linebuffer);
    strcpy(linebuffer, ses->last_line);
    cpdest += strlen(linebuffer);
  }

  result2 = result;
	inansi = 0;	/* Used to keep track of when we're processing an ansi sequence */

	/* cut out each of the lines and process */

  while (*cpsource)
  {				
    if(*cpsource == 0x1b)
			inansi = 1;
		else if(inansi && *cpsource == 'm')
			inansi = 0;
		
		if(!inansi && *cpsource == 0x07)		// bell
		{
			bell_command(ses);
			*cpsource++;
			continue;
		}
		
		/* wrap at wraplength */

    if (*cpsource == '\n' || *cpsource == '\r' || length > wraplength)
    {
			if (length > wraplength)
			{
				if(!inansi)
				{
					/* skip back to the last word break, if there is one */

					*cpdest = 0;

					if(strstr(linebuffer, " ") != NULL)
					{
						while(cpsource > buffer && *(cpsource-1) != ' ')
						{
							cpsource--;
							cpdest--;
						}
					}
				}
				else
				{
					/* avoid breaking an ANSI sequence */

					while (*cpsource && *cpsource != 'm')
						*cpdest++ = *cpsource++;

					if(*cpsource == 'm')
						*cpdest++ = *cpsource++;
				}

				*cpdest++ = '\r';
				*cpdest++ = '\n';
			}

			length = 0;
			*cpdest = '\0';
			do_one_line(linebuffer, ses);

			/* after the line has been processed, we copy the processed line
			   from linebuffer into result, using result2 as a pointer */

			if (!(*linebuffer == '.' && !*(linebuffer + 1)))
			{
				n = strlen(linebuffer);
				memcpy(result2, linebuffer, n);
				result2 += n;
				// *result2++ = *cpsource++;

				if (*cpsource == '\n' || *cpsource == '\r')
					*result2++ = *cpsource++;
			}
			else if (*++cpsource == '\n' || *cpsource == '\r')
				cpsource++;

			/* reset cpdest so that we fetch a fresh line into linebuffer */

			cpdest = linebuffer;
    }
    else   /* not the end of a line */
    {
			// Check for ANSI sequence, remove from length count if found

			if (*cpsource == 0x1b && *(cpsource + 1) == '[')
			{
				// don't get too hung up on format

				for (i = 2; i < 10; i++)
					if (*(cpsource + i) == 'm')
						break;

				length -= (i + 2);
			}

			*cpdest++ = *cpsource++;
			length++;
		}
  }

  *cpdest = '\0';

  if (ses->more_coming == 1)
  {
    strcpy(ses->last_line, linebuffer);
    length = 0;
  }
  else
  {
		/* if there's no more text to come, assume we have a complete line
		   even though it isn't terminated by crlf (it's probably a prompt) */

    do_one_line(linebuffer, ses);
    n = strlen(linebuffer);
    memcpy(result2, linebuffer, n);
    result2 += n;
  }

  *result2 = '\0';

  if (ses == activesession)
    conio(result);
  else if (ses->snoopstatus)
    snoop(result, ses);
}

/**********************************************************/
/* strip ansi codes from buffer                           */
/**********************************************************/

void strip(char *buf)
{
  int i = 0;

  char *start = buf;
  char *end;

  while ((start = strstr(start, "\x1b[")) != NULL)
  {
    end = start + 2;

    while (*end)
    {
      if (!((*end >= '0' && *end <= '9') || *end == ';'))
				break;

      end++;
    }

    if (!(*end))
		{
			// partial sequence at end of string

			*start = 0;
      return;		
		}

    if (*end == 'm')
    {
      // found a valid ansi colour sequence

      end++;

      memmove(start, end, strlen(end) + 1);
    }
    else
      start = end;
  }

	// check for trailing escape

	if(buf[strlen(buf)-1] == 0x1b)
		buf[strlen(buf)-1] = 0;
}

/**********************************************************/
/* do all of the functions to one line of buffer          */
/**********************************************************/
void do_one_line(char *line, struct session *ses)
{
  char buf[3000], buf2[3000], *p, *pp;
  int i;
  struct listnode *ln, *ln2;

  strcpy(buf, line);
  strip(buf);

  if (!buf[0])
    return;

  /* Check for bpp packet */

  if (bppmode)
  {
    if (!strncmp(buf, "BPP", 3))
    {
      if (ses->in_bpp_packet)
      {
	      ses->bpp_packet[ses->bpp_packet_line] = "";
	      parse_bpp_packet(ses->Mud, ses->bpp_packet);

	      for (i = 0; ses->bpp_packet[i][0]; i++)
	        free(ses->bpp_packet[i]);
      }

      ses->in_bpp_packet = !ses->in_bpp_packet;
      ses->bpp_packet_line = 0;
    }
    else if (ses->in_bpp_packet)
    {
      if (ses->bpp_packet_line < MAX_BPP_LINES - 1)
      	ses->bpp_packet[ses->bpp_packet_line++] = strdup(buf);
    }

    return;
  }

  if(msp_active)
  {
     if(strstr(buf, "!!SOUND") || strstr(buf, "!!MUSIC"))
       process_msp(buf);
  }


  if (!presub && !ses->ignore)
    check_all_actions(buf, ses);

  if (!togglesubs)
  {
    if (!do_one_antisub(buf, ses))
      if (!do_one_sub(line, ses))
	if (do_one_sub(buf, ses))
	  strcpy(line, buf);
  }

  strcpy(buf, line);
  strip(buf);

	/* Capture for mapping */

	if(mapping && strlen(mapbuf) + strlen(buf) < 9500)
	{
		strcpy(buf2, buf);

		while(pp = strchr(buf2, '<'))
			*pp = ' ';

		while(pp = strchr(buf2, '>'))
			*pp = ' ';

		while(pp = strchr(buf2, '&'))
			*pp = ' ';

		while(pp = strchr(buf2, '\r'))
			*pp = ' ';

		while(pp = strchr(buf2, '\n'))
			*pp = ' ';

		strcat(mapbuf, buf2);
		strcat(mapbuf, "\r\n");
	}

  /* Check for captures */

  ln = ses->captures;

  while ((ln = ln->next))
  {
    if ((ln2 = searchnode_list(ses->myvars, ln->left)) == NULL)
    {
			i = strlen(buf);

			if(i >= BUFFER_SIZE-1)
				buf[BUFFER_SIZE-1] = 0;

      insertnode_list(ses->myvars, ln->left, buf, "0", ALPHA);
      varnum++;
    }
    else
    {
      i = strlen(buf) + strlen(ln2->right) + 4;

      if(i < BUFFER_SIZE-1)
      {
        p = mymalloc(i);
        strcpy(p, ln2->right);

        if(p[0])
          strcat(p, ", ");

        strcat(p, buf);
        myfree(ln2->right);
        ln2->right = p;
      }
    }

    if(i >= BUFFER_SIZE-1 || check_one_action(buf, ln->right, ses))
    {
			if(i >= BUFFER_SIZE-1 && echo)
				tintin_debug("capture buffer overflow!", ses);

      deletenode_list(ses->captures, ln);
      ln = ses->captures;
    }
  }


  if (presub && !ses->ignore)
    check_all_actions(buf, ses);

  do_one_high(line, ses);
}

/**********************************************************/
/* snoop session ses - chop up lines and put'em in buffer */
/**********************************************************/
void snoop(char *buffer, struct session *ses)
{
  /* int n; */
  char *cpsource, *cpdest, line[BUFFER_SIZE], linebuffer[BUFFER_SIZE], header[BUFFER_SIZE];

  *linebuffer = '\0';

	sprintf(line, "\n\r");
  strcat(linebuffer, line);
  
  cpsource = buffer;
  sprintf(header, "%s%% ", ses->name);
  strcpy(line, header);
  cpdest = line + strlen(line);
  while (*cpsource)
  {
    if (*cpsource == '\n' || *cpsource == '\r')
    {
      *cpdest++ = *cpsource++;
      if (*cpsource == '\n' || *cpsource == '\r')
	*cpdest++ = *cpsource++;
      *cpdest = '\0';
      strcat(linebuffer, line);
      cpdest = line + strlen(header);
    }
    else
      *cpdest++ = *cpsource++;
  }
  if (cpdest != line + strlen(header))
  {
    *cpdest++ = '\r';
    *cpdest++ = '\n';
    *cpdest = '\0';
    strcat(linebuffer, line);
  }
  conio(linebuffer);
}
/*****************************************************/
/* low-level output to the screen                    */
/* re-open the window if it has been closed by user  */
/*****************************************************/

void showinwin(char *cptr, int window)
{
  if (!showstr(cptr, wins[window].handle))
  {
    /* need to re-open window */

    if (window == 0 && !wins[window].window_title[0])
      strcpy(wins[window].window_title, "Wintin 95");	/* Default main window
							 * title */
    else if (window == 10 && !wins[window].window_title[10])
      strcpy(wins[window].window_title, "Input");

    else if (window == 11 && !wins[window].window_title[11])
      strcpy(wins[window].window_title, "Debug");

    wins[window].handle = newwindow(wins[window].window_title);
    showstr(cptr, wins[window].handle);
  }
}
/**************************************************************/
/* Open a new child window                                    */
/**************************************************************/

void openwin(char *arg)
{
  char left[BUFFER_SIZE], right[BUFFER_SIZE];
  int window = 0;

  arg = get_arg_in_braces(arg, left, 1);
  arg = get_arg_in_braces(arg, right, 1);

  window = left[0] - '0';

  if (window < 0 || window > 9)
    return;

  strcpy(wins[window].window_title, right);

  showinwin("", window);
}
/**************************************************************/
/* process a window-switch escape sequence                    */
/**************************************************************/

void wswitch(char *cptr)
{
  int window = 0;
  int andmain = 0;
  int i = 5;

  window = cptr[3] - '0';
  andmain = cptr[2] - '5';

  if (cptr[i])
  {
    showinwin(&cptr[i], window);
    showinwin("\r\n", window);

    if (andmain)
      showinwin(&cptr[i], 0);
  }
}


void keyio(char *cptr)
{
  char *p, *q, *l;

  /*
   * check for window-switching escape sequence, could be anywhere in the
   * text
   */

  l = cptr;
  p = cptr;

  while (p && *p && (q = strstr(p, "\x1b[")) != NULL)
  {
    if ((*(q + 2) == '5' || *(q + 2) == '6') && (isdigit(*(q + 3))) && (*(q + 4) == 'm' || *(q + 4) == ','))
    {
      /* found a window-switch */

      if (l != q)
      {
	/*
	 * emit everything up to this point through
	 * main window
	 */

	*q = 0;
	showinwin(l, 0);
	*q = 0x1b;
	l = q;
      }

      /* window switch to highlight reset sequence or to end */

      if ((q = strstr(q + 1, "\x1b[99m")) != NULL)
	*q = 0;

      wswitch(l);

      if (q != NULL)
	*q = 0x1b;

      p = q;
      l = q;
    }
    else
      p++;
  }

  //emit any remaining string

  if (l != NULL && *l)
    showinwin(l, 0);
}	


/* Output to screen, honouring window-switch sequences.
   This function should be used for displaying everything
	 EXCEPT keystrokes, which should be done with keyio
	 */

void conio(char *cptr)
{
	int n;

	keyio(cptr);

	if(strlen(k_input) && (strchr(cptr, '\n') || strchr(cptr, '\r')))
	{
		if(redraw && term_echoing)
		{
			if(!splitting)
			{
				keyio(k_input);

				if((n = current_insert_pos - strlen(k_input)) < 0)
					setinsertpos(SBCURR, n, wins[0].handle);
			}
		}
		else
			input_not_visible = 1;
	}
}


/*****************************************************/
/* output to screen should go throught this function */
/* text gets checked for actions                     */
/*****************************************************/
void tintin_puts(char *cptr, struct session *ses)
{
  tintin_puts2(cptr, ses);
  if (ses)
    check_all_actions(cptr, ses);

}
/*****************************************************/
/* output to screen should go throught this function */
/* not checked for actions                           */
/*****************************************************/
void tintin_puts2(char *cptr, struct session *ses)
{
  char strng[1024];

  if ((ses == activesession || ses == NULL) && puts_echoing)
  {
    sprintf(strng, "%s\n\r", cptr);
    conio(strng);
  }

}
/*****************************************************/
/* output to screen should go throught this function */
/* not checked for actions                           */
/*****************************************************/
void tintin_puts3(char *cptr, struct session *ses)
{
  char strng[1024];

  if ((ses == activesession || ses == NULL) && puts_echoing)
  {
    cptr++;
    sprintf(strng, "%s\n\r", cptr);
    conio(strng);
  }
}

/* Debug output */

void tintin_debug(char *cptr, struct session *ses)
{
  char strng[1024];

  if ((ses == activesession || ses == NULL) && puts_echoing)
  {
    sprintf(strng, "%s\n\r", cptr);
    showinwin(strng, 11);
  }

}

/* Panel Output */

void tintin_panel(int ind, char *txt, struct session *ses)
{
  if(ses == activesession || ses == NULL)
		paneltext(ind, txt);
}


/****************************************/
/* alarm signal handler used for ticker */
/****************************************/
void tintick()
{
  static int last_time;
  struct session *sesptr;

  /* wdl avoid multiple invocations in same second */

  if (last_time == time(NULL))
    return;

  // kick the reader if necessary

   for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
   {
		if(++(sesptr->watchdog) > 5)
		{
			// tintin_puts2("watchdog\n", sesptr);
			tinread(sesptr->socket);
		}
   }

  last_time = time(NULL);

  sec_to_tick = tick_size - ((time(NULL) - time0) % tick_size);

  if (sec_to_tick == tick_size || sec_to_tick == 10 || sec_to_tick == (tick_size - 10))
  {
    struct session *sesptr;

    for (sesptr = sessionlist; sesptr; sesptr = sesptr->next)
      if (sesptr->tickstatus)
	if (sec_to_tick == tick_size)
	  tintin_puts("#TICK!!!", sesptr);
	else if (sec_to_tick == 10)
	  tintin_puts("#TICK-10", sesptr);
	else
	  tintin_puts("#TICK+10", sesptr);
  }
}

void split_command()
{
  splitting = TRUE;
  showinwin("\r\n> ", 10);
  setcarethandle(wins[10].handle);
  prompt(NULL);
}

void unsplit_command()
{
  splitting = FALSE;
  setcarethandle(100);
  prompt(NULL);
}

/****************************************/
/* display the smart client window      */
/****************************************/

void displaysmartmud()
{
  if (activesession != NULL)
    display_mud_object(activesession->Mud);
}
