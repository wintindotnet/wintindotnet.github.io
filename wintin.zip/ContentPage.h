// ContentPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CContentPage dialog

class CContentPage : public CPropertyPage
{
// Construction
public:
	CContentPage(CWnd* pParent = NULL);   // standard constructor
  class CService *pService;
	void OnRButtonDown(UINT nFlags, CPoint point);

// Dialog Data
	//{{AFX_DATA(CContentPage)
	enum { IDD = IDD_CONTENT_PAGE };
	CEnhListBox	m_clb;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContentPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

  CEnhListBox m_EnhListBox;
	// Generated message map functions
	//{{AFX_MSG(CContentPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
