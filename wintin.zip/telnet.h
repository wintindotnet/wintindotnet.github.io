// telnet.h : main header file for the TELNET application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTelnetApp:
// See telnet.cpp for the implementation of this class
//

class CTelnetApp : public CWinApp
{
protected:
	BOOL OnIdle(LONG lCount);
	void InvalidateAllViews();

public:
	CTelnetApp();
	CTelnetDoc* GetDocument(int handle);
	void AddDocToList(CTelnetDoc *doc);
	void RemDocFromList(CTelnetDoc *doc);
	int NewDocument(LPSTR lpszTitle = NULL);
	int GetWindowDetails(const char *, WINDOWPLACEMENT*);
	void WriteWindowDetails(const char *, WINDOWPLACEMENT*);
	int GetDocHandle(CTelnetDoc *doc);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL                    

// Implementation
	COleTemplateServer m_server;
		// Server object for document creation

	//{{AFX_MSG(CTelnetApp)       
	afx_msg void OnAppAbout();
	afx_msg void OnViewTextColor();
	afx_msg void OnViewBackgroundcolor();
	afx_msg void OnViewFont();
	afx_msg void OnViewWrap();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
// Data

private:
	CPtrList m_DocList;		// list of open documents and associated handles
	int m_NextDocHandle;	// next handle to allocate
public:
	int iCaretHandle;		// Handle to document that has the caret
  int read_profile;   // set to zero to disable reading from profile
	COLORREF backcolor, textcolor;
	HFONT hfont;
};



/////////////////////////////////////////////////////////////////////////////

