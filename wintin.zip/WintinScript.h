#if !defined(AFX_WINTINSCRIPT_H__16D95762_91F4_49CA_9040_9D3FFD7B9CA5__INCLUDED_)
#define AFX_WINTINSCRIPT_H__16D95762_91F4_49CA_9040_9D3FFD7B9CA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WintinScript.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// WintinScript command target

class WintinScript : public CCmdTarget
{
	DECLARE_DYNCREATE(WintinScript)

	WintinScript();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WintinScript)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~WintinScript();

	// Generated message map functions
	//{{AFX_MSG(WintinScript)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(WintinScript)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(WintinScript)
	afx_msg short Command(LPCTSTR cmd);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINTINSCRIPT_H__16D95762_91F4_49CA_9040_9D3FFD7B9CA5__INCLUDED_)
