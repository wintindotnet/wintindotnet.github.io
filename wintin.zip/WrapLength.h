#if !defined(AFX_WRAPLENGTH_H__B3B525B4_E752_11D2_B8EC_000064657374__INCLUDED_)
#define AFX_WRAPLENGTH_H__B3B525B4_E752_11D2_B8EC_000064657374__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WrapLength.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWrapLength dialog

class CWrapLength : public CDialog
{
// Construction
public:
	CWrapLength(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWrapLength)
	enum { IDD = IDD_WRAPLENGTH };
	int		m_WrapLength;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWrapLength)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWrapLength)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WRAPLENGTH_H__B3B525B4_E752_11D2_B8EC_000064657374__INCLUDED_)
