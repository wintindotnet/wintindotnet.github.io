// ContentPage.cpp : implementation file
//

#include "stdafx.h"
#include "scrbuf.h"
#include "telnedoc.h"
#include "telnet.h"
#include "enhstr.h"
#include "EnhListBox.h"
#include "ContentPage.h"
#include "packet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContentPage dialog


CContentPage::CContentPage(CWnd* pParent /*=NULL*/)
	: CPropertyPage(CContentPage::IDD)
{  
  //{{AFX_DATA_INIT(CContentPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT


}


void CContentPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CContentPage)
	DDX_Control(pDX, IDC_CONTENT_LIST, m_clb);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CContentPage, CPropertyPage)
	//{{AFX_MSG_MAP(CContentPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContentPage message handlers

BOOL CContentPage::OnInitDialog() 
{
  // m_EnhListBox.SubclassDlgItem(IDC_CONTENT_LIST, this);

  CPropertyPage::OnInitDialog();
	
	pService->FillServicePage();

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CContentPage::OnRButtonDown(UINT nFlags, CPoint point) 
{
	int iItem = m_clb.GetCurSel();

  if(iItem < 0)
    return;
  
  pService->DisplayPopUp(point, m_clb.GetItemData(iItem));
	
	// CPropertyPage::OnRButtonUp(nFlags, point);
}

